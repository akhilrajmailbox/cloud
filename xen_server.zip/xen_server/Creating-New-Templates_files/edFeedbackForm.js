/*
 * Citrix TV FEEDBACK FORMs
 */

/* DETECT APPLICATION ENVIRONMENT & SET VARIABLES */
//Set QA variables as the default
var ffFieldId = ffFieldId_qa;
//If the ffHost is production, update the variables
//if (ffHost === "docs.citrix.com" ||                     //Added 7/7/15
//	ffHost === "support.citrix.com" ||
//    ffHost === "edocssand.citrix.com"||
//    ffHost === "edocsstage.citrix.com")
//{
ffFieldId = ffFieldId_prod;
//}
//If the host is dev, update the variables
if(ffHost === ffDevHost)
{
    ffFieldId.appEnv = "";
    ffJsHost = "//"+ffDevHost;
}

var ffRequiredFields = ['name','type','email'];
var ffWebsiteName = 'eDocs';
var ffCommonCssFile = ffJsHost + ffFieldId.appEnv + '/feedbackform/common/feedback_common.css';
//eDoc topic to	SF Product
var ffedocsPagetoSFProdData = [
    ["/topic/dna-70/", "AppDNA"],
    ["/topic/dna-76/", "AppDNA"],
    ["/topic/dna/", "AppDNA"],
    ["/topic/archive/", "Non-Product Related"],		//Changed from "" to "Non-Product Related" on 6/26/15
    ["/topic/receiver-android-34/", "Citrix Receiver"],
    ["/topic/receiver-android-36/", "Citrix Receiver"],
    ["/topic/receiver-blackberry10-10/", "Citrix Receiver"],
    ["/topic/blackberry-receiver-22/", "Citrix Receiver"],
    ["/topic/receiver-chrome-14/", "Citrix Receiver"],
    ["/topic/receiver-chrome-15/", "Citrix Receiver"],
    ["/topic/receiver-html5-11/", "Citrix Receiver"],
    ["/topic/receiver-html5-13a/", "Citrix Receiver"],
    ["/topic/receiver-html5-14/", "Citrix Receiver"],
    ["/topic/receiver-html5-15/", "Citrix Receiver"],
    ["/topic/receiver-ios-59/", "Citrix Receiver"],
    ["/topic/receivers-java-101/", "Citrix Receiver"],
    ["/topic/receiver-linux-12-1/", "Citrix Receiver"],
    ["/topic/receiver-linux-13-0/", "Citrix Receiver"],
    ["/topic/receiver-linux-13-1/", "Citrix Receiver"],
    ["/topic/rec-mac-11-8/", "Citrix Receiver"],
    ["/topic/rec-mac-11-9/", "Citrix Receiver"],
    ["/topic/mobility-pack/", "Citrix Receiver"],
    ["/topic/receiver-offline-plugin-60/", "Citrix Receiver"],
    ["/topic/receiver-offline-plugin-65/", "Citrix Receiver"],
    ["/topic/plugin-mac-11-2/", "Citrix Receiver"],
    ["/topic/online-plugin-123-windows/", "Citrix Receiver"],
    ["/topic/receiver-playbook-10/", "Citrix Receiver"],
    ["/topic/receiver-updater-win-40-3x/", "Citrix Receiver"],
    ["/topic/ica-settings/", "Citrix Receiver"],
    ["/topic/receiver-windows-40/", "Citrix Receiver"],
    ["/topic/receiver-windows-42/", "Citrix Receiver"],
    ["/topic/receiver-windows-enterprise-3x/", "Citrix Receiver"],
    ["/topic/receiver-8rt-14/", "Citrix Receiver"],
    ["/topic/receiver1102-wince/", "Citrix Receiver"],
    ["/topic/receiver-winphone8-12/", "Citrix Receiver"],
    ["/topic/receiver/", "Citrix Receiver"],
    ["/topic/branch-repeater-rn-61/", "CloudBridge (formerly Branch Repeater)"],
    ["/topic/branch-repeater-61/", "CloudBridge (formerly Branch Repeater)"],
    ["/topic/sdx-60/", "CloudBridge (formerly Branch Repeater)"],
    ["/topic/cb-hardware-map/", "CloudBridge (formerly Branch Repeater)"],
    ["/topic/brsdx-62-map/", "CloudBridge (formerly Branch Repeater)"],
    ["/topic/br-hardware-map/", "CloudBridge (formerly Branch Repeater)"],
    ["/topic/branch-repeater-rn-62/", "CloudBridge (formerly Branch Repeater)"],
    ["/topic/branch-repeater-62/", "CloudBridge (formerly Branch Repeater)"],
    ["/topic/branch-repeater-gui-map/", "CloudBridge (formerly Branch Repeater)"],
    ["/topic/cloudbridge-hardware-2000-map-70/", "CloudBridge (formerly Branch Repeater)"],
    ["/topic/brsdx-70-map/", "CloudBridge (formerly Branch Repeater)"],
    ["/topic/cloudbridge-gui-map-70/", "CloudBridge (formerly Branch Repeater)"],
    ["/topic/cb-rn-70-map/", "CloudBridge (formerly Branch Repeater)"],
    ["/topic/cloudbridge-70/", "CloudBridge (formerly Branch Repeater)"],
    ["/topic/cloudbridge-hardware-2000-map-71/", "CloudBridge (formerly Branch Repeater)"],
    ["/topic/brsdx-71-map/", "CloudBridge (formerly Branch Repeater)"],
    ["/topic/cloudbridge-gui-map-71/", "CloudBridge (formerly Branch Repeater)"],
    ["/topic/cb-rn-71-map/", "CloudBridge (formerly Branch Repeater)"],
    ["/topic/cloudbridge-71/", "CloudBridge (formerly Branch Repeater)"],
    ["/topic/cloudbridge-72-1000-2000-win-map/", "CloudBridge (formerly Branch Repeater)"],
    ["/topic/cloudbridge-72-400-map/", "CloudBridge (formerly Branch Repeater)"],
    ["/topic/cloudbridge-72-brsdx-map/", "CloudBridge (formerly Branch Repeater)"],
    ["/topic/cloudbridge-72-gui-map/", "CloudBridge (formerly Branch Repeater)"],
    ["/topic/cloudbridge-72-rn-map/", "CloudBridge (formerly Branch Repeater)"],
    ["/topic/cloudbridge-72/", "CloudBridge (formerly Branch Repeater)"],
    ["/topic/cloudbridge-73-1000-2000-win-map/", "CloudBridge (formerly Branch Repeater)"],
    ["/topic/cloudbridge-73-400-map/", "CloudBridge (formerly Branch Repeater)"],
    ["/topic/cloudbridge-73-brsdx-map/", "CloudBridge (formerly Branch Repeater)"],
    ["/topic/cloudbridge-73-gui-map/", "CloudBridge (formerly Branch Repeater)"],
    ["/topic/cloudbridge-73-rn-map/", "CloudBridge (formerly Branch Repeater)"],
    ["/topic/cloudbridge-73/", "CloudBridge (formerly Branch Repeater)"],
    ["/topic/cloudbridge-74/", "CloudBridge (formerly Branch Repeater)"],    //Added on 6/26/15
    ["/topic/sdx-56/", "CloudBridge (formerly Branch Repeater)"],
    ["/topic/cloudbridge/", "CloudBridge (formerly Branch Repeater)"],
    ["/topic/cloudplatform/", "CloudPlatform"],
    ["/topic/cloudportalbusiness-13/", "CloudPortal Business Manager"],
    ["/topic/cloudportalbusiness-14/", "CloudPortal Business Manager"],
    ["/topic/ccpb-20-map/", "CloudPortal Business Manager"],
    ["/topic/cpbm-21-map/", "CloudPortal Business Manager"],
    ["/topic/cpbm-22-map/", "CloudPortal Business Manager"],
    ["/topic/cpbm-23-map/", "CloudPortal Business Manager"],
    ["/topic/ccp-10/", "CloudPortal Business Manager"],
    ["/topic/ccps-11/", "CloudPortal Services Manager"],
    ["/topic/ccps-115/", "CloudPortal Services Manager"],
    ["/topic/cloudportal/", "CloudPortal Services Manager"],
    ["/topic/command-center-40/", "NetScaler"],
    ["/topic/command-center-release-notes-40/", "NetScaler"],
    ["/topic/command-center-41/", "NetScaler"],
    ["/topic/cc-release-notes-4-1-map/", "NetScaler"],
    ["/topic/command-center-50/", "NetScaler"],
    ["/topic/cc-release-notes-5-0-map/", "NetScaler"],
    ["/topic/command-center-51/", "NetScaler"],
    ["/topic/command-center-52/", "NetScaler"],
    ["/topic/netscaler-main-api-10-map/", "NetScaler"],
    ["/topic/ns-main-appexpert-10-map/", "NetScaler"],
    ["/topic/ns-faq-map/", "NetScaler"],
    ["/topic/netscaler-getting-started-map-10/", "NetScaler"],
    ["/topic/netscaler-vpx-10/", "NetScaler"],
    ["/topic/netscaler-hrdwre-installation-10/", "NetScaler"],
    ["/topic/netscaler-migration-10/", "NetScaler"],
    ["/topic/ns-optimization-10-map/", "NetScaler"],
    ["/topic/ns-reference-map/", "NetScaler"],
    ["/topic/netscaler-release-notes-10/", "NetScaler"],
    ["/topic/netscaler-10/", "NetScaler"],
    ["/topic/ns-security-10-map/", "NetScaler"],
    ["/topic/ns-system-10-map/", "NetScaler"],
    ["/topic/netscaler-traffic-management-10-map/", "NetScaler"],
    ["/topic/netscaler-main-api-10-1-map/", "NetScaler"],
    ["/topic/ns-main-appexpert-10-1-map/", "NetScaler"],
    ["/topic/ns-faq-map-10-1/", "NetScaler"],
    ["/topic/netscaler-getting-started-map-10-1/", "NetScaler"],
    ["/topic/netscaler-vpx-10-1/", "NetScaler"],
    ["/topic/netscaler-hrdwre-installation-10-1/", "NetScaler"],
    ["/topic/netscaler-migration-10-1/", "NetScaler"],
    ["/topic/ns-solutions-10-1/", "NetScaler"],
    ["/topic/ns-optimization-10-1-map/", "NetScaler"],
    ["/topic/ns-reference-map-10-1/", "NetScaler"],
    ["/topic/ns-rn-main-release-10-1-map/", "NetScaler"],
    ["/topic/netscaler-10-1/", "NetScaler"],
    ["/topic/ns-security-10-1-map/", "NetScaler"],
    ["/topic/ns-system-10-1-map/", "NetScaler"],
    ["/topic/netscaler-traffic-management-10-1-map/", "NetScaler"],
    ["/topic/ns-rn-main-release-10-5-map/", "NetScaler"],
    ["/topic/netscaler-10-5/", "NetScaler"],
    ["/topic/ns-main-appexpert-10-5-map/", "NetScaler"],
    ["/topic/ns-faq-map-10-5/", "NetScaler"],
    ["/topic/netscaler-getting-started-map-10-5/", "NetScaler"],
    ["/topic/netscaler-vpx-10-5/", "NetScaler"],
    ["/topic/netscaler-hrdwre-installation-10-5/", "NetScaler"],
    ["/topic/netscaler-migration-10-5/", "NetScaler"],
    ["/topic/ns-solutions-10-5/", "NetScaler"],
    ["/topic/netscaler-main-api-10-5-map/", "NetScaler"],
    ["/topic/ns-optimization-10-5-map/", "NetScaler"],
    ["/topic/ns-reference-map-10-5/", "NetScaler"],
    ["/topic/ns-security-10-5-map/", "NetScaler"],
    ["/topic/ns-system-10-5-map/", "NetScaler"],
    ["/topic/netscaler-traffic-management-10-5-map/", "NetScaler"],
    ["/topic/netscaler-aaa-app-traffic-93/", "NetScaler"],
    ["/topic/netscaler-admin-guide-93/", "NetScaler"],
    ["/topic/netscaler-advanced-networking-93-map/", "NetScaler"],
    ["/topic/ns-api-map/", "NetScaler"],
    ["/topic/ns-nitro-edocs-93-map/", "NetScaler"],
    ["/topic/netscaler-api-map-93/", "NetScaler"],
    ["/topic/netscaler-appexpert-93/", "NetScaler"],
    ["/topic/netscaler-cache-redirection-93/", "NetScaler"],
    ["/topic/netscaler-application-firewall-93/", "NetScaler"],
    ["/topic/netscaler-client-keep-alive-93-map/", "NetScaler"],
    ["/topic/netscaler-crg-93-map/", "NetScaler"],
    ["/topic/netscaler-compression-93-map/", "NetScaler"],
    ["/topic/netscaler-content-filtering-93/", "NetScaler"],
    ["/topic/netscaler-content-switching-93/", "NetScaler"],
    ["/topic/netscaler-database-users-93/", "NetScaler"],
    ["/topic/db-proxy-reference-93/", "NetScaler"],
    ["/topic/netscaler-dns-gen-93-map/", "NetScaler"],
    ["/topic/netscaler-edgesight-monitor-93/", "NetScaler"],
    ["/topic/netscaler-firewall-load-balancing-map-93/", "NetScaler"],
    ["/topic/ns-flextenancy-map/", "NetScaler"],
    ["/topic/netscaler-getting-started-map-93/", "NetScaler"],
    ["/topic/netscaler-vpx-93/", "NetScaler"],
    ["/topic/netscaler-gslb-93-map/", "NetScaler"],
    ["/topic/netscaler-hrdwre-installation-93/", "NetScaler"],
    ["/topic/netscaler-http-callouts-93-map/", "NetScaler"],
    ["/topic/netscaler-dos-protection-93/", "NetScaler"],
    ["/topic/netscaler-integrated-caching-93-map/", "NetScaler"],
    ["/topic/netscaler-migration-93/", "NetScaler"],
    ["/topic/netscaler-link-load-balancing-93-map/", "NetScaler"],
    ["/topic/netscaler-load-balancing-93/", "NetScaler"],
    ["/topic/netscaler-web-2-0-push-93-map/", "NetScaler"],
    ["/topic/netscaler-pattern-sets-93-map/", "NetScaler"],
    ["/topic/netscaler-policy-configuration-93-map/", "NetScaler"],
    ["/topic/netscaler-priority-queuing-93/", "NetScaler"],
    ["/topic/netscaler-rate-limiting-93/", "NetScaler"],
    ["/topic/netscaler-release-notes-93/", "NetScaler"],
    ["/topic/netscaler-responder-93/", "NetScaler"],
    ["/topic/netscaler-rewrite-93/", "NetScaler"],
    ["/topic/netscaler-ssl-93/", "NetScaler"],
    ["/topic/netscaler-fips-93/", "NetScaler"],
    ["/topic/ns-pi-string-maps/", "NetScaler"],
    ["/topic/netscaler-sureconnect-93-map/", "NetScaler"],
    ["/topic/netscaler-surge-protection-93/", "NetScaler"],
    ["/topic/netscaler-tcp-buffering-93-map/", "NetScaler"],
    ["/topic/ni-1-0-map/", "NetScaler"],
    ["/topic/ni-10-1-map/", "NetScaler"],
    ["/topic/ni-10-5-map/", "NetScaler"],
    ["/topic/ns-sdx-hardware-installation/", "NetScaler"],
    ["/topic/sdx-administration-10-map/", "NetScaler"],
    ["/topic/sdx-administration-10-1-map/", "NetScaler"],
    ["/topic/sdx-administration-10-5-map/", "NetScaler"],
    ["/topic/sdx-crg-map/", "NetScaler"],
    ["/topic/sdx-administration-map/", "NetScaler"],
    ["/topic/netscaler/", "NetScaler"],
    ["/topic/access-gateway-10/", "NetScaler Gateway (formerly Access Gateway)"],
    ["/topic/access-gateway-92/", "NetScaler Gateway (formerly Access Gateway)"],
    ["/topic/access-gateway-93/", "NetScaler Gateway (formerly Access Gateway)"],
    ["/topic/netscaler-gateway-101/", "NetScaler Gateway (formerly Access Gateway)"],
    ["/topic/netscaler-gateway-105/", "NetScaler Gateway (formerly Access Gateway)"],
    ["/topic/access-gateway-hig-appliances/", "NetScaler Gateway (formerly Access Gateway)"],
    ["/topic/netscaler-gateway/", "NetScaler Gateway (formerly Access Gateway)"],
    ["/topic/sharefile-storagezones-22/", "ShareFile"],
    ["/topic/sharefile-storagezones-30/", "ShareFile"],
    ["/topic/sharefile-umt-17/", "ShareFile"],
    ["/topic/sharefile/", "ShareFile"],
    ["/topic/application-streaming-66/", "XenDesktop"],
    ["/topic/application-streaming-67/", "XenDesktop"],
    ["/topic/director-10/", "XenDesktop"],
    ["/topic/director-110/", "XenDesktop"],
    ["/topic/director-200/", "XenDesktop"],
    ["/topic/director-210/", "XenDesktop"],
    ["/topic/edgesight53/", "EdgeSight"],
    ["/topic/edgesight54/", "EdgeSight"],
    ["/topic/edgesight-loadtest-38/", "EdgeSight"],
    ["/topic/hdx-realtime-optimization-pack-14/", "XenDesktop"],
    ["/topic/hdx-realtime-optimization-pack-15/", "XenDesktop"],
    ["/topic/hdx-realtime-optimization-pack-16/", "XenDesktop"],
    ["/topic/licensing-1110/", "Other Product"],
    ["/topic/licensing-1111/", "Other Product"],
    ["/topic/licensing-11121/", "Other Product"],
    ["/topic/citrix-usage-collector-10/", "Other Product"],
    ["/topic/lic-find-by-version/", "Other Product"],
    ["/topic/personal-vdisk-5x/", "XenDesktop"],
    ["/topic/personal-vdisk-7x/", "XenDesktop"],
    ["/topic/user-profile-manager-sou/", "XenDesktop"],
    ["/topic/user-profile-manager-5-x/", "XenDesktop"],
    ["/topic/provisioning-60/", "XenDesktop"],
    ["/topic/provisioning-61/", "XenDesktop"],
    ["/topic/provisioning-7/", "XenDesktop"],
    ["/topic/passwordmanager-4-8/", "XenDesktop"],
    ["/topic/passwordmanager-5-0/", "XenDesktop"],
    ["/topic/dws-storefront-21/", "XenDesktop"],
    ["/topic/dws-storefront-25/", "XenDesktop"],
    ["/topic/dws-storefront-26/", "XenDesktop"],
    ["/topic/dws-storefront-30/", "XenDesktop"],                    //Added 6/26/15
    ["/topic/web-interface-hardwick/", "XenDesktop"],
    ["/topic/web-interface-impington/", "XenDesktop"],
    ["/topic/technologies/", ""],
    ["/topic/vdi-50/", "VDI-in-a-Box"],
    ["/topic/vdi-51/", "VDI-in-a-Box"],
    ["/topic/vdi-52/", "VDI-in-a-Box"],
    ["/topic/vdi-53/", "VDI-in-a-Box"],
    ["/topic/vdi-54/", "VDI-in-a-Box"],
    ["/topic/vdi/", "VDI-in-a-Box"],
    ["/topic/infocenter/", "Non-Product Related"],
    ["/topic/app-orchestration/", "XenApp"],
    ["/topic/xenapp5fp3-w2k8/", "XenApp"],
    ["/topic/xenapp5fp-w2k8/", "XenApp"],
    ["/topic/xenapp5-sec/", "XenApp"],
    ["/topic/xenapp6-w2k8-admin/", "XenApp"],
    ["/topic/xenapp-application-streaming-edocs-v6-0/", "XenApp"],
    ["/topic/xenapp6-w2k8-designing/", "XenApp"],
    ["/topic/hd-hdx-parra/", "XenApp"],
    ["/topic/xenapp6-w2k8-enterprisemgmt/", "XenApp"],
    ["/topic/xenapp6-w2k8-install/", "XenApp"],
    ["/topic/xenapp6-w2k8-loadmgr/", "XenApp"],
    ["/topic/xenapp6-w2k8-pacman/", "XenApp"],
    ["/topic/xenapp6-w2k8/", "XenApp"],
    ["/topic/xenapp6-w2k8-securegateway/", "XenApp"],
    ["/topic/xenapp6-smartauditor-edocs/", "XenApp"],
    ["/topic/xenapp6-vm-hosted-apps/", "XenApp"],
    ["/topic/xenapp6-w2k8-migrating/", "XenApp"],
    ["/topic/xenapp-connector-configmgr/", "XenApp"],
    ["/topic/xenapp6-sec/", "XenApp"],
    ["/topic/xenapp65fp2-w2k8/", "XenApp"],
    ["/topic/xenapp65-w2k8/", "XenApp"],
    ["/topic/xenapp65-enterprisemgmt/", "XenApp"],
    ["/topic/xenapp65-install/", "XenApp"],
    ["/topic/xenapp65-admin/", "XenApp"],
    ["/topic/xenapp65-migrating/", "XenApp"],
    ["/topic/xenapp65-planning/", "XenApp"],
    ["/topic/xenapp65-publishing/", "XenApp"],
    ["/topic/xenapp65-smartauditor-edocs/", "XenApp"],
    ["/topic/xenapp65-securegateway/", "XenApp"],
    ["/topic/xenapp65-sec/", "XenApp"],
    ["/topic/ps-unix/", "XenApp"],
    ["/topic/xendesktop-bdx/", "XenDesktop"],
    ["/topic/xendesktop-5sp1/", "XenDesktop"],
    ["/topic/xendesktop-als/", "XenDesktop"],
    ["/topic/xendesktop-rho/", "XenDesktop"],
    ["/topic/xendesktop-56fp1/", "XenDesktop"],
    ["/topic/xendesktop-ibi/", "XenDesktop"],
    ["/topic/xendesktop-7/", "XenDesktop"],
    ["/topic/citrix-adidentity-admin-v2-xd7/", "XenDesktop"],
    ["/topic/citrix-appv-admin-v1-xd7/", "XenDesktop"],
    ["/topic/citrix-broker-admin-v2-xd7/", "XenDesktop"],
    ["/topic/citrix-configuration-admin-v2-xd7/", "XenDesktop"],
    ["/topic/citrix-configurationlogging-admin-v1-xd7/", "XenDesktop"],
    ["/topic/citrix-delegatedadmin-admin-v1-xd7/", "XenDesktop"],
    ["/topic/citrix-envtest-admin-v1-xd7/", "XenDesktop"],
    ["/topic/citrix-host-admin-v2-xd7/", "XenDesktop"],
    ["/topic/citrix-machinecreation-admin-v2-xd7/", "XenDesktop"],
    ["/topic/citrix-monitor-admin-v1-xd7/", "XenDesktop"],
    ["/topic/citrix-storefront-admin-v1-xd7/", "XenDesktop"],
    ["/topic/xendesktop-71/", "XenDesktop"],
    ["/topic/citrix-adidentity-admin-v2-xd71/", "XenDesktop"],
    ["/topic/citrix-appv-admin-v1-xd71/", "XenDesktop"],
    ["/topic/citrix-broker-admin-v2-xd71/", "XenDesktop"],
    ["/topic/citrix-configuration-admin-v2-xd71/", "XenDesktop"],
    ["/topic/citrix-configurationlogging-admin-v1-xd71/", "XenDesktop"],
    ["/topic/citrix-delegatedadmin-admin-v1-xd71/", "XenDesktop"],
    ["/topic/citrix-envtest-admin-v1-xd71/", "XenDesktop"],
    ["/topic/citrix-host-admin-v2-xd71/", "XenDesktop"],
    ["/topic/citrix-machinecreation-admin-v2-xd71/", "XenDesktop"],
    ["/topic/citrix-monitor-admin-v1-xd71/", "XenDesktop"],
    ["/topic/citrix-storefront-admin-v1-xd71/", "XenDesktop"],
    ["/topic/xenapp-xendesktop-75/", "XenDesktop"],
    ["/topic/citrix-adidentity-admin-v2-xd75/", "XenDesktop"],
    ["/topic/citrix-appv-admin-v1-xd75/", "XenDesktop"],
    ["/topic/citrix-broker-admin-v2-xd75/", "XenDesktop"],
    ["/topic/citrix-configuration-admin-v2-xd75/", "XenDesktop"],
    ["/topic/citrix-configurationlogging-admin-v1-xd75/", "XenDesktop"],
    ["/topic/citrix-delegatedadmin-admin-v1-xd75/", "XenDesktop"],
    ["/topic/citrix-envtest-admin-v1-xd75/", "XenDesktop"],
    ["/topic/citrix-host-admin-v2-xd75/", "XenDesktop"],
    ["/topic/citrix-machinecreation-admin-v2-xd75/", "XenDesktop"],
    ["/topic/citrix-monitor-admin-v1-xd75/", "XenDesktop"],
    ["/topic/citrix-storefront-admin-v1-xd75/", "XenDesktop"],
    ["/topic/xenapp-xendesktop-76/", "XenDesktop"],
    ["/topic/citrix-adidentity-admin-v2-xd76/", "XenDesktop"],
    ["/topic/citrix-appv-admin-v1-xd76/", "XenDesktop"],
    ["/topic/citrix-broker-admin-v2-xd76/", "XenDesktop"],
    ["/topic/citrix-configuration-admin-v2-xd76/", "XenDesktop"],
    ["/topic/citrix-configurationlogging-admin-v1-xd76/", "XenDesktop"],
    ["/topic/citrix-delegatedadmin-admin-v1-xd76/", "XenDesktop"],
    ["/topic/citrix-envtest-admin-v1-xd76/", "XenDesktop"],
    ["/topic/citrix-host-admin-v2-xd76/", "XenDesktop"],
    ["/topic/citrix-machinecreation-admin-v2-xd76/", "XenDesktop"],
    ["/topic/citrix-monitor-admin-v1-xd76/", "XenDesktop"],
    ["/topic/citrix-storefront-admin-v1-xd76/", "XenDesktop"],
    ["/topic/xenapp-xendesktop/", "XenDesktop"],
    ["/topic/xenclient/", "XenClient"],
    ["/topic/mdxtoolkit-10/", "XenMobile"],
    ["/topic/worx-mobile-apps/", "XenMobile"],
    ["/topic/xenmobile-90/", "XenMobile"],
    ["/topic/appcontroller-28/", "XenMobile"],
    ["/topic/xmob-dm-85/", "XenMobile"],
    ["/topic/xmob-multen-8/", "XenMobile"],
    ["/topic/xmob-remote-supp-8/", "XenMobile"],
    ["/topic/xmob-smg-85/", "XenMobile"],
    ["/topic/xenmobile-86/", "XenMobile"],
    ["/topic/xenmobile-87/", "XenMobile"],
    ["/topic/xenmobile/", "XenMobile"],
    ["/topic/xencenter-61/", "XenServer"],
    ["/topic/xencenter-62/", "XenServer"],
    ["/topic/xencenter-65/", "XenServer"],
    ["/topic/xenserver/", "XenServer"],
    ["/app-orchestration/", "XenApp"],			     //Start of new doc site URLs
    ["/appcontroller/", "XenMobile"],
    ["/dna/", "AppDNA"],
    ["/app-streaming/", "XenDesktop"],
    ["/categories/", ""],
    ["/citrix-workspace-cloud/",""],                       //added 7/7/15
    ["/cloudbridge/", "CloudBridge (formerly Branch Repeater)"],
    ["/cloudplatform/", "CloudPlatform"],
    ["/cloudportal-business-manager/", "CloudPortal Business Manager"],
    ["/cloudportal-services-manager/", "CloudPortal Services Manager"],
    ["/command-center/", "NetScaler"],
    ["/docs-site/", ""],
    ["/device-manager/", "XenMobile"],                     //added 7/7/15
    ["/edgesight/", "EdgeSight"],
    ["/hdx-optimization/", "XenDesktop"],
    ["/licensing/", "Other Product"],
    ["/melio/", ""],                                       //added 7/7/15
    ["/mdx-toolkit/", "XenMobile"],
    ["/netscaler/", "NetScaler"],
    ["/netscaler-gateway/", "NetScaler Gateway (formerly Access Gateway)"],
    ["/netscaler-insight/", "NetScaler"],
    ["/sdx/", "NetScaler"],
    ["/profile-management/", "XenDesktop"],
    ["/provisioning/", "XenDesktop"],
    ["/receiver/", "Citrix Receiver"],
    ["/secure-mobile-gateway/", "XenMobile"],               //added 7/7/15
    ["/sharefile/", "ShareFile"],
    ["/sharefile-user-management-tool/", "ShareFile"],
    ["/single-sign-on/", ""],
    ["/storagezones-controller/", "ShareFile"],
    ["/storefront/", "XenDesktop"],
    ["/vdi/", "VDI-in-a-Box"],
    ["/web-interface/", "XenDesktop"],
    ["/worx-mobile-apps/", "XenMobile"],
    ["/xenapp-and-xendesktop/", "XenDesktop"],
    ["/xencenter/", "XenServer"],
    ["/xenclient/", "XenClient"],
    ["/xenmobile/", "XenMobile"],
    ["/xenmobile-secure-mobile-gateway/", "XenMobile"],
    ["/xenserver/", "XenServer"],
    ["/netscaler-cpx/", "NetScaler"],						//added 7/20/16 - tested in UAT on 7/19/16
    ["/netscaler-mas/", "NetScaler"],
    ["/citrix-cloud/", "Other Product"],
    ["/workspace-cloud/", "Other Product"],
    ["/netscaler-control-center/", "NetScaler"],
    ["/xenmobile-apps/", "XenMobile"],
    ["/workspace-suite/", "Other Product"],
    ["/linux-virtual-delivery-agent/", "XenDesktop"]
];


/* FUNCTION FOR OPENING MODAL */
function ffShowForm(id) {

    var ffWebUrlData = window.location.protocol + '//' + window.location.host + window.location.pathname + window.location.search + window.location.hash;
    var ffWindowHeight = window.innerHeight;
    var ffPageYOffset = window.pageYOffset;
    var ffFormPos = ffPageYOffset + 40;
    var ffProduct = ffGetProduct();

    /* STRING USED TO CREATE THE HTML FOR THE FEEDBACK FORM IN THE MODAL */
    var codeFeedbackForm = ''
        + '<style type="text/css">'
        + '		#feedBackFormContainer {'
        + '			top:' + ffFormPos + 'px;'
        + '		}'
        + '</style>'
        + '<div id="feedBackFormSalesForce">'
        + '		<div id="feedBackFormContainerTop">'
        + '			<div id="feedbackFormTitle">Provide feedback about this topic</div>'
        + '			<div id="closeFeedBackForm" onClick="ffHideForm();">x</div>'
        + '			<div class="clearBoth"></div>'
        + '		</div>'
        + ''
        + '		<!--  ----------------------------------------------------------------------  -->'
        + '		<!--  NOTE: Please add the following <FORM> element to your page.             -->'
        + '		<!--  ----------------------------------------------------------------------  -->'
        + ''
        + '		<form id="jsSalesForceFeedback" action="' + ffFieldId.formAction +'" method="POST">'
        + '			<!-- orgid currently pointing to Test environment 00DJ0000003K4xs -->'
        + '			<!-- For production, change orgid value to 00DJ0000003K4xs -->'
        + '			<input type=hidden name="orgid" value="' + ffFieldId.orgId + '">'
        + ''
        + '			<!--  INSERT RETURN URL BELOW-->'
        + '			<input type=hidden name="retURL" value="' + ffWebUrlData + '">'
        + ''
        + '			<!--  ----------------------------------------------------------------------  -->'
        + '			<!--  NOTE: These fields are optional debugging elements.  Please uncomment   -->'
        + '			<!--  these lines if you wish to test in debug mode.                          -->'
        + '			<!--  <input type="hidden" name="debug" value=1>                              -->'
        + '			<!--  <input type="hidden" name="debugEmail"                                  -->'
        + '			<!--  value="francisco.saravia@citrix.com">                                   -->'
        + '			<!--  ----------------------------------------------------------------------  -->'
        + '			<table border="0" class="tableFeedBackForm">'
        + '				<tr>'
        + '					<td><label for="type">Topic:</label></td>'
        + '					<td>'
        + '                     <div class="ffDropDown-container">'
        + '						    <select class="ffDropDown ffField" id="type" name="type">'
        + '						    	<option value="">--None--</option>'
        + '						    	<option value="Content Accuracy">Content Accuracy</option>'
        + '						    	<option value="Website usability">Website usability</option>'
        + '						    	<option value="Other">Other</option>'
        + '						    </select>'
        + '                     </div>'
        + '					</td>'
        + '				</tr>'
        + '				<tr>'
        + '					<td><label for="subject">Subject:</label></td>'
        + '					<td><input class="ffInputTextField ffField" id="subject" maxlength="80" name="subject" size="20" type="text" /></td>'
        + '				</tr>'
        + '				<tr>'
        + '					<td class="align-top"><label for="description">Description:</label></td>'
        + '					<td><textarea class="ffInputTextArea ffField" name="description"></textarea></td>'
        + '				</tr>'
        + '				<tr>'
        + '					<td><label for="'+ ffFieldId.webUrl +'">URL:</label></td>'
        + '					<td>'
        + '						<input class="ffInputTextField ffField" readonly id="'+ ffFieldId.webUrl +'" maxlength="255" value="' + ffWebUrlData + '" name="'+ ffFieldId.webUrl +'" size="20" type="text"  >'
        + '					</td>'
        + '				</tr>'
        + '				<tr>'
        + '					<td><label for="name">Name:</label></td>'
        + '					<td><input class="ffInputTextField ffField" id="name" maxlength="80" name="name" size="20" type="text" /></td>'
        + '				</tr>'
        + '				<tr>'
        + '					<td><label for="email">Email:</label></td>'
        + '					<td><input class="ffInputTextField ffField" id="email" maxlength="80" name="email" size="20" type="text" /></td>'
        + '				</tr>'
        + '				<tr>'
        + '					<td><label for="' + ffFieldId.myAccountLogin + '">Citrix Login:</label></td>'
        + '					<td><input class="ffInputTextField ffField" id="' + ffFieldId.myAccountLogin + '" maxlength="60" name="' + ffFieldId.myAccountLogin + '" size="20" type="text" /></td>'
        + '				</tr>'
        + '				<tr>'
        + '					<td><label for="phone">Phone:</label></td>'
        + '					<td><input class="ffInputTextField ffField" id="phone" maxlength="40" name="phone" size="20" type="text" /></td>'
        + '				</tr>'
        + '				<tr>'
        + '					<td>'
        + '						<!--  MAKE THIS FIELD HIDDEN -->'
        + '					    <label style="display:none;" for="priority">Priority:</label>'
        + '                     <div style="display:none;" class="ffDropDown-container">'
        + '						    <select class="ffDropDown ffField" id="priority" name="priority">'
        + '						    	<option value="">--None--</option><option value="Low">Low</option>'
        + '						    	<option value="Medium">Medium</option>'
        + '						    	<option value="High">High</option>'
        + '						    	<option value="Critical">Critical</option>'
        + '						    </select>'
        + '                     </div>'
        + '						<!--  MAKE THIS FIELD HIDDEN -->'
        + '						<!--  HARDCODE THE VALUE TO "eService"-->'
        + '						<label style="display:none;" for="source">Source:</label>'
        + '						<select class="ffField" style="display:none;" id="'+ ffFieldId.source +'" name="'+ ffFieldId.source +'" title="Source">'
        + '							<option value="eService">eService</option>'
        + '						</select>'
        + ''
        + '						<!--  MAKE THIS FIELD HIDDEN -->'
        + '						<!--  HARDCODE THE VALUE TO "browser"-->'
        + '						<label style="display:none;" for="source">Browser:</label>'
        + '						<input class="ffField" style="display:none;" id="'+ ffFieldId.browser +'" maxlength="100" name="'+ ffFieldId.browser +'" size="20" type="text" value="' + ffBrowser + '"/>'
        + ''
        + '						<!--  MAKE THIS FIELD HIDDEN -->'
        + '						<!--  HARDCODE the value for the Product field -->'
        + '						<label style="display:none;" for="recordType">Product</label>'
        + '						<select class="ffField" style="display:none;"  id="'+ ffFieldId.product +'" name="'+ ffFieldId.product +'">'
        + '							<option value="' + ffProduct + '">' + ffProduct + '</option>'
        + '						</select>'
        + ''
        + '						<!--  MAKE THIS FIELD HIDDEN -->'
        + '						<label style="display:none;" for="recordType">Case Record Type</label>'
        + '						<select class="ffField" style="display:none;"  id="recordType" name="recordType">'
        + '							<option value="' + ffFieldId.caseRecordType + '">Services Website</option>'
        + '						</select>'
        + ''
        + '						<!-- USED TO SET WEBSITE -->'
        + ' 					<input value="'+ ffWebsiteName +'" id="' + ffFieldId.webSite +'" maxlength="255" name="' + ffFieldId.webSite +'" size="20" type="hidden" />'
        + ''
        + '						<input type="hidden"  id="external" name="external" value="1" />'
        + '					</td>'
        + '				</tr>'
        + '				<tr>'
        + '					<td colspan="2"><i id="requiredText">Required fields are marked with an <span class="requiredField">*</span></i></td>'
        + '				</tr>'
        + '				<tr>'
        + '					<td></td>'
        + '					<td><input id="ffButtonSubmit" type="button" onClick="ffValidateForm(ffRequiredFields);" value="Submit" name="ffButtonSubmit"><input id="ffButtonCancel" type="button" onClick="ffHideForm();" value="Cancel" name="ffButtonCancel"></td>'
        + '				</tr>'
        + '			</table>'
        + '		</form>'
        + ''

        + '</div>';


    var divFeedbackFormBlocker = document.createElement('div');
    divFeedbackFormBlocker.id = "feedBackFormBlocker";
    document.body.appendChild(divFeedbackFormBlocker);

    var divFeedbackFormAdd = document.createElement('div');
    divFeedbackFormAdd.id = "feedBackFormContainer";
    divFeedbackFormAdd.innerHTML = codeFeedbackForm;

    document.body.appendChild(divFeedbackFormAdd);

    ffLabelRequired(ffRequiredFields);

}

function ffGetProduct()
{
    //This will check the path to see what part of edocs the user is on
    var currPath = window.location.pathname;
    var matchedProduct = '';

    var i;
    var sfProduct ='';
    //Look up SF product in edocsULR to SF Product mapping table
    for (i = 0; i < ffedocsPagetoSFProdData.length; i++) {
        if (currPath.indexOf(ffedocsPagetoSFProdData[i][0]) > -1 ) {
            sfProduct = ffedocsPagetoSFProdData[i][1];
            break;
        }
    }

    if (sfProduct == '')
    {
        return sfProduct;
    }

    var matchedProduct = '';
    //Double check to sure product calculated in the the approved list of SF Products
    for(var j=0; j<ffProductValueArray.length; j++)
    {
        var currSection =  ffProductValueArray[j];

        if(sfProduct === ffProductValueArray[j])
        {
            return ffProductValueArray[j];
        }
    }

    return matchedProduct;
}

//When the page loads, add the support button *not needed for eDocs*
/*
 window.onload = function() {
 ffAddFeedbackButton();
 }
 */
window.onload = function() {
    //Load the common css
    ffLoadCss(ffCommonCssFile,null);
    ffLoadFont();
}
