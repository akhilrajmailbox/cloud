_satellite.pushAsyncScript(function(event, target, $variables){
  //listens for the unload browser event to occur and fires a direct call rule
if (typeof jQuery !== 'undefined') {
  var pageHeight = jQuery(document).height();
  var viewportHeight = jQuery(window).height();
  var initialPercent = viewportHeight / pageHeight;
  if (initialPercent > 1) {
    initialPercent = 100;
  } else {
    initialPercent = Math.round(initialPercent * 100);
  }
  var maxScroll = initialPercent;
  var scrollPercent = 0;
  jQuery(window).scroll(function() {
    var s = jQuery(window).scrollTop(),
      d = jQuery(document).height(),
      c = jQuery(window).height();
    scrollPercent = (s / (d - c)) * 100;
    if (scrollPercent > maxScroll) {
      maxScroll = scrollPercent;
    }
  });

  jQuery(window).on('beforeunload', function(e) {
    var interval = 25; //set the interval here
    var intervalLevel = Math.floor(maxScroll / interval) * interval;
    _satellite.setVar('scrollInterval', intervalLevel);
    _satellite.track('percent_page_scroll');
  });
}
});
