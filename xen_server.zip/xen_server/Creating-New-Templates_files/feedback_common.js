/**
 * feedback_common.js
 * This file contains shared elements used in the feedback forms
 * This is used in conjunction with another custom FeedbackForm.js file which includes variables that this file will use
 * ffApplicationEnv
 * ffShowForm
 */

var ffHost = window.location.host;
var ffButtonText = "Need Support?";
var ffJsHost = "//www.citrix.com/static/";
var ffDevHost = "localhost:88";
var ffBrowser = ffDetectBrowser();

//Default values that can be overwritten

var ffFieldId_qa = {
    appEnv:"qa",
    formAction:"https://cs18.salesforce.com/servlet/servlet.WebToCase?encoding=UTF-8",
    orgId:"00DK000000W4wxg",
    myAccountLogin:"00N60000001Hlok",
    envId:"00N60000002oB6K",
    caseRecordType:"01260000000JC9M",
    webUrl:"00N60000002oB6L",
    source:"00N300000013SFk",
    browser:"00N60000002oB6j",
    webSite:"00N60000002oB6M",
    product:"00N60000002oB6M"
};

var ffFieldId_prod = {
    appEnv:"prod",
    formAction:"https://www.salesforce.com/servlet/servlet.WebToCase?encoding=UTF-8",
    orgId:"00D300000006M9V",
    myAccountLogin:"00N60000001Hlok",
    envId:"00N60000002oB6K",
    caseRecordType:"01260000000JC9M",
    webUrl:"00N60000002oB6L",
    source:"00N300000013SFk",
    browser:"00N60000002oB6j",
    webSite:"00N60000002oB6M",
    product:"00N300000013SFx"
};
//used to determine the product for sites like edocs. DO NOT CHANGE THE ORDER!
var ffProductValueArray = [
    "AppDNA",
    "ByteMobile",
    "Citrix Online",
    "Citrix Receiver",
    "CloudBridge (formerly Branch Repeater)",
    "CloudPlatform",
    "CloudPortal Business Manager",
    "CloudPortal Services Manager",
    "EdgeSight",
    "NetScaler",
    "NetScaler Gateway (formerly Access Gateway)",
    "ShareFile",
    "VDI-in-a-Box",
    "XenApp",
    "XenClient",
    "XenDesktop",
    "XenMobile",
    "XenServer",
    "Other Product",
    "Non-Product Related"
];

/* Replacement for the kampyle function */
var k_button = {};
k_button.open_ff = function(str)
{
    var formVal = null;
    if(str && str.indexOf("[navLevel1]="))
    {
        var matches = str.match(/\[navLevel1\]=([0-9]+)/);
        formVal = (matches)? matches[1] : "";
    }
    ffShowForm(formVal);
}

/* FUNCTION FOR CLOSING MODAL */
function ffHideForm(callback) {
    var divFeedbackFormRemove = document.getElementById('feedBackFormContainer');
    document.body.removeChild(divFeedbackFormRemove);

    var divFeedbackFormBlocker = document.getElementById('feedBackFormBlocker');
    document.body.removeChild(divFeedbackFormBlocker);

    if(callback)
    {
        callback();
    }
}

/*FUNCTION TO ADD FEEDBACK BUTTON */
function ffAddFeedbackButton() {
    var divFeedbackButtonContainerFull = document.createElement('div');
    divFeedbackButtonContainerFull.id = "feedbackButtonContainerFull";

    var divFeedbackButtonContainer = document.createElement('div');
    divFeedbackButtonContainer.id = "feedbackButtonContainer";

    var divFeedbackButton = document.createElement('div');
    divFeedbackButton.id = "feedbackOpenButton";
    divFeedbackButton.onclick = function()
    {
        ffShowForm();
    }

    var divFeedbackButtonSpan = document.createElement('span');
    divFeedbackButtonSpan.innerHTML = ffButtonText;

    document.body.appendChild(divFeedbackButtonContainerFull);
    divFeedbackButtonContainerFull.appendChild(divFeedbackButtonContainer);
    divFeedbackButtonContainer.appendChild(divFeedbackButton);
    divFeedbackButton.appendChild(divFeedbackButtonSpan);
}

/*FUNCTION TO LOAD THE FONT IF THE FEEDBACK BUTTON IS OMITTED */
function ffLoadFont() {
    var feedbackFontLoader = document.createElement('div');
    feedbackFontLoader.id = "feedbackFontLoader";
    feedbackFontLoader.innerHTML = ".";

    document.body.appendChild(feedbackFontLoader);
}

/* VALIDATION FOR FEEDBACK FORM REQUIRED FIELDS */
function ffValidateForm(fields) {
    //name, type, email
    var isValid = true;
    var validEmail = true;
    try{
        var ffFields = document.getElementsByClassName('ffField');
    }
    catch(e)
    {
        var ffFields = document.querySelectorAll('.ffField');
    }
    for (var j in ffFields)
    {
        var currField = ffFields[j];
        for (var i in fields){
            if(currField.id == fields[i])
            {
                var currFieldVal = currField.value;
                if(currField.id == 'email')
                {
                    validEmail = ffValidateEmail(currFieldVal);
                }
                else
                {
                    if(!currFieldVal)
                    {
                        isValid = false;
                    }
                }
            }
        }
    }

    if(isValid && validEmail)
    {
        document.getElementById("jsSalesForceFeedback").submit();
    }
    else
    {
        if(!isValid)
        {
            alert('One or more required fields were not filled out, please complete all required fields before submitting.');
        }
        else if(!validEmail)
        {
            alert("Please enter a valid email");

        }

        return false;
    }
}
/* Does simple validation on an email address */
function ffValidateEmail(email)
{
    atpos = email.indexOf("@");
    dotpos = email.lastIndexOf(".");
    if (atpos < 1 || ( dotpos - atpos < 2 ))
    {
        return false;
    }
    return( true );
}
/* Adds the "required" style to a label */
function ffLabelRequired(fields)
{
    if(fields.length > 0)
    {
        var labels = document.getElementsByTagName("label");
        for (var j in labels){
            if(labels[j] && typeof labels[j] == "object"){
                var currAtt = labels[j].getAttribute("for");
                for (var i in fields){
                    if(currAtt == fields[i])
                    {
                        //<span class="requiredField">*</span>
                        var reqSpan = document.createElement('span');
                        reqSpan.className = "requiredField";
                        reqSpan.innerHTML = " *";

                        labels[j].appendChild(reqSpan);
                    }
                }
            }
        }
    }
}
/* Removes the "required" style from a label */
function ffLabelNotRequired(fields)
{
    if(fields.length > 0)
    {
        var labels = document.getElementsByTagName("label");
        for (var j in labels){
            if(labels[j] && typeof labels[j] == "object"){
                var currAtt = labels[j].getAttribute("for");
                for (var i in fields){
                    if(currAtt == fields[i])
                    {
                        //<span class="requiredField">*</span>
                        var reqSpan = labels[j].getElementsByTagName('span')[0];
                        if(reqSpan)
                        {
                            labels[j].removeChild(reqSpan);
                        }
                    }
                }
            }
        }
    }
}

/* Makes fields read only */
function ffFieldsReadOnly(fields)
{
    if(fields.length > 0)
    {
        for (var i in fields){
            document.getElementById(fields[i]).readOnly = true;
        }
    }
}
/* loads a script */
function ffLoadScript(url, callback)
{
    // Adding the script tag to the head
    var head = document.getElementsByTagName('head')[0];
    var script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = url;

    if(callback)
    {
        //IE load event
        script.onreadystatechange = callback;
        //Other browser load event
        script.onload = callback;
    }
    // Fire the loading
    head.appendChild(script);
}
/* loads a css */
function ffLoadCss(url, callback)
{
    // Adding the css tag to the head
    var head = document.getElementsByTagName('head')[0];
    var css = document.createElement('link');
    css.type = 'text/css';
    css.rel = 'stylesheet';
    css.href = url;

    if(callback)
    {
        //IE load event
        css.onreadystatechange = callback;
        //Other browser load event
        css.onload = callback;
    }
    // Fire the loading
    head.appendChild(css);
}
/* Sets the default width of the longest column to allow room for a required field (when the required field is dynamic) */
function ffAdjustColWidth()
{
    try{
        var columns = document.getElementsByClassName("long-title");
        for (var j in columns){
            var currCol = columns[j];
            if(currCol && typeof currCol == "object"){
                var newWidth = currCol.offsetWidth + 10;
                currCol.setAttribute("style","width:"+newWidth+"px");
                currCol.style.width = newWidth+'px';
            }
        }
    }catch(e){}
}

//Browser detection
function ffDetectBrowser()
{
    var objappVersion = navigator.appVersion;
    var objAgent = navigator.userAgent;
    var objbrowserName = navigator.appName;
    var objfullVersion = '' + parseFloat(navigator.appVersion);
    var objBrMajorVersion = parseInt(navigator.appVersion, 10);
    var objOffsetName, objOffsetVersion, ix;
    // In Chrome
    if ((objOffsetVersion = objAgent.indexOf("Chrome")) != -1) {
        objbrowserName = "Chrome";
        objfullVersion = objAgent.substring(objOffsetVersion + 7);
    }
    // In Microsoft internet explorer
    else if ((objOffsetVersion = objAgent.indexOf("MSIE")) != -1) {
        objbrowserName = "Microsoft Internet Explorer";
        objfullVersion = objAgent.substring(objOffsetVersion + 5);
    }
    // In Microsoft internet explorer 11
    else if ((objOffsetVersion = objAgent.indexOf("Trident")) != -1) {
        objbrowserName = "Microsoft Internet Explorer";
        objOffsetVersion = objAgent.indexOf("rv:");
        objfullVersion = objAgent.substring(objOffsetVersion + 3, objAgent.lastIndexOf(")"));
    }
    // In Firefox
    else if ((objOffsetVersion = objAgent.indexOf("Firefox")) != -1) {
        objbrowserName = "Firefox";
    }
    // In Safari
    else if ((objOffsetVersion = objAgent.indexOf("Safari")) != -1) {
        objbrowserName = "Safari";
        objfullVersion = objAgent.substring(objOffsetVersion + 7);
        if ((objOffsetVersion = objAgent.indexOf("Version")) != -1) objfullVersion = objAgent.substring(objOffsetVersion + 8);
    }
    // For other browser "name/version" is at the end of userAgent
    else if ((objOffsetName = objAgent.lastIndexOf(' ') + 1) < (objOffsetVersion = objAgent.lastIndexOf('/'))) {
        objbrowserName = objAgent.substring(objOffsetName, objOffsetVersion);
        objfullVersion = objAgent.substring(objOffsetVersion + 1);
        if (objbrowserName.toLowerCase() == objbrowserName.toUpperCase()) {
            objbrowserName = navigator.appName;
        }
    }
    // trimming the fullVersion string at semicolon/space if present
    if ((ix = objfullVersion.indexOf(";")) != -1) objfullVersion = objfullVersion.substring(0, ix);
    if ((ix = objfullVersion.indexOf(" ")) != -1) objfullVersion = objfullVersion.substring(0, ix);
    objBrMajorVersion = parseInt('' + objfullVersion, 10);
    if (isNaN(objBrMajorVersion)) {
        objfullVersion = '' + parseFloat(navigator.appVersion);
        objBrMajorVersion = parseInt(navigator.appVersion, 10);
    }

    return objbrowserName + ' ' + objBrMajorVersion;
}





