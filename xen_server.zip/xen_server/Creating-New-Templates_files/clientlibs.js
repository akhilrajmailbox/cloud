window.Modernizr=function(at,ae,aj){function ag(a){aw.cssText=a
}function ai(b,a){return ag(B.join(b+";")+(a||""))
}function ax(b,a){return typeof b===a
}function ao(b,a){return !!~(""+b).indexOf(a)
}function av(c,a){for(var b in c){var d=c[b];
if(!ao(d,"-")&&aw[d]!==aj){return"pfx"==a?d:!0
}}return !1
}function af(d,b,c){for(var f in d){var a=b[d[f]];
if(a!==aj){return c===!1?d[f]:ax(a,"function")?a.bind(c||b):a
}}return !1
}function ad(c,a,f){var b=c.charAt(0).toUpperCase()+c.slice(1),d=(c+" "+am.join(b+" ")+b).split(" ");
return ax(a,"string")||ax(a,"undefined")?av(d,a):(d=(c+" "+q.join(b+" ")+b).split(" "),af(d,a,f))
}function al(){ah.input=function(c){for(var a=0,b=c.length;
b>a;
a++){an[c[a]]=!!(c[a] in R)
}return an.list&&(an.list=!(!ae.createElement("datalist")||!at.HTMLDataListElement)),an
}("autocomplete autofocus list placeholder max min multiple pattern required step".split(" ")),ah.inputtypes=function(g){for(var f,h,b,d=0,j=g.length;
j>d;
d++){R.setAttribute("type",h=g[d]),f="text"!==R.type,f&&(R.value=aa,R.style.cssText="position:absolute;visibility:hidden;",/^range$/.test(h)&&R.style.WebkitAppearance!==aj?(aq.appendChild(R),b=ae.defaultView,f=b.getComputedStyle&&"textfield"!==b.getComputedStyle(R,null).WebkitAppearance&&0!==R.offsetHeight,aq.removeChild(R)):/^(search|tel)$/.test(h)||(f=/^(url|email)$/.test(h)?R.checkValidity&&R.checkValidity()===!1:R.value!=aa)),G[g[d]]=!!f
}return G
}("search tel url email datetime date month week time datetime-local number range color".split(" "))
}var au,ar,ak="2.8.3",ah={},ap=!0,aq=ae.documentElement,ac="modernizr",Z=ae.createElement(ac),aw=Z.style,R=ae.createElement("input"),aa=":)",ab={}.toString,B=" -webkit- -moz- -o- -ms- ".split(" "),V="Webkit Moz O ms",am=V.split(" "),q=V.toLowerCase().split(" "),I={svg:"http://www.w3.org/2000/svg"},J={},G={},an={},X=[],U=X.slice,Q=function(k,g,b,f){var t,j,p,w,v=ae.createElement("div"),h=ae.body,m=h||ae.createElement("body");
if(parseInt(b,10)){for(;
b--;
){p=ae.createElement("div"),p.id=f?f[b]:ac+(b+1),v.appendChild(p)
}}return t=["&#173;",'<style id="s',ac,'">',k,"</style>"].join(""),v.id=ac,(h?v:m).innerHTML+=t,m.appendChild(v),h||(m.style.background="",m.style.overflow="hidden",w=aq.style.overflow,aq.style.overflow="hidden",aq.appendChild(m)),j=g(v,k),h?v.parentNode.removeChild(v):(m.parentNode.removeChild(m),aq.style.overflow=w),!!j
},Y=function(a){var c=at.matchMedia||at.msMatchMedia;
if(c){return c(a)&&c(a).matches||!1
}var b;
return Q("@media "+a+" { #"+ac+" { position: absolute; } }",function(d){b="absolute"==(at.getComputedStyle?getComputedStyle(d,null):d.currentStyle).position
}),b
},W=function(){function b(d,f){f=f||ae.createElement(a[d]||"div"),d="on"+d;
var c=d in f;
return c||(f.setAttribute||(f=ae.createElement("div")),f.setAttribute&&f.removeAttribute&&(f.setAttribute(d,""),c=ax(f[d],"function"),ax(f[d],"undefined")||(f[d]=aj),f.removeAttribute(d))),f=null,c
}var a={select:"input",change:"input",submit:"form",reset:"form",error:"img",load:"img",abort:"img"};
return b
}(),K={}.hasOwnProperty;
ar=ax(K,"undefined")||ax(K.call,"undefined")?function(b,a){return a in b&&ax(b.constructor.prototype[a],"undefined")
}:function(b,a){return K.call(b,a)
},Function.prototype.bind||(Function.prototype.bind=function(c){var a=this;
if("function"!=typeof a){throw new TypeError
}var d=U.call(arguments,1),b=function(){if(this instanceof b){var g=function(){};
g.prototype=a.prototype;
var e=new g,f=a.apply(e,d.concat(U.call(arguments)));
return Object(f)===f?f:e
}return a.apply(c,d.concat(U.call(arguments)))
};
return b
}),J.flexbox=function(){return ad("flexWrap")
},J.flexboxlegacy=function(){return ad("boxDirection")
},J.canvas=function(){var a=ae.createElement("canvas");
return !(!a.getContext||!a.getContext("2d"))
},J.canvastext=function(){return !(!ah.canvas||!ax(ae.createElement("canvas").getContext("2d").fillText,"function"))
},J.webgl=function(){return !!at.WebGLRenderingContext
},J.touch=function(){var a;
return"ontouchstart" in at||at.DocumentTouch&&ae instanceof DocumentTouch?a=!0:Q(["@media (",B.join("touch-enabled),("),ac,")","{#modernizr{top:9px;position:absolute}}"].join(""),function(b){a=9===b.offsetTop
}),a
},J.geolocation=function(){return"geolocation" in navigator
},J.postmessage=function(){return !!at.postMessage
},J.websqldatabase=function(){return !!at.openDatabase
},J.indexedDB=function(){return !!ad("indexedDB",at)
},J.hashchange=function(){return W("hashchange",at)&&(ae.documentMode===aj||ae.documentMode>7)
},J.history=function(){return !(!at.history||!history.pushState)
},J.draganddrop=function(){var a=ae.createElement("div");
return"draggable" in a||"ondragstart" in a&&"ondrop" in a
},J.websockets=function(){return"WebSocket" in at||"MozWebSocket" in at
},J.rgba=function(){return ag("background-color:rgba(150,255,150,.5)"),ao(aw.backgroundColor,"rgba")
},J.hsla=function(){return ag("background-color:hsla(120,40%,100%,.5)"),ao(aw.backgroundColor,"rgba")||ao(aw.backgroundColor,"hsla")
},J.multiplebgs=function(){return ag("background:url(https://),url(https://),red url(https://)"),/(url\s*\(.*?){3}/.test(aw.background)
},J.backgroundsize=function(){return ad("backgroundSize")
},J.borderimage=function(){return ad("borderImage")
},J.borderradius=function(){return ad("borderRadius")
},J.boxshadow=function(){return ad("boxShadow")
},J.textshadow=function(){return""===ae.createElement("div").style.textShadow
},J.opacity=function(){return ai("opacity:.55"),/^0.55$/.test(aw.opacity)
},J.cssanimations=function(){return ad("animationName")
},J.csscolumns=function(){return ad("columnCount")
},J.cssgradients=function(){var b="background-image:",a="gradient(linear,left top,right bottom,from(#9f9),to(white));",c="linear-gradient(left top,#9f9, white);";
return ag((b+"-webkit- ".split(" ").join(a+b)+B.join(c+b)).slice(0,-b.length)),ao(aw.backgroundImage,"gradient")
},J.cssreflections=function(){return ad("boxReflect")
},J.csstransforms=function(){return !!ad("transform")
},J.csstransforms3d=function(){var a=!!ad("perspective");
return a&&"webkitPerspective" in aq.style&&Q("@media (transform-3d),(-webkit-transform-3d){#modernizr{left:9px;position:absolute;height:3px;}}",function(b){a=9===b.offsetLeft&&3===b.offsetHeight
}),a
},J.csstransitions=function(){return ad("transition")
},J.fontface=function(){var a;
return Q('@font-face {font-family:"font";src:url("https://")}',function(f,d){var e=ae.getElementById("smodernizr"),b=e.sheet||e.styleSheet,c=b?b.cssRules&&b.cssRules[0]?b.cssRules[0].cssText:b.cssText||"":"";
a=/src/i.test(c)&&0===c.indexOf(d.split(" ")[0])
}),a
},J.generatedcontent=function(){var a;
return Q(["#",ac,"{font:0/0 a}#",ac,':after{content:"',aa,'";visibility:hidden;font:3px/1 a}'].join(""),function(b){a=b.offsetHeight>=3
}),a
},J.video=function(){var b=ae.createElement("video"),c=!1;
try{(c=!!b.canPlayType)&&(c=new Boolean(c),c.ogg=b.canPlayType('video/ogg; codecs="theora"').replace(/^no$/,""),c.h264=b.canPlayType('video/mp4; codecs="avc1.42E01E"').replace(/^no$/,""),c.webm=b.canPlayType('video/webm; codecs="vp8, vorbis"').replace(/^no$/,""))
}catch(a){}return c
},J.audio=function(){var b=ae.createElement("audio"),c=!1;
try{(c=!!b.canPlayType)&&(c=new Boolean(c),c.ogg=b.canPlayType('audio/ogg; codecs="vorbis"').replace(/^no$/,""),c.mp3=b.canPlayType("audio/mpeg;").replace(/^no$/,""),c.wav=b.canPlayType('audio/wav; codecs="1"').replace(/^no$/,""),c.m4a=(b.canPlayType("audio/x-m4a;")||b.canPlayType("audio/aac;")).replace(/^no$/,""))
}catch(a){}return c
},J.localstorage=function(){try{return localStorage.setItem(ac,ac),localStorage.removeItem(ac),!0
}catch(a){return !1
}},J.sessionstorage=function(){try{return sessionStorage.setItem(ac,ac),sessionStorage.removeItem(ac),!0
}catch(a){return !1
}},J.webworkers=function(){return !!at.Worker
},J.applicationcache=function(){return !!at.applicationCache
},J.svg=function(){return !!ae.createElementNS&&!!ae.createElementNS(I.svg,"svg").createSVGRect
},J.inlinesvg=function(){var a=ae.createElement("div");
return a.innerHTML="<svg/>",(a.firstChild&&a.firstChild.namespaceURI)==I.svg
},J.smil=function(){return !!ae.createElementNS&&/SVGAnimate/.test(ab.call(ae.createElementNS(I.svg,"animate")))
},J.svgclippaths=function(){return !!ae.createElementNS&&/SVGClipPath/.test(ab.call(ae.createElementNS(I.svg,"clipPath")))
};
for(var O in J){ar(J,O)&&(au=O.toLowerCase(),ah[au]=J[O](),X.push((ah[au]?"":"no-")+au))
}return ah.input||al(),ah.addTest=function(c,a){if("object"==typeof c){for(var b in c){ar(c,b)&&ah.addTest(b,c[b])
}}else{if(c=c.toLowerCase(),ah[c]!==aj){return ah
}a="function"==typeof a?a():a,"undefined"!=typeof ap&&ap&&(aq.className+=" "+(a?"":"no-")+c),ah[c]=a
}return ah
},ag(""),Z=R=null,function(P,w){function D(d,a){var f=d.createElement("p"),c=d.getElementsByTagName("head")[0]||d.documentElement;
return f.innerHTML="x<style>"+a+"</style>",c.insertBefore(f.lastChild,c.firstChild)
}function z(){var a=b.elements;
return"string"==typeof a?a.split(" "):a
}function C(c){var a=j[c[L]];
return a||(a={},M++,c[L]=M,j[M]=a),a
}function ay(f,g,d){if(g||(g=w),F){return g.createElement(f)
}d||(d=C(g));
var c;
return c=d.cache[f]?d.cache[f].cloneNode():A.test(f)?(d.cache[f]=d.createElem(f)).cloneNode():d.createElem(f),!c.canHaveChildren||E.test(f)||c.tagUrn?c:d.frag.appendChild(c)
}function H(h,m){if(h||(h=w),F){return h.createDocumentFragment()
}m=m||C(h);
for(var d=m.frag.cloneNode(),f=0,l=z(),g=l.length;
g>f;
f++){d.createElement(l[f])
}return d
}function T(c,a){a.cache||(a.cache={},a.createElem=c.createElement,a.createFrag=c.createDocumentFragment,a.frag=a.createFrag()),c.createElement=function(d){return b.shivMethods?ay(d,c,a):a.createElem(d)
},c.createDocumentFragment=Function("h,f","return function(){var n=f.cloneNode(),c=n.createElement;h.shivMethods&&("+z().join().replace(/[\w\-]+/g,function(d){return a.createElem(d),a.frag.createElement(d),'c("'+d+'")'
})+");return n}")(b,a.frag)
}function x(c){c||(c=w);
var a=C(c);
return !b.shivCSS||k||a.hasCSS||(a.hasCSS=!!D(c,"article,aside,dialog,figcaption,figure,footer,header,hgroup,main,nav,section{display:block}mark{background:#FF0;color:#000}template{display:none}")),F||T(c,a),c
}var k,F,S="3.7.0",N=P.html5||{},E=/^<|^(?:button|map|select|textarea|object|iframe|option|optgroup)$/i,A=/^(?:a|b|code|div|fieldset|h1|h2|h3|h4|h5|h6|i|label|li|ol|p|q|span|strong|style|table|tbody|td|th|tr|ul)$/i,L="_html5shiv",M=0,j={};
!function(){try{var a=w.createElement("a");
a.innerHTML="<xyz></xyz>",k="hidden" in a,F=1==a.childNodes.length||function(){w.createElement("a");
var d=w.createDocumentFragment();
return"undefined"==typeof d.cloneNode||"undefined"==typeof d.createDocumentFragment||"undefined"==typeof d.createElement
}()
}catch(c){k=!0,F=!0
}}();
var b={elements:N.elements||"abbr article aside audio bdi canvas data datalist details dialog figcaption figure footer header hgroup main mark meter nav output progress section summary template time video",version:S,shivCSS:N.shivCSS!==!1,supportsUnknownElements:F,shivMethods:N.shivMethods!==!1,type:"default",shivDocument:x,createElement:ay,createDocumentFragment:H};
P.html5=b,x(w)
}(this,ae),ah._version=ak,ah._prefixes=B,ah._domPrefixes=q,ah._cssomPrefixes=am,ah.mq=Y,ah.hasEvent=W,ah.testProp=function(a){return av([a])
},ah.testAllProps=ad,ah.testStyles=Q,ah.prefixed=function(b,a,c){return a?ad(b,a,c):ad(b,"pfx")
},aq.className=aq.className.replace(/(^|\s)no-js(\s|$)/,"$1$2")+(ap?" js "+X.join(" "):""),ah
}(this,this.document);
/*!
 * Bootstrap v3.2.0 (http://getbootstrap.com)
 * Copyright 2011-2014 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
 */
if("undefined"==typeof jQuery){throw new Error("Bootstrap's JavaScript requires jQuery")
}+function(d){function c(){var f=document.createElement("bootstrap"),e={WebkitTransition:"webkitTransitionEnd",MozTransition:"transitionend",OTransition:"oTransitionEnd otransitionend",transition:"transitionend"};
for(var g in e){if(void 0!==f.style[g]){return{end:e[g]}
}}return !1
}d.fn.emulateTransitionEnd=function(a){var h=!1,g=this;
d(this).one("bsTransitionEnd",function(){h=!0
});
var f=function(){h||d(g).trigger(d.support.transition.end)
};
return setTimeout(f,a),this
},d(function(){d.support.transition=c(),d.support.transition&&(d.event.special.bsTransitionEnd={bindType:d.support.transition.end,delegateType:d.support.transition.end,handle:function(a){return d(a.target).is(this)?a.handleObj.handler.apply(this,arguments):void 0
}})
})
}(jQuery),+function(g){function f(a){return this.each(function(){var d=g(this),b=d.data("bs.alert");
b||d.data("bs.alert",b=new j(this)),"string"==typeof a&&b[a].call(d)
})
}var k='[data-dismiss="alert"]',j=function(a){g(a).on("click",k,this.close)
};
j.VERSION="3.2.0",j.prototype.close=function(a){function o(){l.detach().trigger("closed.bs.alert").remove()
}var n=g(this),m=n.attr("data-target");
m||(m=n.attr("href"),m=m&&m.replace(/.*(?=#[^\s]*$)/,""));
var l=g(m);
a&&a.preventDefault(),l.length||(l=n.hasClass("alert")?n:n.parent()),l.trigger(a=g.Event("close.bs.alert")),a.isDefaultPrevented()||(l.removeClass("in"),g.support.transition&&l.hasClass("fade")?l.one("bsTransitionEnd",o).emulateTransitionEnd(150):o())
};
var h=g.fn.alert;
g.fn.alert=f,g.fn.alert.Constructor=j,g.fn.alert.noConflict=function(){return g.fn.alert=h,this
},g(document).on("click.bs.alert.data-api",k,j.prototype.close)
}(jQuery),+function(f){function e(a){return this.each(function(){var j=f(this),c=j.data("bs.button"),b="object"==typeof a&&a;
c||j.data("bs.button",c=new h(this,b)),"toggle"==a?c.toggle():a&&c.setState(a)
})
}var h=function(a,c){this.$element=f(a),this.options=f.extend({},h.DEFAULTS,c),this.isLoading=!1
};
h.VERSION="3.2.0",h.DEFAULTS={loadingText:"loading..."},h.prototype.setState=function(a){var m="disabled",l=this.$element,k=l.is("input")?"val":"html",j=l.data();
a+="Text",null==j.resetText&&l.data("resetText",l[k]()),l[k](null==j[a]?this.options[a]:j[a]),setTimeout(f.proxy(function(){"loadingText"==a?(this.isLoading=!0,l.addClass(m).attr(m,m)):this.isLoading&&(this.isLoading=!1,l.removeClass(m).removeAttr(m))
},this),0)
},h.prototype.toggle=function(){var j=!0,d=this.$element.closest('[data-toggle="buttons"]');
if(d.length){var k=this.$element.find("input");
"radio"==k.prop("type")&&(k.prop("checked")&&this.$element.hasClass("active")?j=!1:d.find(".active").removeClass("active")),j&&k.prop("checked",!this.$element.hasClass("active")).trigger("change")
}j&&this.$element.toggleClass("active")
};
var g=f.fn.button;
f.fn.button=e,f.fn.button.Constructor=h,f.fn.button.noConflict=function(){return f.fn.button=g,this
},f(document).on("click.bs.button.data-api",'[data-toggle^="button"]',function(b){var a=f(b.target);
a.hasClass("btn")||(a=a.closest(".btn")),e.call(a,"toggle"),b.preventDefault()
})
}(jQuery),+function(f){function e(a){return this.each(function(){var k=f(this),j=k.data("bs.carousel"),c=f.extend({},h.DEFAULTS,k.data(),"object"==typeof a&&a),b="string"==typeof a?a:c.slide;
j||k.data("bs.carousel",j=new h(this,c)),"number"==typeof a?j.to(a):b?j[b]():c.interval&&j.pause().cycle()
})
}var h=function(a,d){this.$element=f(a).on("keydown.bs.carousel",f.proxy(this.keydown,this)),this.$indicators=this.$element.find(".carousel-indicators"),this.options=d,this.paused=this.sliding=this.interval=this.$active=this.$items=null,"hover"==this.options.pause&&this.$element.on("mouseenter.bs.carousel",f.proxy(this.pause,this)).on("mouseleave.bs.carousel",f.proxy(this.cycle,this))
};
h.VERSION="3.2.0",h.DEFAULTS={interval:5000,pause:"hover",wrap:!0},h.prototype.keydown=function(b){switch(b.which){case 37:this.prev();
break;
case 39:this.next();
break;
default:return
}b.preventDefault()
},h.prototype.cycle=function(a){return a||(this.paused=!1),this.interval&&clearInterval(this.interval),this.options.interval&&!this.paused&&(this.interval=setInterval(f.proxy(this.next,this),this.options.interval)),this
},h.prototype.getItemIndex=function(b){return this.$items=b.parent().children(".item"),this.$items.index(b||this.$active)
},h.prototype.to=function(a){var k=this,j=this.getItemIndex(this.$active=this.$element.find(".item.active"));
return a>this.$items.length-1||0>a?void 0:this.sliding?this.$element.one("slid.bs.carousel",function(){k.to(a)
}):j==a?this.pause().cycle():this.slide(a>j?"next":"prev",f(this.$items[a]))
},h.prototype.pause=function(a){return a||(this.paused=!0),this.$element.find(".next, .prev").length&&f.support.transition&&(this.$element.trigger(f.support.transition.end),this.cycle(!0)),this.interval=clearInterval(this.interval),this
},h.prototype.next=function(){return this.sliding?void 0:this.slide("next")
},h.prototype.prev=function(){return this.sliding?void 0:this.slide("prev")
},h.prototype.slide=function(x,w){var v=this.$element.find(".item.active"),u=w||v[x](),t=this.interval,s="next"==x?"left":"right",r="next"==x?"first":"last",q=this;
if(!u.length){if(!this.options.wrap){return
}u=this.$element.find(".item")[r]()
}if(u.hasClass("active")){return this.sliding=!1
}var p=u[0],o=f.Event("slide.bs.carousel",{relatedTarget:p,direction:s});
if(this.$element.trigger(o),!o.isDefaultPrevented()){if(this.sliding=!0,t&&this.pause(),this.$indicators.length){this.$indicators.find(".active").removeClass("active");
var n=f(this.$indicators.children()[this.getItemIndex(u)]);
n&&n.addClass("active")
}var a=f.Event("slid.bs.carousel",{relatedTarget:p,direction:s});
return f.support.transition&&this.$element.hasClass("slide")?(u.addClass(x),u[0].offsetWidth,v.addClass(s),u.addClass(s),v.one("bsTransitionEnd",function(){u.removeClass([x,s].join(" ")).addClass("active"),v.removeClass(["active",s].join(" ")),q.sliding=!1,setTimeout(function(){q.$element.trigger(a)
},0)
}).emulateTransitionEnd(1000*v.css("transition-duration").slice(0,-1))):(v.removeClass("active"),u.addClass("active"),this.sliding=!1,this.$element.trigger(a)),t&&this.cycle(),this
}};
var g=f.fn.carousel;
f.fn.carousel=e,f.fn.carousel.Constructor=h,f.fn.carousel.noConflict=function(){return f.fn.carousel=g,this
},f(document).on("click.bs.carousel.data-api","[data-slide], [data-slide-to]",function(m){var l,k=f(this),j=f(k.attr("data-target")||(l=k.attr("href"))&&l.replace(/.*(?=#[^\s]+$)/,""));
if(j.hasClass("carousel")){var b=f.extend({},j.data(),k.data()),a=k.attr("data-slide-to");
a&&(b.interval=!1),e.call(j,b),a&&j.data("bs.carousel").to(a),m.preventDefault()
}}),f(window).on("load",function(){f('[data-ride="carousel"]').each(function(){var a=f(this);
e.call(a,a.data())
})
})
}(jQuery),+function(f){function e(a){return this.each(function(){var j=f(this),c=j.data("bs.collapse"),b=f.extend({},h.DEFAULTS,j.data(),"object"==typeof a&&a);
!c&&b.toggle&&"show"==a&&(a=!a),c||j.data("bs.collapse",c=new h(this,b)),"string"==typeof a&&c[a]()
})
}var h=function(a,c){this.$element=f(a),this.options=f.extend({},h.DEFAULTS,c),this.transitioning=null,this.options.parent&&(this.$parent=f(this.options.parent)),this.options.toggle&&this.toggle()
};
h.VERSION="3.2.0",h.DEFAULTS={toggle:!0},h.prototype.dimension=function(){var b=this.$element.hasClass("width");
return b?"width":"height"
},h.prototype.show=function(){if(!this.transitioning&&!this.$element.hasClass("in")){var m=f.Event("show.bs.collapse");
if(this.$element.trigger(m),!m.isDefaultPrevented()){var l=this.$parent&&this.$parent.find("> .panel > .in");
if(l&&l.length){var k=l.data("bs.collapse");
if(k&&k.transitioning){return
}e.call(l,"hide"),k||l.data("bs.collapse",null)
}var j=this.dimension();
this.$element.removeClass("collapse").addClass("collapsing")[j](0),this.transitioning=1;
var b=function(){this.$element.removeClass("collapsing").addClass("collapse in")[j](""),this.transitioning=0,this.$element.trigger("shown.bs.collapse")
};
if(!f.support.transition){return b.call(this)
}var a=f.camelCase(["scroll",j].join("-"));
this.$element.one("bsTransitionEnd",f.proxy(b,this)).emulateTransitionEnd(350)[j](this.$element[0][a])
}}},h.prototype.hide=function(){if(!this.transitioning&&this.$element.hasClass("in")){var a=f.Event("hide.bs.collapse");
if(this.$element.trigger(a),!a.isDefaultPrevented()){var k=this.dimension();
this.$element[k](this.$element[k]())[0].offsetHeight,this.$element.addClass("collapsing").removeClass("collapse").removeClass("in"),this.transitioning=1;
var j=function(){this.transitioning=0,this.$element.trigger("hidden.bs.collapse").removeClass("collapsing").addClass("collapse")
};
return f.support.transition?void this.$element[k](0).one("bsTransitionEnd",f.proxy(j,this)).emulateTransitionEnd(350):j.call(this)
}}},h.prototype.toggle=function(){this[this.$element.hasClass("in")?"hide":"show"]()
};
var g=f.fn.collapse;
f.fn.collapse=e,f.fn.collapse.Constructor=h,f.fn.collapse.noConflict=function(){return f.fn.collapse=g,this
},f(document).on("click.bs.collapse.data-api",'[data-toggle="collapse"]',function(r){var q,p=f(this),o=p.attr("data-target")||r.preventDefault()||(q=p.attr("href"))&&q.replace(/.*(?=#[^\s]+$)/,""),n=f(o),m=n.data("bs.collapse"),l=m?"toggle":p.data(),b=p.attr("data-parent"),a=b&&f(b);
m&&m.transitioning||(a&&a.find('[data-toggle="collapse"][data-parent="'+b+'"]').not(p).addClass("collapsed"),p[n.hasClass("in")?"addClass":"removeClass"]("collapsed")),e.call(n,l)
})
}(jQuery),+function(k){function j(a){a&&3===a.which||(k(o).remove(),k(n).each(function(){var c=q(k(this)),b={relatedTarget:this};
c.hasClass("open")&&(c.trigger(a=k.Event("hide.bs.dropdown",b)),a.isDefaultPrevented()||c.removeClass("open").trigger("hidden.bs.dropdown",b))
}))
}function q(a){var f=a.attr("data-target");
f||(f=a.attr("href"),f=f&&/#[A-Za-z]/.test(f)&&f.replace(/.*(?=#[^\s]*$)/,""));
var e=f&&k(f);
return e&&e.length?e:a.parent()
}function p(a){return this.each(function(){var e=k(this),b=e.data("bs.dropdown");
b||e.data("bs.dropdown",b=new m(this)),"string"==typeof a&&b[a].call(e)
})
}var o=".dropdown-backdrop",n='[data-toggle="dropdown"]',m=function(a){k(a).on("click.bs.dropdown",this.toggle)
};
m.VERSION="3.2.0",m.prototype.toggle=function(s){var r=k(this);
if(!r.is(".disabled, :disabled")){var c=q(r),b=c.hasClass("open");
if(j(),!b){"ontouchstart" in document.documentElement&&!c.closest(".navbar-nav").length&&k('<div class="dropdown-backdrop"/>').insertAfter(k(this)).on("click",j);
var a={relatedTarget:this};
if(c.trigger(s=k.Event("show.bs.dropdown",a)),s.isDefaultPrevented()){return
}r.trigger("focus"),c.toggleClass("open").trigger("shown.bs.dropdown",a)
}return !1
}},m.prototype.keydown=function(a){if(/(38|40|27)/.test(a.keyCode)){var u=k(this);
if(a.preventDefault(),a.stopPropagation(),!u.is(".disabled, :disabled")){var t=q(u),s=t.hasClass("open");
if(!s||s&&27==a.keyCode){return 27==a.which&&t.find(n).trigger("focus"),u.trigger("click")
}var r=" li:not(.divider):visible a",f=t.find('[role="menu"]'+r+', [role="listbox"]'+r);
if(f.length){var c=f.index(f.filter(":focus"));
38==a.keyCode&&c>0&&c--,40==a.keyCode&&c<f.length-1&&c++,~c||(c=0),f.eq(c).trigger("focus")
}}}};
var l=k.fn.dropdown;
k.fn.dropdown=p,k.fn.dropdown.Constructor=m,k.fn.dropdown.noConflict=function(){return k.fn.dropdown=l,this
},k(document).on("click.bs.dropdown.data-api",j).on("click.bs.dropdown.data-api",".dropdown form",function(b){b.stopPropagation()
}).on("click.bs.dropdown.data-api",n,m.prototype.toggle).on("keydown.bs.dropdown.data-api",n+', [role="menu"], [role="listbox"]',m.prototype.keydown)
}(jQuery),+function(f){function e(a,c){return this.each(function(){var j=f(this),d=j.data("bs.modal"),b=f.extend({},h.DEFAULTS,j.data(),"object"==typeof a&&a);
d||j.data("bs.modal",d=new h(this,b)),"string"==typeof a?d[a](c):b.show&&d.show(c)
})
}var h=function(a,d){this.options=d,this.$body=f(document.body),this.$element=f(a),this.$backdrop=this.isShown=null,this.scrollbarWidth=0,this.options.remote&&this.$element.find(".modal-content").load(this.options.remote,f.proxy(function(){this.$element.trigger("loaded.bs.modal")
},this))
};
h.VERSION="3.2.0",h.DEFAULTS={backdrop:!0,keyboard:!0,show:!0},h.prototype.toggle=function(b){return this.isShown?this.hide():this.show(b)
},h.prototype.show=function(a){var k=this,j=f.Event("show.bs.modal",{relatedTarget:a});
this.$element.trigger(j),this.isShown||j.isDefaultPrevented()||(this.isShown=!0,this.checkScrollbar(),this.$body.addClass("modal-open"),this.setScrollbar(),this.escape(),this.$element.on("click.dismiss.bs.modal",'[data-dismiss="modal"]',f.proxy(this.hide,this)),this.backdrop(function(){var c=f.support.transition&&k.$element.hasClass("fade");
k.$element.parent().length||k.$element.appendTo(k.$body),k.$element.show().scrollTop(0),c&&k.$element[0].offsetWidth,k.$element.addClass("in").attr("aria-hidden",!1),k.enforceFocus();
var b=f.Event("shown.bs.modal",{relatedTarget:a});
c?k.$element.find(".modal-dialog").one("bsTransitionEnd",function(){k.$element.trigger("focus").trigger(b)
}).emulateTransitionEnd(300):k.$element.trigger("focus").trigger(b)
}))
},h.prototype.hide=function(a){a&&a.preventDefault(),a=f.Event("hide.bs.modal"),this.$element.trigger(a),this.isShown&&!a.isDefaultPrevented()&&(this.isShown=!1,this.$body.removeClass("modal-open"),this.resetScrollbar(),this.escape(),f(document).off("focusin.bs.modal"),this.$element.removeClass("in").attr("aria-hidden",!0).off("click.dismiss.bs.modal"),f.support.transition&&this.$element.hasClass("fade")?this.$element.one("bsTransitionEnd",f.proxy(this.hideModal,this)).emulateTransitionEnd(300):this.hideModal())
},h.prototype.enforceFocus=function(){f(document).off("focusin.bs.modal").on("focusin.bs.modal",f.proxy(function(b){this.$element[0]===b.target||this.$element.has(b.target).length||this.$element.trigger("focus")
},this))
},h.prototype.escape=function(){this.isShown&&this.options.keyboard?this.$element.on("keyup.dismiss.bs.modal",f.proxy(function(b){27==b.which&&this.hide()
},this)):this.isShown||this.$element.off("keyup.dismiss.bs.modal")
},h.prototype.hideModal=function(){var b=this;
this.$element.hide(),this.backdrop(function(){b.$element.trigger("hidden.bs.modal")
})
},h.prototype.removeBackdrop=function(){this.$backdrop&&this.$backdrop.remove(),this.$backdrop=null
},h.prototype.backdrop=function(a){var m=this,l=this.$element.hasClass("fade")?"fade":"";
if(this.isShown&&this.options.backdrop){var k=f.support.transition&&l;
if(this.$backdrop=f('<div class="modal-backdrop '+l+'" />').appendTo(this.$body),this.$element.on("click.dismiss.bs.modal",f.proxy(function(b){b.target===b.currentTarget&&("static"==this.options.backdrop?this.$element[0].focus.call(this.$element[0]):this.hide.call(this))
},this)),k&&this.$backdrop[0].offsetWidth,this.$backdrop.addClass("in"),!a){return
}k?this.$backdrop.one("bsTransitionEnd",a).emulateTransitionEnd(150):a()
}else{if(!this.isShown&&this.$backdrop){this.$backdrop.removeClass("in");
var j=function(){m.removeBackdrop(),a&&a()
};
f.support.transition&&this.$element.hasClass("fade")?this.$backdrop.one("bsTransitionEnd",j).emulateTransitionEnd(150):j()
}else{a&&a()
}}},h.prototype.checkScrollbar=function(){document.body.clientWidth>=window.innerWidth||(this.scrollbarWidth=this.scrollbarWidth||this.measureScrollbar())
},h.prototype.setScrollbar=function(){var b=parseInt(this.$body.css("padding-right")||0,10);
this.scrollbarWidth&&this.$body.css("padding-right",b+this.scrollbarWidth)
},h.prototype.resetScrollbar=function(){this.$body.css("padding-right","")
},h.prototype.measureScrollbar=function(){var d=document.createElement("div");
d.className="modal-scrollbar-measure",this.$body.append(d);
var c=d.offsetWidth-d.clientWidth;
return this.$body[0].removeChild(d),c
};
var g=f.fn.modal;
f.fn.modal=e,f.fn.modal.Constructor=h,f.fn.modal.noConflict=function(){return f.fn.modal=g,this
},f(document).on("click.bs.modal.data-api",'[data-toggle="modal"]',function(l){var k=f(this),j=k.attr("href"),b=f(k.attr("data-target")||j&&j.replace(/.*(?=#[^\s]+$)/,"")),a=b.data("bs.modal")?"toggle":f.extend({remote:!/#/.test(j)&&j},b.data(),k.data());
k.is("a")&&l.preventDefault(),b.one("show.bs.modal",function(c){c.isDefaultPrevented()||b.one("hidden.bs.modal",function(){k.is(":visible")&&k.trigger("focus")
})
}),e.call(b,a,this)
})
}(jQuery),+function(f){function e(a){return this.each(function(){var j=f(this),c=j.data("bs.tooltip"),b="object"==typeof a&&a;
(c||"destroy"!=a)&&(c||j.data("bs.tooltip",c=new h(this,b)),"string"==typeof a&&c[a]())
})
}var h=function(d,c){this.type=this.options=this.enabled=this.timeout=this.hoverState=this.$element=null,this.init("tooltip",d,c)
};
h.VERSION="3.2.0",h.DEFAULTS={animation:!0,placement:"top",selector:!1,template:'<div class="tooltip" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>',trigger:"hover focus",title:"",delay:0,html:!1,container:!1,viewport:{selector:"body",padding:0}},h.prototype.init=function(a,p,o){this.enabled=!0,this.type=a,this.$element=f(p),this.options=this.getOptions(o),this.$viewport=this.options.viewport&&f(this.options.viewport.selector||this.options.viewport);
for(var n=this.options.trigger.split(" "),m=n.length;
m--;
){var l=n[m];
if("click"==l){this.$element.on("click."+this.type,this.options.selector,f.proxy(this.toggle,this))
}else{if("manual"!=l){var k="hover"==l?"mouseenter":"focusin",j="hover"==l?"mouseleave":"focusout";
this.$element.on(k+"."+this.type,this.options.selector,f.proxy(this.enter,this)),this.$element.on(j+"."+this.type,this.options.selector,f.proxy(this.leave,this))
}}}this.options.selector?this._options=f.extend({},this.options,{trigger:"manual",selector:""}):this.fixTitle()
},h.prototype.getDefaults=function(){return h.DEFAULTS
},h.prototype.getOptions=function(a){return a=f.extend({},this.getDefaults(),this.$element.data(),a),a.delay&&"number"==typeof a.delay&&(a.delay={show:a.delay,hide:a.delay}),a
},h.prototype.getDelegateOptions=function(){var a={},d=this.getDefaults();
return this._options&&f.each(this._options,function(b,c){d[b]!=c&&(a[b]=c)
}),a
},h.prototype.enter=function(a){var d=a instanceof this.constructor?a:f(a.currentTarget).data("bs."+this.type);
return d||(d=new this.constructor(a.currentTarget,this.getDelegateOptions()),f(a.currentTarget).data("bs."+this.type,d)),clearTimeout(d.timeout),d.hoverState="in",d.options.delay&&d.options.delay.show?void (d.timeout=setTimeout(function(){"in"==d.hoverState&&d.show()
},d.options.delay.show)):d.show()
},h.prototype.leave=function(a){var d=a instanceof this.constructor?a:f(a.currentTarget).data("bs."+this.type);
return d||(d=new this.constructor(a.currentTarget,this.getDelegateOptions()),f(a.currentTarget).data("bs."+this.type,d)),clearTimeout(d.timeout),d.hoverState="out",d.options.delay&&d.options.delay.hide?void (d.timeout=setTimeout(function(){"out"==d.hoverState&&d.hide()
},d.options.delay.hide)):d.hide()
},h.prototype.show=function(){var F=f.Event("show.bs."+this.type);
if(this.hasContent()&&this.enabled){this.$element.trigger(F);
var E=f.contains(document.documentElement,this.$element[0]);
if(F.isDefaultPrevented()||!E){return
}var D=this,C=this.tip(),B=this.getUID(this.type);
this.setContent(),C.attr("id",B),this.$element.attr("aria-describedby",B),this.options.animation&&C.addClass("fade");
var A="function"==typeof this.options.placement?this.options.placement.call(this,C[0],this.$element[0]):this.options.placement,z=/\s?auto?\s?/i,y=z.test(A);
y&&(A=A.replace(z,"")||"top"),C.detach().css({top:0,left:0,display:"block"}).addClass(A).data("bs."+this.type,this),this.options.container?C.appendTo(this.options.container):C.insertAfter(this.$element);
var x=this.getPosition(),w=C[0].offsetWidth,v=C[0].offsetHeight;
if(y){var u=A,t=this.$element.parent(),s=this.getPosition(t);
A="bottom"==A&&x.top+x.height+v-s.scroll>s.height?"top":"top"==A&&x.top-s.scroll-v<0?"bottom":"right"==A&&x.right+w>s.width?"left":"left"==A&&x.left-w<s.left?"right":A,C.removeClass(u).addClass(A)
}var r=this.getCalculatedOffset(A,x,w,v);
this.applyPlacement(r,A);
var a=function(){D.$element.trigger("shown.bs."+D.type),D.hoverState=null
};
f.support.transition&&this.$tip.hasClass("fade")?C.one("bsTransitionEnd",a).emulateTransitionEnd(150):a()
}},h.prototype.applyPlacement=function(z,y){var x=this.tip(),w=x[0].offsetWidth,v=x[0].offsetHeight,u=parseInt(x.css("margin-top"),10),t=parseInt(x.css("margin-left"),10);
isNaN(u)&&(u=0),isNaN(t)&&(t=0),z.top=z.top+u,z.left=z.left+t,f.offset.setOffset(x[0],f.extend({using:function(b){x.css({top:Math.round(b.top),left:Math.round(b.left)})
}},z),0),x.addClass("in");
var s=x[0].offsetWidth,r=x[0].offsetHeight;
"top"==y&&r!=v&&(z.top=z.top+v-r);
var q=this.getViewportAdjustedDelta(y,z,s,r);
q.left?z.left+=q.left:z.top+=q.top;
var p=q.left?2*q.left-w+s:2*q.top-v+r,o=q.left?"left":"top",a=q.left?"offsetWidth":"offsetHeight";
x.offset(z),this.replaceArrow(p,x[0][a],o)
},h.prototype.replaceArrow=function(j,d,k){this.arrow().css(k,j?50*(1-j/d)+"%":"")
},h.prototype.setContent=function(){var d=this.tip(),c=this.getTitle();
d.find(".tooltip-inner")[this.options.html?"html":"text"](c),d.removeClass("fade in top bottom left right")
},h.prototype.hide=function(){function a(){"in"!=l.hoverState&&k.detach(),l.$element.trigger("hidden.bs."+l.type)
}var l=this,k=this.tip(),j=f.Event("hide.bs."+this.type);
return this.$element.removeAttr("aria-describedby"),this.$element.trigger(j),j.isDefaultPrevented()?void 0:(k.removeClass("in"),f.support.transition&&this.$tip.hasClass("fade")?k.one("bsTransitionEnd",a).emulateTransitionEnd(150):a(),this.hoverState=null,this)
},h.prototype.fixTitle=function(){var b=this.$element;
(b.attr("title")||"string"!=typeof b.attr("data-original-title"))&&b.attr("data-original-title",b.attr("title")||"").attr("title","")
},h.prototype.hasContent=function(){return this.getTitle()
},h.prototype.getPosition=function(a){a=a||this.$element;
var k=a[0],j="BODY"==k.tagName;
return f.extend({},"function"==typeof k.getBoundingClientRect?k.getBoundingClientRect():null,{scroll:j?document.documentElement.scrollTop||document.body.scrollTop:a.scrollTop(),width:j?f(window).width():a.outerWidth(),height:j?f(window).height():a.outerHeight()},j?{top:0,left:0}:a.offset())
},h.prototype.getCalculatedOffset=function(k,j,m,l){return"bottom"==k?{top:j.top+j.height,left:j.left+j.width/2-m/2}:"top"==k?{top:j.top-l,left:j.left+j.width/2-m/2}:"left"==k?{top:j.top+j.height/2-l/2,left:j.left-m}:{top:j.top+j.height/2-l/2,left:j.left+j.width}
},h.prototype.getViewportAdjustedDelta=function(v,u,t,s){var r={top:0,left:0};
if(!this.$viewport){return r
}var q=this.options.viewport&&this.options.viewport.padding||0,p=this.getPosition(this.$viewport);
if(/right|left/.test(v)){var o=u.top-q-p.scroll,n=u.top+q-p.scroll+s;
o<p.top?r.top=p.top-o:n>p.top+p.height&&(r.top=p.top+p.height-n)
}else{var m=u.left-q,l=u.left+q+t;
m<p.left?r.left=p.left-m:l>p.width&&(r.left=p.left+p.width-l)
}return r
},h.prototype.getTitle=function(){var j,d=this.$element,k=this.options;
return j=d.attr("data-original-title")||("function"==typeof k.title?k.title.call(d[0]):k.title)
},h.prototype.getUID=function(b){do{b+=~~(1000000*Math.random())
}while(document.getElementById(b));
return b
},h.prototype.tip=function(){return this.$tip=this.$tip||f(this.options.template)
},h.prototype.arrow=function(){return this.$arrow=this.$arrow||this.tip().find(".tooltip-arrow")
},h.prototype.validate=function(){this.$element[0].parentNode||(this.hide(),this.$element=null,this.options=null)
},h.prototype.enable=function(){this.enabled=!0
},h.prototype.disable=function(){this.enabled=!1
},h.prototype.toggleEnabled=function(){this.enabled=!this.enabled
},h.prototype.toggle=function(a){var d=this;
a&&(d=f(a.currentTarget).data("bs."+this.type),d||(d=new this.constructor(a.currentTarget,this.getDelegateOptions()),f(a.currentTarget).data("bs."+this.type,d))),d.tip().hasClass("in")?d.leave(d):d.enter(d)
},h.prototype.destroy=function(){clearTimeout(this.timeout),this.hide().$element.off("."+this.type).removeData("bs."+this.type)
};
var g=f.fn.tooltip;
f.fn.tooltip=e,f.fn.tooltip.Constructor=h,f.fn.tooltip.noConflict=function(){return f.fn.tooltip=g,this
}
}(jQuery),+function(f){function e(a){return this.each(function(){var j=f(this),c=j.data("bs.popover"),b="object"==typeof a&&a;
(c||"destroy"!=a)&&(c||j.data("bs.popover",c=new h(this,b)),"string"==typeof a&&c[a]())
})
}var h=function(d,c){this.init("popover",d,c)
};
if(!f.fn.tooltip){throw new Error("Popover requires tooltip.js")
}h.VERSION="3.2.0",h.DEFAULTS=f.extend({},f.fn.tooltip.Constructor.DEFAULTS,{placement:"right",trigger:"click",content:"",template:'<div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-title"></h3><div class="popover-content"></div></div>'}),h.prototype=f.extend({},f.fn.tooltip.Constructor.prototype),h.prototype.constructor=h,h.prototype.getDefaults=function(){return h.DEFAULTS
},h.prototype.setContent=function(){var j=this.tip(),d=this.getTitle(),k=this.getContent();
j.find(".popover-title")[this.options.html?"html":"text"](d),j.find(".popover-content").empty()[this.options.html?"string"==typeof k?"html":"append":"text"](k),j.removeClass("fade top bottom left right in"),j.find(".popover-title").html()||j.find(".popover-title").hide()
},h.prototype.hasContent=function(){return this.getTitle()||this.getContent()
},h.prototype.getContent=function(){var d=this.$element,c=this.options;
return d.attr("data-content")||("function"==typeof c.content?c.content.call(d[0]):c.content)
},h.prototype.arrow=function(){return this.$arrow=this.$arrow||this.tip().find(".arrow")
},h.prototype.tip=function(){return this.$tip||(this.$tip=f(this.options.template)),this.$tip
};
var g=f.fn.popover;
f.fn.popover=e,f.fn.popover.Constructor=h,f.fn.popover.noConflict=function(){return f.fn.popover=g,this
}
}(jQuery),+function(f){function e(j,b){var a=f.proxy(this.process,this);
this.$body=f("body"),this.$scrollElement=f(f(j).is("body")?window:j),this.options=f.extend({},e.DEFAULTS,b),this.selector=(this.options.target||"")+" .nav li > a",this.offsets=[],this.targets=[],this.activeTarget=null,this.scrollHeight=0,this.$scrollElement.on("scroll.bs.scrollspy",a),this.refresh(),this.process()
}function h(a){return this.each(function(){var j=f(this),c=j.data("bs.scrollspy"),b="object"==typeof a&&a;
c||j.data("bs.scrollspy",c=new e(this,b)),"string"==typeof a&&c[a]()
})
}e.VERSION="3.2.0",e.DEFAULTS={offset:10},e.prototype.getScrollHeight=function(){return this.$scrollElement[0].scrollHeight||Math.max(this.$body[0].scrollHeight,document.documentElement.scrollHeight)
},e.prototype.refresh=function(){var a="offset",k=0;
f.isWindow(this.$scrollElement[0])||(a="position",k=this.$scrollElement.scrollTop()),this.offsets=[],this.targets=[],this.scrollHeight=this.getScrollHeight();
var j=this;
this.$body.find(this.selector).map(function(){var l=f(this),c=l.data("target")||l.attr("href"),b=/^#./.test(c)&&f(c);
return b&&b.length&&b.is(":visible")&&[[b[a]().top+k,c]]||null
}).sort(function(d,c){return d[0]-c[0]
}).each(function(){j.offsets.push(this[0]),j.targets.push(this[1])
})
},e.prototype.process=function(){var k,j=this.$scrollElement.scrollTop()+this.options.offset,p=this.getScrollHeight(),o=this.options.offset+p-this.$scrollElement.height(),n=this.offsets,m=this.targets,l=this.activeTarget;
if(this.scrollHeight!=p&&this.refresh(),j>=o){return l!=(k=m[m.length-1])&&this.activate(k)
}if(l&&j<=n[0]){return l!=(k=m[0])&&this.activate(k)
}for(k=n.length;
k--;
){l!=m[k]&&j>=n[k]&&(!n[k+1]||j<=n[k+1])&&this.activate(m[k])
}},e.prototype.activate=function(a){this.activeTarget=a,f(this.selector).parentsUntil(this.options.target,".active").removeClass("active");
var k=this.selector+'[data-target="'+a+'"],'+this.selector+'[href="'+a+'"]',j=f(k).parents("li").addClass("active");
j.parent(".dropdown-menu").length&&(j=j.closest("li.dropdown").addClass("active")),j.trigger("activate.bs.scrollspy")
};
var g=f.fn.scrollspy;
f.fn.scrollspy=h,f.fn.scrollspy.Constructor=e,f.fn.scrollspy.noConflict=function(){return f.fn.scrollspy=g,this
},f(window).on("load.bs.scrollspy.data-api",function(){f('[data-spy="scroll"]').each(function(){var a=f(this);
h.call(a,a.data())
})
})
}(jQuery),+function(f){function e(a){return this.each(function(){var c=f(this),b=c.data("bs.tab");
b||c.data("bs.tab",b=new h(this)),"string"==typeof a&&b[a]()
})
}var h=function(a){this.element=f(a)
};
h.VERSION="3.2.0",h.prototype.show=function(){var a=this.element,n=a.closest("ul:not(.dropdown-menu)"),m=a.data("target");
if(m||(m=a.attr("href"),m=m&&m.replace(/.*(?=#[^\s]*$)/,"")),!a.parent("li").hasClass("active")){var l=n.find(".active:last a")[0],k=f.Event("show.bs.tab",{relatedTarget:l});
if(a.trigger(k),!k.isDefaultPrevented()){var j=f(m);
this.activate(a.closest("li"),n),this.activate(j,j.parent(),function(){a.trigger({type:"shown.bs.tab",relatedTarget:l})
})
}}},h.prototype.activate=function(a,n,m){function l(){k.removeClass("active").find("> .dropdown-menu > .active").removeClass("active"),a.addClass("active"),j?(a[0].offsetWidth,a.addClass("in")):a.removeClass("fade"),a.parent(".dropdown-menu")&&a.closest("li.dropdown").addClass("active"),m&&m()
}var k=n.find("> .active"),j=m&&f.support.transition&&k.hasClass("fade");
j?k.one("bsTransitionEnd",l).emulateTransitionEnd(150):l(),k.removeClass("in")
};
var g=f.fn.tab;
f.fn.tab=e,f.fn.tab.Constructor=h,f.fn.tab.noConflict=function(){return f.fn.tab=g,this
},f(document).on("click.bs.tab.data-api",'[data-toggle="tab"], [data-toggle="pill"]',function(a){a.preventDefault(),e.call(f(this),"show")
})
}(jQuery),+function(f){function e(a){return this.each(function(){var j=f(this),c=j.data("bs.affix"),b="object"==typeof a&&a;
c||j.data("bs.affix",c=new h(this,b)),"string"==typeof a&&c[a]()
})
}var h=function(a,c){this.options=f.extend({},h.DEFAULTS,c),this.$target=f(this.options.target).on("scroll.bs.affix.data-api",f.proxy(this.checkPosition,this)).on("click.bs.affix.data-api",f.proxy(this.checkPositionWithEventLoop,this)),this.$element=f(a),this.affixed=this.unpin=this.pinnedOffset=null,this.checkPosition()
};
h.VERSION="3.2.0",h.RESET="affix affix-top affix-bottom",h.DEFAULTS={offset:0,target:window},h.prototype.getPinnedOffset=function(){if(this.pinnedOffset){return this.pinnedOffset
}this.$element.removeClass(h.RESET).addClass("affix");
var d=this.$target.scrollTop(),c=this.$element.offset();
return this.pinnedOffset=c.top-d
},h.prototype.checkPositionWithEventLoop=function(){setTimeout(f.proxy(this.checkPosition,this),1)
},h.prototype.checkPosition=function(){if(this.$element.is(":visible")){var r=f(document).height(),q=this.$target.scrollTop(),p=this.$element.offset(),o=this.options.offset,n=o.top,m=o.bottom;
"object"!=typeof o&&(m=n=o),"function"==typeof n&&(n=o.top(this.$element)),"function"==typeof m&&(m=o.bottom(this.$element));
var l=null!=this.unpin&&q+this.unpin<=p.top?!1:null!=m&&p.top+this.$element.height()>=r-m?"bottom":null!=n&&n>=q?"top":!1;
if(this.affixed!==l){null!=this.unpin&&this.$element.css("top","");
var c="affix"+(l?"-"+l:""),a=f.Event(c+".bs.affix");
this.$element.trigger(a),a.isDefaultPrevented()||(this.affixed=l,this.unpin="bottom"==l?this.getPinnedOffset():null,this.$element.removeClass(h.RESET).addClass(c).trigger(f.Event(c.replace("affix","affixed"))),"bottom"==l&&this.$element.offset({top:r-this.$element.height()-m}))
}}};
var g=f.fn.affix;
f.fn.affix=e,f.fn.affix.Constructor=h,f.fn.affix.noConflict=function(){return f.fn.affix=g,this
},f(window).on("load",function(){f('[data-spy="affix"]').each(function(){var b=f(this),a=b.data();
a.offset=a.offset||{},a.offsetBottom&&(a.offset.bottom=a.offsetBottom),a.offsetTop&&(a.offset.top=a.offsetTop),e.call(b,a)
})
})
}(jQuery);
/*!
 * ZeroClipboard
 * The ZeroClipboard library provides an easy way to copy text to the clipboard using an invisible Adobe Flash movie and a JavaScript interface.
 * Copyright (c) 2014 Jon Rohan, James M. Greene
 * Licensed MIT
 * http://zeroclipboard.org/
 * v2.1.6
 */
!function(aZ,aY){var aX,aW,aT=aZ,aS=aT.document,aR=aT.navigator,aQ=aT.setTimeout,aP=aT.encodeURIComponent,aM=aT.ActiveXObject,aL=aT.Error,aK=aT.Number.parseInt||aT.parseInt,aJ=aT.Number.parseFloat||aT.parseFloat,aI=aT.Number.isNaN||aT.isNaN,aG=aT.Math.round,aF=aT.Date.now,aE=aT.Object.keys,aD=aT.Object.defineProperty,aC=aT.Object.prototype.hasOwnProperty,aB=aT.Array.prototype.slice,aA=function(){var f=function(b){return b
};
if("function"==typeof aT.wrap&&"function"==typeof aT.unwrap){try{var e=aS.createElement("div"),h=aT.unwrap(e);
1===e.nodeType&&h&&1===h.nodeType&&(f=aT.unwrap)
}catch(g){}}return f
}(),az=function(b){return aB.call(b,0)
},ay=function(){var b,p,o,n,m,l,k=az(arguments),j=k[0]||{};
for(b=1,p=k.length;
p>b;
b++){if(null!=(o=k[b])){for(n in o){aC.call(o,n)&&(m=j[n],l=o[n],j!==l&&l!==aY&&(j[n]=l))
}}}return j
},ax=function(g){var f,k,j,h;
if("object"!=typeof g||null==g){f=g
}else{if("number"==typeof g.length){for(f=[],k=0,j=g.length;
j>k;
k++){aC.call(g,k)&&(f[k]=ax(g[k]))
}}else{f={};
for(h in g){aC.call(g,h)&&(f[h]=ax(g[h]))
}}}return f
},aw=function(g,f){for(var k={},j=0,h=f.length;
h>j;
j++){f[j] in g&&(k[f[j]]=g[f[j]])
}return k
},au=function(f,e){var h={};
for(var g in f){-1===e.indexOf(g)&&(h[g]=f[g])
}return h
},bA=function(d){if(d){for(var c in d){aC.call(d,c)&&delete d[c]
}}return d
},by=function(d,c){if(d&&1===d.nodeType&&d.ownerDocument&&c&&(1===c.nodeType&&c.ownerDocument&&c.ownerDocument===d.ownerDocument||9===c.nodeType&&!c.ownerDocument&&c===d.ownerDocument)){do{if(d===c){return !0
}d=d.parentNode
}while(d)
}return !1
},bx=function(d){var c;
return"string"==typeof d&&d&&(c=d.split("#")[0].split("?")[0],c=d.slice(0,d.lastIndexOf("/")+1)),c
},bw=function(e){var d,f;
return"string"==typeof e&&e&&(f=e.match(/^(?:|[^:@]*@|.+\)@(?=http[s]?|file)|.+?\s+(?: at |@)(?:[^:\(]+ )*[\(]?)((?:http[s]?|file):\/\/[\/]?.+?\/[^:\)]*?)(?::\d+)(?::\d+)?/),f&&f[1]?d=f[1]:(f=e.match(/\)@((?:http[s]?|file):\/\/[\/]?.+?\/[^:\)]*?)(?::\d+)(?::\d+)?/),f&&f[1]&&(d=f[1]))),d
},bv=function(){var e,d;
try{throw new aL
}catch(f){d=f
}return d&&(e=d.sourceURL||d.fileName||bw(d.stack)),e
},bs=function(){var b,f,e;
if(aS.currentScript&&(b=aS.currentScript.src)){return b
}if(f=aS.getElementsByTagName("script"),1===f.length){return f[0].src||aY
}if("readyState" in f[0]){for(e=f.length;
e--;
){if("interactive"===f[e].readyState&&(b=f[e].src)){return b
}}}return"loading"===aS.readyState&&(b=f[f.length-1].src)?b:(b=bv())?b:aY
},br=function(){var b,h,g,f=aS.getElementsByTagName("script");
for(b=f.length;
b--;
){if(!(g=f[b].src)){h=null;
break
}if(g=bx(g),null==h){h=g
}else{if(h!==g){h=null;
break
}}}return h||aY
},bq=function(){var b=bx(bs())||br()||"";
return b+"ZeroClipboard.swf"
},bp={bridge:null,version:"0.0.0",pluginType:"unknown",disabled:null,outdated:null,unavailable:null,deactivated:null,overdue:null,ready:null},bo="11.0.0",bl={},bk={},bj=null,bi={ready:"Flash communication is established",error:{"flash-disabled":"Flash is disabled or not installed","flash-outdated":"Flash is too outdated to support ZeroClipboard","flash-unavailable":"Flash is unable to communicate bidirectionally with JavaScript","flash-deactivated":"Flash is too outdated for your browser and/or is configured as click-to-activate","flash-overdue":"Flash communication was established but NOT within the acceptable time limit"}},bh={swfPath:bq(),trustedDomains:aZ.location.host?[aZ.location.host]:[],cacheBust:!0,forceEnhancedClipboard:!1,flashLoadTimeout:30000,autoActivate:!0,bubbleEvents:!0,containerId:"global-zeroclipboard-html-bridge",containerClass:"global-zeroclipboard-container",swfObjectId:"global-zeroclipboard-flash-bridge",hoverClass:"zeroclipboard-is-hover",activeClass:"zeroclipboard-is-active",forceHandCursor:!1,title:null,zIndex:999999999},bg=function(d){if("object"==typeof d&&null!==d){for(var c in d){if(aC.call(d,c)){if(/^(?:forceHandCursor|title|zIndex|bubbleEvents)$/.test(c)){bh[c]=d[c]
}else{if(null==bp.bridge){if("containerId"===c||"swfObjectId"===c){if(!aH(d[c])){throw new Error("The specified `"+c+"` value is not valid as an HTML4 Element ID")
}bh[c]=d[c]
}else{bh[c]=d[c]
}}}}}}if("string"!=typeof d||!d){return ax(bh)
}if(aC.call(bh,d)){return bh[d]
}},be=function(){return{browser:aw(aR,["userAgent","platform","appName"]),flash:au(bp,["bridge"]),zeroclipboard:{version:ag.version,config:ag.config()}}
},bd=function(){return !!(bp.disabled||bp.outdated||bp.unavailable||bp.deactivated)
},bc=function(j,h){var o,n,m,l={};
if("string"==typeof j&&j){m=j.toLowerCase().split(/\s+/)
}else{if("object"==typeof j&&j&&"undefined"==typeof h){for(o in j){aC.call(j,o)&&"string"==typeof o&&o&&"function"==typeof j[o]&&ag.on(o,j[o])
}}}if(m&&m.length){for(o=0,n=m.length;
n>o;
o++){j=m[o].replace(/^on/,""),l[j]=!0,bl[j]||(bl[j]=[]),bl[j].push(h)
}if(l.ready&&bp.ready&&ag.emit({type:"ready"}),l.error){var k=["disabled","outdated","unavailable","deactivated","overdue"];
for(o=0,n=k.length;
n>o;
o++){if(bp[k[o]]===!0){ag.emit({type:"error",name:"flash-"+k[o]});
break
}}}}return ag
},ba=function(j,h){var o,n,m,l,k;
if(0===arguments.length){l=aE(bl)
}else{if("string"==typeof j&&j){l=j.split(/\s+/)
}else{if("object"==typeof j&&j&&"undefined"==typeof h){for(o in j){aC.call(j,o)&&"string"==typeof o&&o&&"function"==typeof j[o]&&ag.off(o,j[o])
}}}}if(l&&l.length){for(o=0,n=l.length;
n>o;
o++){if(j=l[o].toLowerCase().replace(/^on/,""),k=bl[j],k&&k.length){if(h){for(m=k.indexOf(h);
-1!==m;
){k.splice(m,1),m=k.indexOf(h,m)
}}else{k.length=0
}}}}return ag
},a9=function(d){var c;
return c="string"==typeof d&&d?ax(bl[d])||null:ax(bl)
},a8=function(f){var e,h,g;
return f=am(f),f&&!an(f)?"ready"===f.type&&bp.overdue===!0?ag.emit({type:"error",name:"flash-overdue"}):(e=ay({},f),aN.call(this,e),"copy"===f.type&&(g=ap(bk),h=g.data,bj=g.formatMap),h):void 0
},a7=function(){if("boolean"!=typeof bp.ready&&(bp.ready=!1),!ag.isFlashUnusable()&&null===bp.bridge){var b=bh.flashLoadTimeout;
"number"==typeof b&&b>=0&&aQ(function(){"boolean"!=typeof bp.deactivated&&(bp.deactivated=!0),bp.deactivated===!0&&ag.emit({type:"error",name:"flash-deactivated"})
},b),bp.overdue=!1,bt()
}},a6=function(){ag.clearData(),ag.blur(),ag.emit("destroy"),aU(),ag.off()
},a5=function(f,e){var h;
if("object"==typeof f&&f&&"undefined"==typeof e){h=f,ag.clearData()
}else{if("string"!=typeof f||!f){return
}h={},h[f]=e
}for(var g in h){"string"==typeof g&&g&&aC.call(h,g)&&"string"==typeof h[g]&&h[g]&&(bk[g]=h[g])
}},a4=function(b){"undefined"==typeof b?(bA(bk),bj=null):"string"==typeof b&&aC.call(bk,b)&&delete bk[b]
},bJ=function(b){return"undefined"==typeof b?ax(bk):"string"==typeof b&&aC.call(bk,b)?bk[b]:void 0
},a2=function(f){if(f&&1===f.nodeType){aX&&(aa(aX,bh.activeClass),aX!==f&&aa(aX,bh.hoverClass)),aX=f,aj(f,bh.hoverClass);
var c=f.getAttribute("title")||bh.title;
if("string"==typeof c&&c){var h=bH(bp.bridge);
h&&h.setAttribute("title",c)
}var g=bh.forceHandCursor===!0||"pointer"===bM(f,"cursor");
bn(g),bG()
}},bE=function(){var b=bH(bp.bridge);
b&&(b.removeAttribute("title"),b.style.left="0px",b.style.top="-9999px",b.style.width="1px",b.style.top="1px"),aX&&(aa(aX,bh.hoverClass),aa(aX,bh.activeClass),aX=null)
},bf=function(){return aX||null
},aH=function(b){return"string"==typeof b&&b&&/^[A-Za-z][A-Za-z0-9_:\-\.]*$/.test(b)
},am=function(d){var c;
if("string"==typeof d&&d?(c=d,d={}):"object"==typeof d&&d&&"string"==typeof d.type&&d.type&&(c=d.type),c){!d.target&&/^(copy|aftercopy|_click)$/.test(c.toLowerCase())&&(d.target=aW),ay(d,{type:c.toLowerCase(),target:d.target||aX||null,relatedTarget:d.relatedTarget||null,currentTarget:bp&&bp.bridge||null,timeStamp:d.timeStamp||aF()||null});
var f=bi[d.type];
return"error"===d.type&&d.name&&f&&(f=f[d.name]),f&&(d.message=f),"ready"===d.type&&ay(d,{target:null,version:bp.version}),"error"===d.type&&(/^flash-(disabled|outdated|unavailable|deactivated|overdue)$/.test(d.name)&&ay(d,{target:null,minimumVersion:bo}),/^flash-(outdated|unavailable|deactivated|overdue)$/.test(d.name)&&ay(d,{version:bp.version})),"copy"===d.type&&(d.clipboardData={setData:ag.setData,clearData:ag.clearData}),"aftercopy"===d.type&&(d=ah(d,bj)),d.target&&!d.relatedTarget&&(d.relatedTarget=ae(d.target)),d=bO(d)
}},ae=function(d){var c=d&&d.getAttribute&&d.getAttribute("data-clipboard-target");
return c?aS.getElementById(c):null
},bO=function(F){if(F&&/^_(?:click|mouse(?:over|out|down|up|move))$/.test(F.type)){var E=F.target,D="_mouseover"===F.type&&F.relatedTarget?F.relatedTarget:aY,C="_mouseout"===F.type&&F.relatedTarget?F.relatedTarget:aY,B=bP(E),A=aT.screenLeft||aT.screenX||0,z=aT.screenTop||aT.screenY||0,y=aS.body.scrollLeft+aS.documentElement.scrollLeft,x=aS.body.scrollTop+aS.documentElement.scrollTop,w=B.left+("number"==typeof F._stageX?F._stageX:0),v=B.top+("number"==typeof F._stageY?F._stageY:0),u=w-y,f=v-x,e=A+u,b=z+f,H="number"==typeof F.movementX?F.movementX:0,G="number"==typeof F.movementY?F.movementY:0;
delete F._stageX,delete F._stageY,ay(F,{srcElement:E,fromElement:D,toElement:C,screenX:e,screenY:b,pageX:w,pageY:v,clientX:u,clientY:f,x:u,y:f,movementX:H,movementY:G,offsetX:0,offsetY:0,layerX:0,layerY:0})
}return F
},bF=function(d){var c=d&&"string"==typeof d.type&&d.type||"";
return !/^(?:(?:before)?copy|destroy)$/.test(c)
},bm=function(f,e,h,g){g?aQ(function(){f.apply(e,h)
},0):f.apply(e,h)
},aN=function(v){if("object"==typeof v&&v&&v.type){var u=bF(v),t=bl["*"]||[],s=bl[v.type]||[],r=t.concat(s);
if(r&&r.length){var q,p,o,n,m,e=this;
for(q=0,p=r.length;
p>q;
q++){o=r[q],n=e,"string"==typeof o&&"function"==typeof aT[o]&&(o=aT[o]),"object"==typeof o&&o&&"function"==typeof o.handleEvent&&(n=o,o=o.handleEvent),"function"==typeof o&&(m=ay({},v),bm(o,n,[m],u))
}}return this
}},an=function(d){var c=d.target||aX||null,p="swf"===d._source;
delete d._source;
var o=["flash-disabled","flash-outdated","flash-unavailable","flash-deactivated","flash-overdue"];
switch(d.type){case"error":-1!==o.indexOf(d.name)&&ay(bp,{disabled:"flash-disabled"===d.name,outdated:"flash-outdated"===d.name,unavailable:"flash-unavailable"===d.name,deactivated:"flash-deactivated"===d.name,overdue:"flash-overdue"===d.name,ready:!1});
break;
case"ready":var n=bp.deactivated===!0;
ay(bp,{disabled:!1,outdated:!1,unavailable:!1,deactivated:!1,overdue:n,ready:!n});
break;
case"beforecopy":aW=c;
break;
case"copy":var m,l,k=d.relatedTarget;
!bk["text/html"]&&!bk["text/plain"]&&k&&(l=k.value||k.outerHTML||k.innerHTML)&&(m=k.value||k.textContent||k.innerText)?(d.clipboardData.clearData(),d.clipboardData.setData("text/plain",m),l!==m&&d.clipboardData.setData("text/html",l)):!bk["text/plain"]&&d.target&&(m=d.target.getAttribute("data-clipboard-text"))&&(d.clipboardData.clearData(),d.clipboardData.setData("text/plain",m));
break;
case"aftercopy":ag.clearData(),c&&c!==ar()&&c.focus&&c.focus();
break;
case"_mouseover":ag.focus(c),bh.bubbleEvents===!0&&p&&(c&&c!==d.relatedTarget&&!by(d.relatedTarget,c)&&af(ay({},d,{type:"mouseenter",bubbles:!1,cancelable:!1})),af(ay({},d,{type:"mouseover"})));
break;
case"_mouseout":ag.blur(),bh.bubbleEvents===!0&&p&&(c&&c!==d.relatedTarget&&!by(d.relatedTarget,c)&&af(ay({},d,{type:"mouseleave",bubbles:!1,cancelable:!1})),af(ay({},d,{type:"mouseout"})));
break;
case"_mousedown":aj(c,bh.activeClass),bh.bubbleEvents===!0&&p&&af(ay({},d,{type:d.type.slice(1)}));
break;
case"_mouseup":aa(c,bh.activeClass),bh.bubbleEvents===!0&&p&&af(ay({},d,{type:d.type.slice(1)}));
break;
case"_click":aW=null,bh.bubbleEvents===!0&&p&&af(ay({},d,{type:d.type.slice(1)}));
break;
case"_mousemove":bh.bubbleEvents===!0&&p&&af(ay({},d,{type:d.type.slice(1)}))
}return/^_(?:click|mouse(?:over|out|down|up|move))$/.test(d.type)?!0:void 0
},af=function(f){if(f&&"string"==typeof f.type&&f){var e,m=f.target||null,l=m&&m.ownerDocument||aS,k={view:l.defaultView||aT,canBubble:!0,cancelable:!0,detail:"click"===f.type?1:0,button:"number"==typeof f.which?f.which-1:"number"==typeof f.button?f.button:l.createEvent?0:1},j=ay(k,f);
m&&l.createEvent&&m.dispatchEvent&&(j=[j.type,j.canBubble,j.cancelable,j.view,j.detail,j.screenX,j.screenY,j.clientX,j.clientY,j.ctrlKey,j.altKey,j.shiftKey,j.metaKey,j.button,j.relatedTarget],e=l.createEvent("MouseEvents"),e.initMouseEvent&&(e.initMouseEvent.apply(e,j),e._source="js",m.dispatchEvent(e)))
}},bQ=function(){var b=aS.createElement("div");
return b.id=bh.containerId,b.className=bh.containerClass,b.style.position="absolute",b.style.left="0px",b.style.top="-9999px",b.style.width="1px",b.style.height="1px",b.style.zIndex=""+aO(bh.zIndex),b
},bH=function(d){for(var c=d&&d.parentNode;
c&&"OBJECT"===c.nodeName&&c.parentNode;
){c=c.parentNode
}return c||null
},bt=function(){var t,s=bp.bridge,r=bH(s);
if(!s){var q=a0(aT.location.host,bh),p="never"===q?"none":"all",o=bK(bh),n=bh.swfPath+bS(bh.swfPath,bh);
r=bQ();
var m=aS.createElement("div");
r.appendChild(m),aS.body.appendChild(r);
var f=aS.createElement("div"),e="activex"===bp.pluginType;
f.innerHTML='<object id="'+bh.swfObjectId+'" name="'+bh.swfObjectId+'" width="100%" height="100%" '+(e?'classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000"':'type="application/x-shockwave-flash" data="'+n+'"')+">"+(e?'<param name="movie" value="'+n+'"/>':"")+'<param name="allowScriptAccess" value="'+q+'"/><param name="allowNetworking" value="'+p+'"/><param name="menu" value="false"/><param name="wmode" value="transparent"/><param name="flashvars" value="'+o+'"/></object>',s=f.firstChild,f=null,aA(s).ZeroClipboard=ag,r.replaceChild(s,m)
}return s||(s=aS[bh.swfObjectId],s&&(t=s.length)&&(s=s[t-1]),!s&&r&&(s=r.firstChild)),bp.bridge=s||null,s
},aU=function(){var e=bp.bridge;
if(e){var d=bH(e);
d&&("activex"===bp.pluginType&&"readyState" in e?(e.style.display="none",function f(){if(4===e.readyState){for(var a in e){"function"==typeof e[a]&&(e[a]=null)
}e.parentNode&&e.parentNode.removeChild(e),d.parentNode&&d.parentNode.removeChild(d)
}else{aQ(f,10)
}}()):(e.parentNode&&e.parentNode.removeChild(e),d.parentNode&&d.parentNode.removeChild(d))),bp.ready=null,bp.bridge=null,bp.deactivated=null
}},ap=function(f){var e={},h={};
if("object"==typeof f&&f){for(var g in f){if(g&&aC.call(f,g)&&"string"==typeof f[g]&&f[g]){switch(g.toLowerCase()){case"text/plain":case"text":case"air:text":case"flash:text":e.text=f[g],h.text=g;
break;
case"text/html":case"html":case"air:html":case"flash:html":e.html=f[g],h.html=g;
break;
case"application/rtf":case"text/rtf":case"rtf":case"richtext":case"air:rtf":case"flash:rtf":e.rtf=f[g],h.rtf=g
}}}return{data:e,formatMap:h}
}},ah=function(h,g){if("object"!=typeof h||!h||"object"!=typeof g||!g){return h
}var m={};
for(var l in h){if(aC.call(h,l)){if("success"!==l&&"data"!==l){m[l]=h[l];
continue
}m[l]={};
var k=h[l];
for(var j in k){j&&aC.call(k,j)&&aC.call(g,j)&&(m[l][g[j]]=k[j])
}}}return m
},bS=function(e,d){var f=null==d||d&&d.cacheBust===!0;
return f?(-1===e.indexOf("?")?"?":"&")+"noCache="+aF():""
},bK=function(j){var e,o,n,m,l="",k=[];
if(j.trustedDomains&&("string"==typeof j.trustedDomains?m=[j.trustedDomains]:"object"==typeof j.trustedDomains&&"length" in j.trustedDomains&&(m=j.trustedDomains)),m&&m.length){for(e=0,o=m.length;
o>e;
e++){if(aC.call(m,e)&&m[e]&&"string"==typeof m[e]){if(n=bz(m[e]),!n){continue
}if("*"===n){k.length=0,k.push(n);
break
}k.push.apply(k,[n,"//"+n,aT.location.protocol+"//"+n])
}}}return k.length&&(l+="trustedOrigins="+aP(k.join(","))),j.forceEnhancedClipboard===!0&&(l+=(l?"&":"")+"forceEnhancedClipboard=true"),"string"==typeof j.swfObjectId&&j.swfObjectId&&(l+=(l?"&":"")+"swfObjectId="+aP(j.swfObjectId)),l
},bz=function(e){if(null==e||""===e){return null
}if(e=e.replace(/^\s+|\s+$/g,""),""===e){return null
}var d=e.indexOf("//");
e=-1===d?e:e.slice(d+2);
var f=e.indexOf("/");
return e=-1===f?e:-1===d||0===f?null:e.slice(0,f),e&&".swf"===e.slice(-4).toLowerCase()?null:e||null
},a0=function(){var b=function(g){var f,k,j,h=[];
if("string"==typeof g&&(g=[g]),"object"!=typeof g||!g||"number"!=typeof g.length){return h
}for(f=0,k=g.length;
k>f;
f++){if(aC.call(g,f)&&(j=bz(g[f]))){if("*"===j){h.length=0,h.push("*");
break
}-1===h.indexOf(j)&&h.push(j)
}}return h
};
return function(a,k){var j=bz(k.swfPath);
null===j&&(j=a);
var h=b(k.trustedDomains),g=h.length;
if(g>0){if(1===g&&"*"===h[0]){return"always"
}if(-1!==h.indexOf(a)){return 1===g&&a===j?"sameDomain":"always"
}}return"never"
}
}(),ar=function(){try{return aS.activeElement
}catch(b){return null
}},aj=function(j,h){if(!j||1!==j.nodeType){return j
}if(j.classList){return j.classList.contains(h)||j.classList.add(h),j
}if(h&&"string"==typeof h){var o=(h||"").split(/\s+/);
if(1===j.nodeType){if(j.className){for(var n=" "+j.className+" ",m=j.className,l=0,k=o.length;
k>l;
l++){n.indexOf(" "+o[l]+" ")<0&&(m+=" "+o[l])
}j.className=m.replace(/^\s+|\s+$/g,"")
}else{j.className=h
}}}return j
},aa=function(h,g){if(!h||1!==h.nodeType){return h
}if(h.classList){return h.classList.contains(g)&&h.classList.remove(g),h
}if("string"==typeof g&&g){var m=g.split(/\s+/);
if(1===h.nodeType&&h.className){for(var l=(" "+h.className+" ").replace(/[\n\t]/g," "),k=0,j=m.length;
j>k;
k++){l=l.replace(" "+m[k]+" "," ")
}h.className=l.replace(/^\s+|\s+$/g,"")
}}return h
},bM=function(e,d){var f=aT.getComputedStyle(e,null).getPropertyValue(d);
return"cursor"!==d||f&&"auto"!==f||"A"!==e.nodeName?f:"pointer"
},bC=function(){var f,e,h,g=1;
return"function"==typeof aS.body.getBoundingClientRect&&(f=aS.body.getBoundingClientRect(),e=f.right-f.left,h=aS.body.offsetWidth,g=aG(e/h*100)/100),g
},bP=function(f){var e={left:0,top:0,width:0,height:0};
if(f.getBoundingClientRect){var p,o,n,m=f.getBoundingClientRect();
"pageXOffset" in aT&&"pageYOffset" in aT?(p=aT.pageXOffset,o=aT.pageYOffset):(n=bC(),p=aG(aS.documentElement.scrollLeft/n),o=aG(aS.documentElement.scrollTop/n));
var l=aS.documentElement.clientLeft||0,k=aS.documentElement.clientTop||0;
e.left=m.left+p-l,e.top=m.top+o-k,e.width="width" in m?m.width:m.right-m.left,e.height="height" in m?m.height:m.bottom-m.top
}return e
},bG=function(){var d;
if(aX&&(d=bH(bp.bridge))){var c=bP(aX);
ay(d.style,{width:c.width+"px",height:c.height+"px",top:c.top+"px",left:c.left+"px",zIndex:""+aO(bh.zIndex)})
}},bn=function(b){bp.ready===!0&&(bp.bridge&&"function"==typeof bp.bridge.setHandCursor?bp.bridge.setHandCursor(b):bp.ready=!1)
},aO=function(d){if(/^(?:auto|inherit)$/.test(d)){return d
}var c;
return"number"!=typeof d||aI(d)?"string"==typeof d&&(c=aO(aK(d,10))):c=d,"number"==typeof c?c:"auto"
},ao=function(B){function A(d){var c=d.match(/[\d]+/g);
return c.length=3,c.join(".")
}function z(b){return !!b&&(b=b.toLowerCase())&&(/^(pepflashplayer\.dll|libpepflashplayer\.so|pepperflashplayer\.plugin)$/.test(b)||"chrome.plugin"===b.slice(-13))
}function y(b){b&&(u=!0,b.version&&(r=A(b.version)),!r&&b.description&&(r=A(b.description)),b.filename&&(s=z(b.filename)))
}var x,w,v,u=!1,t=!1,s=!1,r="";
if(aR.plugins&&aR.plugins.length){x=aR.plugins["Shockwave Flash"],y(x),aR.plugins["Shockwave Flash 2.0"]&&(u=!0,r="2.0.0.11")
}else{if(aR.mimeTypes&&aR.mimeTypes.length){v=aR.mimeTypes["application/x-shockwave-flash"],x=v&&v.enabledPlugin,y(x)
}else{if("undefined"!=typeof B){t=!0;
try{w=new B("ShockwaveFlash.ShockwaveFlash.7"),u=!0,r=A(w.GetVariable("$version"))
}catch(q){try{w=new B("ShockwaveFlash.ShockwaveFlash.6"),u=!0,r="6.0.21"
}catch(m){try{w=new B("ShockwaveFlash.ShockwaveFlash"),u=!0,r=A(w.GetVariable("$version"))
}catch(g){t=!1
}}}}}}bp.disabled=u!==!0,bp.outdated=r&&aJ(r)<aJ(bo),bp.version=r||"0.0.0",bp.pluginType=s?"pepper":t?"activex":u?"netscape":"unknown"
};
ao(aM);
var ag=function(){return this instanceof ag?void ("function"==typeof ag._createClient&&ag._createClient.apply(this,az(arguments))):new ag
};
aD(ag,"version",{value:"2.1.6",writable:!1,configurable:!0,enumerable:!0}),ag.config=function(){return bg.apply(this,az(arguments))
},ag.state=function(){return be.apply(this,az(arguments))
},ag.isFlashUnusable=function(){return bd.apply(this,az(arguments))
},ag.on=function(){return bc.apply(this,az(arguments))
},ag.off=function(){return ba.apply(this,az(arguments))
},ag.handlers=function(){return a9.apply(this,az(arguments))
},ag.emit=function(){return a8.apply(this,az(arguments))
},ag.create=function(){return a7.apply(this,az(arguments))
},ag.destroy=function(){return a6.apply(this,az(arguments))
},ag.setData=function(){return a5.apply(this,az(arguments))
},ag.clearData=function(){return a4.apply(this,az(arguments))
},ag.getData=function(){return bJ.apply(this,az(arguments))
},ag.focus=ag.activate=function(){return a2.apply(this,az(arguments))
},ag.blur=ag.deactivate=function(){return bE.apply(this,az(arguments))
},ag.activeElement=function(){return bf.apply(this,az(arguments))
};
var bR=0,bI={},bu=0,aV={},aq={};
ay(bh,{autoActivate:!0});
var ai=function(d){var c=this;
c.id=""+bR++,bI[c.id]={instance:c,elements:[],handlers:{}},d&&c.clip(d),ag.on("*",function(b){return c.emit(b)
}),ag.on("destroy",function(){c.destroy()
}),ag.create()
},bT=function(k,j){var q,p,o,n={},m=bI[this.id]&&bI[this.id].handlers;
if("string"==typeof k&&k){o=k.toLowerCase().split(/\s+/)
}else{if("object"==typeof k&&k&&"undefined"==typeof j){for(q in k){aC.call(k,q)&&"string"==typeof q&&q&&"function"==typeof k[q]&&this.on(q,k[q])
}}}if(o&&o.length){for(q=0,p=o.length;
p>q;
q++){k=o[q].replace(/^on/,""),n[k]=!0,m[k]||(m[k]=[]),m[k].push(j)
}if(n.ready&&bp.ready&&this.emit({type:"ready",client:this}),n.error){var l=["disabled","outdated","unavailable","deactivated","overdue"];
for(q=0,p=l.length;
p>q;
q++){if(bp[l[q]]){this.emit({type:"error",name:"flash-"+l[q],client:this});
break
}}}}return this
},bL=function(k,j){var q,p,o,n,m,l=bI[this.id]&&bI[this.id].handlers;
if(0===arguments.length){n=aE(l)
}else{if("string"==typeof k&&k){n=k.split(/\s+/)
}else{if("object"==typeof k&&k&&"undefined"==typeof j){for(q in k){aC.call(k,q)&&"string"==typeof q&&q&&"function"==typeof k[q]&&this.off(q,k[q])
}}}}if(n&&n.length){for(q=0,p=n.length;
p>q;
q++){if(k=n[q].toLowerCase().replace(/^on/,""),m=l[k],m&&m.length){if(j){for(o=m.indexOf(j);
-1!==o;
){m.splice(o,1),o=m.indexOf(j,o)
}}else{m.length=0
}}}}return this
},bB=function(e){var d=null,f=bI[this.id]&&bI[this.id].handlers;
return f&&(d="string"==typeof e&&e?f[e]?f[e].slice(0):[]:ax(f)),d
},a1=function(d){if(bD.call(this,d)){"object"==typeof d&&d&&"string"==typeof d.type&&d.type&&(d=ay({},d));
var c=ay({},am(d),{client:this});
a3.call(this,c)
}return this
},at=function(e){e=av(e);
for(var d=0;
d<e.length;
d++){if(aC.call(e,d)&&e[d]&&1===e[d].nodeType){e[d].zcClippingId?-1===aV[e[d].zcClippingId].indexOf(this.id)&&aV[e[d].zcClippingId].push(this.id):(e[d].zcClippingId="zcClippingId_"+bu++,aV[e[d].zcClippingId]=[this.id],bh.autoActivate===!0&&al(e[d]));
var f=bI[this.id]&&bI[this.id].elements;
-1===f.indexOf(e[d])&&f.push(e[d])
}}return this
},ak=function(h){var g=bI[this.id];
if(!g){return this
}var m,l=g.elements;
h="undefined"==typeof h?l.slice(0):av(h);
for(var k=h.length;
k--;
){if(aC.call(h,k)&&h[k]&&1===h[k].nodeType){for(m=0;
-1!==(m=l.indexOf(h[k],m));
){l.splice(m,1)
}var j=aV[h[k].zcClippingId];
if(j){for(m=0;
-1!==(m=j.indexOf(this.id,m));
){j.splice(m,1)
}0===j.length&&(bh.autoActivate===!0&&ad(h[k]),delete h[k].zcClippingId)
}}}return this
},ac=function(){var b=bI[this.id];
return b&&b.elements?b.elements.slice(0):[]
},bN=function(){this.unclip(),this.off(),delete bI[this.id]
},bD=function(h){if(!h||!h.type){return !1
}if(h.client&&h.client!==this){return !1
}var g=bI[this.id]&&bI[this.id].elements,m=!!g&&g.length>0,l=!h.target||m&&-1!==g.indexOf(h.target),k=h.relatedTarget&&m&&-1!==g.indexOf(h.relatedTarget),j=h.client&&h.client===this;
return l||k||j?!0:!1
},a3=function(v){if("object"==typeof v&&v&&v.type){var u=bF(v),t=bI[this.id]&&bI[this.id].handlers["*"]||[],s=bI[this.id]&&bI[this.id].handlers[v.type]||[],r=t.concat(s);
if(r&&r.length){var q,p,o,n,m,e=this;
for(q=0,p=r.length;
p>q;
q++){o=r[q],n=e,"string"==typeof o&&"function"==typeof aT[o]&&(o=aT[o]),"object"==typeof o&&o&&"function"==typeof o.handleEvent&&(n=o,o=o.handleEvent),"function"==typeof o&&(m=ay({},v),bm(o,n,[m],u))
}}return this
}},av=function(b){return"string"==typeof b&&(b=[]),"number"!=typeof b.length?[b]:b
},al=function(e){if(e&&1===e.nodeType){var d=function(b){(b||(b=aT.event))&&("js"!==b._source&&(b.stopImmediatePropagation(),b.preventDefault()),delete b._source)
},f=function(a){(a||(a=aT.event))&&(d(a),ag.focus(e))
};
e.addEventListener("mouseover",f,!1),e.addEventListener("mouseout",d,!1),e.addEventListener("mouseenter",d,!1),e.addEventListener("mouseleave",d,!1),e.addEventListener("mousemove",d,!1),aq[e.zcClippingId]={mouseover:f,mouseout:d,mouseenter:d,mouseleave:d,mousemove:d}
}},ad=function(j){if(j&&1===j.nodeType){var h=aq[j.zcClippingId];
if("object"==typeof h&&h){for(var o,n,m=["move","leave","enter","out","over"],l=0,k=m.length;
k>l;
l++){o="mouse"+m[l],n=h[o],"function"==typeof n&&j.removeEventListener(o,n,!1)
}delete aq[j.zcClippingId]
}}};
ag._createClient=function(){ai.apply(this,az(arguments))
},ag.prototype.on=function(){return bT.apply(this,az(arguments))
},ag.prototype.off=function(){return bL.apply(this,az(arguments))
},ag.prototype.handlers=function(){return bB.apply(this,az(arguments))
},ag.prototype.emit=function(){return a1.apply(this,az(arguments))
},ag.prototype.clip=function(){return at.apply(this,az(arguments))
},ag.prototype.unclip=function(){return ak.apply(this,az(arguments))
},ag.prototype.elements=function(){return ac.apply(this,az(arguments))
},ag.prototype.destroy=function(){return bN.apply(this,az(arguments))
},ag.prototype.setText=function(b){return ag.setData("text/plain",b),this
},ag.prototype.setHtml=function(b){return ag.setData("text/html",b),this
},ag.prototype.setRichText=function(b){return ag.setData("application/rtf",b),this
},ag.prototype.setData=function(){return ag.setData.apply(this,az(arguments)),this
},ag.prototype.clearData=function(){return ag.clearData.apply(this,az(arguments)),this
},ag.prototype.getData=function(){return ag.getData.apply(this,az(arguments))
},"function"==typeof define&&define.amd?define(function(){return ag
}):"object"==typeof module&&module&&"object"==typeof module.exports&&module.exports?module.exports=ag:aZ.ZeroClipboard=ag
}(function(){return this||window
}());
/*! jQuery UI - v1.11.2 - 2014-11-24
* http://jqueryui.com
* Includes: core.js, widget.js, mouse.js, slider.js
* Copyright 2014 jQuery Foundation and other contributors; Licensed MIT */
(function(a){"function"==typeof define&&define.amd?define(["jquery"],a):a(jQuery)
})(function(g){function d(j,k){var p,e,m,l=j.nodeName.toLowerCase();
return"area"===l?(p=j.parentNode,e=p.name,j.href&&e&&"map"===p.nodeName.toLowerCase()?(m=g("img[usemap='#"+e+"']")[0],!!m&&c(m)):!1):(/input|select|textarea|button|object/.test(l)?!j.disabled:"a"===l?j.href||k:k)&&c(j)
}function c(a){return g.expr.filters.visible(a)&&!g(a).parents().addBack().filter(function(){return"hidden"===g.css(this,"visibility")
}).length
}g.ui=g.ui||{},g.extend(g.ui,{version:"1.11.2",keyCode:{BACKSPACE:8,COMMA:188,DELETE:46,DOWN:40,END:35,ENTER:13,ESCAPE:27,HOME:36,LEFT:37,PAGE_DOWN:34,PAGE_UP:33,PERIOD:190,RIGHT:39,SPACE:32,TAB:9,UP:38}}),g.fn.extend({scrollParent:function(k){var j=this.css("position"),l="absolute"===j,m=k?/(auto|scroll|hidden)/:/(auto|scroll)/,e=this.parents().filter(function(){var a=g(this);
return l&&"static"===a.css("position")?!1:m.test(a.css("overflow")+a.css("overflow-y")+a.css("overflow-x"))
}).eq(0);
return"fixed"!==j&&e.length?e:g(this[0].ownerDocument||document)
},uniqueId:function(){var a=0;
return function(){return this.each(function(){this.id||(this.id="ui-id-"+ ++a)
})
}
}(),removeUniqueId:function(){return this.each(function(){/^ui-id-\d+$/.test(this.id)&&g(this).removeAttr("id")
})
}}),g.extend(g.expr[":"],{data:g.expr.createPseudo?g.expr.createPseudo(function(a){return function(e){return !!g.data(e,a)
}
}):function(e,a,j){return !!g.data(e,j[3])
},focusable:function(a){return d(a,!isNaN(g.attr(a,"tabindex")))
},tabbable:function(a){var e=g.attr(a,"tabindex"),j=isNaN(e);
return(j||e>=0)&&d(a,!j)
}}),g("<a>").outerWidth(1).jquery||g.each(["Width","Height"],function(k,j){function l(q,o,r,n){return g.each(p,function(){o-=parseFloat(g.css(q,"padding"+this))||0,r&&(o-=parseFloat(g.css(q,"border"+this+"Width"))||0),n&&(o-=parseFloat(g.css(q,"margin"+this))||0)
}),o
}var p="Width"===j?["Left","Right"]:["Top","Bottom"],e=j.toLowerCase(),m={innerWidth:g.fn.innerWidth,innerHeight:g.fn.innerHeight,outerWidth:g.fn.outerWidth,outerHeight:g.fn.outerHeight};
g.fn["inner"+j]=function(a){return void 0===a?m["inner"+j].call(this):this.each(function(){g(this).css(e,l(this,a)+"px")
})
},g.fn["outer"+j]=function(a,o){return"number"!=typeof a?m["outer"+j].call(this,a):this.each(function(){g(this).css(e,l(this,a,!0,o)+"px")
})
}
}),g.fn.addBack||(g.fn.addBack=function(a){return this.add(null==a?this.prevObject:this.prevObject.filter(a))
}),g("<a>").data("a-b","a").removeData("a-b").data("a-b")&&(g.fn.removeData=function(a){return function(e){return arguments.length?a.call(this,g.camelCase(e)):a.call(this)
}
}(g.fn.removeData)),g.ui.ie=!!/msie [\w.]+/.exec(navigator.userAgent.toLowerCase()),g.fn.extend({focus:function(a){return function(e,j){return"number"==typeof e?this.each(function(){var k=this;
setTimeout(function(){g(k).focus(),j&&j.call(k)
},e)
}):a.apply(this,arguments)
}
}(g.fn.focus),disableSelection:function(){var a="onselectstart" in document.createElement("div")?"selectstart":"mousedown";
return function(){return this.bind(a+".ui-disableSelection",function(j){j.preventDefault()
})
}
}(),enableSelection:function(){return this.unbind(".ui-disableSelection")
},zIndex:function(e){if(void 0!==e){return this.css("zIndex",e)
}if(this.length){for(var a,j,k=g(this[0]);
k.length&&k[0]!==document;
){if(a=k.css("position"),("absolute"===a||"relative"===a||"fixed"===a)&&(j=parseInt(k.css("zIndex"),10),!isNaN(j)&&0!==j)){return j
}k=k.parent()
}}return 0
}}),g.ui.plugin={add:function(k,j,l){var m,e=g.ui[k].prototype;
for(m in l){e.plugins[m]=e.plugins[m]||[],e.plugins[m].push([j,l[m]])
}},call:function(o,l,k,m){var p,j=o.plugins[l];
if(j&&(m||o.element[0].parentNode&&11!==o.element[0].parentNode.nodeType)){for(p=0;
j.length>p;
p++){o.options[j[p][0]]&&j[p][1].apply(o.element,k)
}}}};
var f=0,h=Array.prototype.slice;
g.cleanData=function(a){return function(j){var k,m,e;
for(e=0;
null!=(m=j[e]);
e++){try{k=g._data(m,"events"),k&&k.remove&&g(m).triggerHandler("remove")
}catch(l){}}a(j)
}
}(g.cleanData),g.widget=function(v,p,w){var k,u,j,e,q={},m=v.split(".")[0];
return v=v.split(".")[1],k=m+"-"+v,w||(w=p,p=g.Widget),g.expr[":"][k.toLowerCase()]=function(a){return !!g.data(a,k)
},g[m]=g[m]||{},u=g[m][v],j=g[m][v]=function(l,a){return this._createWidget?(arguments.length&&this._createWidget(l,a),void 0):new j(l,a)
},g.extend(j,u,{version:w.version,_proto:g.extend({},w),_childConstructors:[]}),e=new p,e.options=g.widget.extend({},e.options),g.each(w,function(a,l){return g.isFunction(l)?(q[a]=function(){var o=function(){return p.prototype[a].apply(this,arguments)
},r=function(n){return p.prototype[a].apply(this,n)
};
return function(){var x,s=this._super,n=this._superApply;
return this._super=o,this._superApply=r,x=l.apply(this,arguments),this._super=s,this._superApply=n,x
}
}(),void 0):(q[a]=l,void 0)
}),j.prototype=g.widget.extend(e,{widgetEventPrefix:u?e.widgetEventPrefix||v:v},q,{constructor:j,namespace:m,widgetName:v,widgetFullName:k}),u?(g.each(u._childConstructors,function(l,a){var n=a.prototype;
g.widget(n.namespace+"."+n.widgetName,j,a._proto)
}),delete u._childConstructors):p._childConstructors.push(j),g.widget.bridge(v,j),j
},g.widget.extend=function(k){for(var j,l,e=h.call(arguments,1),n=0,m=e.length;
m>n;
n++){for(j in e[n]){l=e[n][j],e[n].hasOwnProperty(j)&&void 0!==l&&(k[j]=g.isPlainObject(l)?g.isPlainObject(k[j])?g.widget.extend({},k[j],l):g.widget.extend({},l):l)
}}return k
},g.widget.bridge=function(e,a){var j=a.prototype.widgetFullName||e;
g.fn[e]=function(k){var n="string"==typeof k,m=h.call(arguments,1),l=this;
return k=!n&&m.length?g.widget.extend.apply(null,[k].concat(m)):k,n?this.each(function(){var o,p=g.data(this,j);
return"instance"===k?(l=p,!1):p?g.isFunction(p[k])&&"_"!==k.charAt(0)?(o=p[k].apply(p,m),o!==p&&void 0!==o?(l=o&&o.jquery?l.pushStack(o.get()):o,!1):void 0):g.error("no such method '"+k+"' for "+e+" widget instance"):g.error("cannot call methods on "+e+" prior to initialization; attempted to call method '"+k+"'")
}):this.each(function(){var o=g.data(this,j);
o?(o.option(k||{}),o._init&&o._init()):g.data(this,j,new a(k,this))
}),l
}
},g.Widget=function(){},g.Widget._childConstructors=[],g.Widget.prototype={widgetName:"widget",widgetEventPrefix:"",defaultElement:"<div>",options:{disabled:!1,create:null},_createWidget:function(e,a){a=g(a||this.defaultElement||this)[0],this.element=g(a),this.uuid=f++,this.eventNamespace="."+this.widgetName+this.uuid,this.bindings=g(),this.hoverable=g(),this.focusable=g(),a!==this&&(g.data(a,this.widgetFullName,this),this._on(!0,this.element,{remove:function(j){j.target===a&&this.destroy()
}}),this.document=g(a.style?a.ownerDocument:a.document||a),this.window=g(this.document[0].defaultView||this.document[0].parentWindow)),this.options=g.widget.extend({},this.options,this._getCreateOptions(),e),this._create(),this._trigger("create",null,this._getCreateEventData()),this._init()
},_getCreateOptions:g.noop,_getCreateEventData:g.noop,_create:g.noop,_init:g.noop,destroy:function(){this._destroy(),this.element.unbind(this.eventNamespace).removeData(this.widgetFullName).removeData(g.camelCase(this.widgetFullName)),this.widget().unbind(this.eventNamespace).removeAttr("aria-disabled").removeClass(this.widgetFullName+"-disabled ui-state-disabled"),this.bindings.unbind(this.eventNamespace),this.hoverable.removeClass("ui-state-hover"),this.focusable.removeClass("ui-state-focus")
},_destroy:g.noop,widget:function(){return this.element
},option:function(k,j){var l,p,e,m=k;
if(0===arguments.length){return g.widget.extend({},this.options)
}if("string"==typeof k){if(m={},l=k.split("."),k=l.shift(),l.length){for(p=m[k]=g.widget.extend({},this.options[k]),e=0;
l.length-1>e;
e++){p[l[e]]=p[l[e]]||{},p=p[l[e]]
}if(k=l.pop(),1===arguments.length){return void 0===p[k]?null:p[k]
}p[k]=j
}else{if(1===arguments.length){return void 0===this.options[k]?null:this.options[k]
}m[k]=j
}}return this._setOptions(m),this
},_setOptions:function(j){var a;
for(a in j){this._setOption(a,j[a])
}return this
},_setOption:function(j,a){return this.options[j]=a,"disabled"===j&&(this.widget().toggleClass(this.widgetFullName+"-disabled",!!a),a&&(this.hoverable.removeClass("ui-state-hover"),this.focusable.removeClass("ui-state-focus"))),this
},enable:function(){return this._setOptions({disabled:!1})
},disable:function(){return this._setOptions({disabled:!0})
},_on:function(k,j,l){var m,e=this;
"boolean"!=typeof k&&(l=j,j=k,k=!1),l?(j=m=g(j),this.bindings=this.bindings.add(j)):(l=j,j=this.element,m=this.widget()),g.each(l,function(q,v){function t(){return k||e.options.disabled!==!0&&!g(this).hasClass("ui-state-disabled")?("string"==typeof v?e[v]:v).apply(e,arguments):void 0
}"string"!=typeof v&&(t.guid=v.guid=v.guid||t.guid||g.guid++);
var p=q.match(/^([\w:-]*)\s*(.*)$/),a=p[1]+e.eventNamespace,n=p[2];
n?m.delegate(n,a,t):j.bind(a,t)
})
},_off:function(e,a){a=(a||"").split(" ").join(this.eventNamespace+" ")+this.eventNamespace,e.unbind(a).undelegate(a),this.bindings=g(this.bindings.not(e).get()),this.focusable=g(this.focusable.not(e).get()),this.hoverable=g(this.hoverable.not(e).get())
},_delay:function(l,j){function a(){return("string"==typeof l?k[l]:l).apply(k,arguments)
}var k=this;
return setTimeout(a,j||0)
},_hoverable:function(a){this.hoverable=this.hoverable.add(a),this._on(a,{mouseenter:function(e){g(e.currentTarget).addClass("ui-state-hover")
},mouseleave:function(e){g(e.currentTarget).removeClass("ui-state-hover")
}})
},_focusable:function(a){this.focusable=this.focusable.add(a),this._on(a,{focusin:function(e){g(e.currentTarget).addClass("ui-state-focus")
},focusout:function(e){g(e.currentTarget).removeClass("ui-state-focus")
}})
},_trigger:function(k,j,l){var p,e,m=this.options[k];
if(l=l||{},j=g.Event(j),j.type=(k===this.widgetEventPrefix?k:this.widgetEventPrefix+k).toLowerCase(),j.target=this.element[0],e=j.originalEvent){for(p in e){p in j||(j[p]=e[p])
}}return this.element.trigger(j,l),!(g.isFunction(m)&&m.apply(this.element[0],[j].concat(l))===!1||j.isDefaultPrevented())
}},g.each({show:"fadeIn",hide:"fadeOut"},function(e,a){g.Widget.prototype["_"+e]=function(k,p,j){"string"==typeof p&&(p={effect:p});
var m,l=p?p===!0||"number"==typeof p?a:p.effect||a:e;
p=p||{},"number"==typeof p&&(p={duration:p}),m=!g.isEmptyObject(p),p.complete=j,p.delay&&k.delay(p.delay),m&&g.effects&&g.effects.effect[l]?k[e](p):l!==e&&k[l]?k[l](p.duration,p.easing,j):k.queue(function(n){g(this)[e](),j&&j.call(k[0]),n()
})
}
}),g.widget;
var b=!1;
g(document).mouseup(function(){b=!1
}),g.widget("ui.mouse",{version:"1.11.2",options:{cancel:"input,textarea,button,select,option",distance:1,delay:0},_mouseInit:function(){var a=this;
this.element.bind("mousedown."+this.widgetName,function(j){return a._mouseDown(j)
}).bind("click."+this.widgetName,function(e){return !0===g.data(e.target,a.widgetName+".preventClickEvent")?(g.removeData(e.target,a.widgetName+".preventClickEvent"),e.stopImmediatePropagation(),!1):void 0
}),this.started=!1
},_mouseDestroy:function(){this.element.unbind("."+this.widgetName),this._mouseMoveDelegate&&this.document.unbind("mousemove."+this.widgetName,this._mouseMoveDelegate).unbind("mouseup."+this.widgetName,this._mouseUpDelegate)
},_mouseDown:function(e){if(!b){this._mouseMoved=!1,this._mouseStarted&&this._mouseUp(e),this._mouseDownEvent=e;
var a=this,j=1===e.which,k="string"==typeof this.options.cancel&&e.target.nodeName?g(e.target).closest(this.options.cancel).length:!1;
return j&&!k&&this._mouseCapture(e)?(this.mouseDelayMet=!this.options.delay,this.mouseDelayMet||(this._mouseDelayTimer=setTimeout(function(){a.mouseDelayMet=!0
},this.options.delay)),this._mouseDistanceMet(e)&&this._mouseDelayMet(e)&&(this._mouseStarted=this._mouseStart(e)!==!1,!this._mouseStarted)?(e.preventDefault(),!0):(!0===g.data(e.target,this.widgetName+".preventClickEvent")&&g.removeData(e.target,this.widgetName+".preventClickEvent"),this._mouseMoveDelegate=function(l){return a._mouseMove(l)
},this._mouseUpDelegate=function(l){return a._mouseUp(l)
},this.document.bind("mousemove."+this.widgetName,this._mouseMoveDelegate).bind("mouseup."+this.widgetName,this._mouseUpDelegate),e.preventDefault(),b=!0,!0)):!0
}},_mouseMove:function(a){if(this._mouseMoved){if(g.ui.ie&&(!document.documentMode||9>document.documentMode)&&!a.button){return this._mouseUp(a)
}if(!a.which){return this._mouseUp(a)
}}return(a.which||a.button)&&(this._mouseMoved=!0),this._mouseStarted?(this._mouseDrag(a),a.preventDefault()):(this._mouseDistanceMet(a)&&this._mouseDelayMet(a)&&(this._mouseStarted=this._mouseStart(this._mouseDownEvent,a)!==!1,this._mouseStarted?this._mouseDrag(a):this._mouseUp(a)),!this._mouseStarted)
},_mouseUp:function(a){return this.document.unbind("mousemove."+this.widgetName,this._mouseMoveDelegate).unbind("mouseup."+this.widgetName,this._mouseUpDelegate),this._mouseStarted&&(this._mouseStarted=!1,a.target===this._mouseDownEvent.target&&g.data(a.target,this.widgetName+".preventClickEvent",!0),this._mouseStop(a)),b=!1,!1
},_mouseDistanceMet:function(a){return Math.max(Math.abs(this._mouseDownEvent.pageX-a.pageX),Math.abs(this._mouseDownEvent.pageY-a.pageY))>=this.options.distance
},_mouseDelayMet:function(){return this.mouseDelayMet
},_mouseStart:function(){},_mouseDrag:function(){},_mouseStop:function(){},_mouseCapture:function(){return !0
}}),g.widget("ui.slider",g.ui.mouse,{version:"1.11.2",widgetEventPrefix:"slide",options:{animate:!1,distance:0,max:100,min:0,orientation:"horizontal",range:!1,step:1,value:0,values:null,change:null,slide:null,start:null,stop:null},numPages:5,_create:function(){this._keySliding=!1,this._mouseSliding=!1,this._animateOff=!0,this._handleIndex=null,this._detectOrientation(),this._mouseInit(),this._calculateNewMax(),this.element.addClass("ui-slider ui-slider-"+this.orientation+" ui-widget ui-widget-content ui-corner-all"),this._refresh(),this._setOption("disabled",this.options.disabled),this._animateOff=!1
},_refresh:function(){this._createRange(),this._createHandles(),this._setupEvents(),this._refreshValue()
},_createHandles:function(){var k,j,l=this.options,p=this.element.find(".ui-slider-handle").addClass("ui-state-default ui-corner-all"),e="<span class='ui-slider-handle ui-state-default ui-corner-all' tabindex='0'></span>",m=[];
for(j=l.values&&l.values.length||1,p.length>j&&(p.slice(j).remove(),p=p.slice(0,j)),k=p.length;
j>k;
k++){m.push(e)
}this.handles=p.add(g(m.join("")).appendTo(this.element)),this.handle=this.handles.eq(0),this.handles.each(function(a){g(this).data("ui-slider-handle-index",a)
})
},_createRange:function(){var e=this.options,a="";
e.range?(e.range===!0&&(e.values?e.values.length&&2!==e.values.length?e.values=[e.values[0],e.values[0]]:g.isArray(e.values)&&(e.values=e.values.slice(0)):e.values=[this._valueMin(),this._valueMin()]),this.range&&this.range.length?this.range.removeClass("ui-slider-range-min ui-slider-range-max").css({left:"",bottom:""}):(this.range=g("<div></div>").appendTo(this.element),a="ui-slider-range ui-widget-header ui-corner-all"),this.range.addClass(a+("min"===e.range||"max"===e.range?" ui-slider-range-"+e.range:""))):(this.range&&this.range.remove(),this.range=null)
},_setupEvents:function(){this._off(this.handles),this._on(this.handles,this._handleEvents),this._hoverable(this.handles),this._focusable(this.handles)
},_destroy:function(){this.handles.remove(),this.range&&this.range.remove(),this.element.removeClass("ui-slider ui-slider-horizontal ui-slider-vertical ui-widget ui-widget-content ui-corner-all"),this._mouseDestroy()
},_mouseCapture:function(y){var p,z,k,w,j,e,q,m,x=this,v=this.options;
return v.disabled?!1:(this.elementSize={width:this.element.outerWidth(),height:this.element.outerHeight()},this.elementOffset=this.element.offset(),p={x:y.pageX,y:y.pageY},z=this._normValueFromMouse(p),k=this._valueMax()-this._valueMin()+1,this.handles.each(function(l){var a=Math.abs(z-x.values(l));
(k>a||k===a&&(l===x._lastChangedValue||x.values(l)===v.min))&&(k=a,w=g(this),j=l)
}),e=this._start(y,j),e===!1?!1:(this._mouseSliding=!0,this._handleIndex=j,w.addClass("ui-state-active").focus(),q=w.offset(),m=!g(y.target).parents().addBack().is(".ui-slider-handle"),this._clickOffset=m?{left:0,top:0}:{left:y.pageX-q.left-w.width()/2,top:y.pageY-q.top-w.height()/2-(parseInt(w.css("borderTopWidth"),10)||0)-(parseInt(w.css("borderBottomWidth"),10)||0)+(parseInt(w.css("marginTop"),10)||0)},this.handles.hasClass("ui-state-hover")||this._slide(y,j,z),this._animateOff=!0,!0))
},_mouseStart:function(){return !0
},_mouseDrag:function(k){var j={x:k.pageX,y:k.pageY},a=this._normValueFromMouse(j);
return this._slide(k,this._handleIndex,a),!1
},_mouseStop:function(a){return this.handles.removeClass("ui-state-active"),this._mouseSliding=!1,this._stop(a,this._handleIndex),this._change(a,this._handleIndex),this._handleIndex=null,this._clickOffset=null,this._animateOff=!1,!1
},_detectOrientation:function(){this.orientation="vertical"===this.options.orientation?"vertical":"horizontal"
},_normValueFromMouse:function(o){var l,k,m,p,j;
return"horizontal"===this.orientation?(l=this.elementSize.width,k=o.x-this.elementOffset.left-(this._clickOffset?this._clickOffset.left:0)):(l=this.elementSize.height,k=o.y-this.elementOffset.top-(this._clickOffset?this._clickOffset.top:0)),m=k/l,m>1&&(m=1),0>m&&(m=0),"vertical"===this.orientation&&(m=1-m),p=this._valueMax()-this._valueMin(),j=this._valueMin()+m*p,this._trimAlignValue(j)
},_start:function(k,j){var a={handle:this.handles[j],value:this.value()};
return this.options.values&&this.options.values.length&&(a.value=this.values(j),a.values=this.values()),this._trigger("start",k,a)
},_slide:function(o,l,k){var m,p,j;
this.options.values&&this.options.values.length?(m=this.values(l?0:1),2===this.options.values.length&&this.options.range===!0&&(0===l&&k>m||1===l&&m>k)&&(k=m),k!==this.values(l)&&(p=this.values(),p[l]=k,j=this._trigger("slide",o,{handle:this.handles[l],value:k,values:p}),m=this.values(l?0:1),j!==!1&&this.values(l,k))):k!==this.value()&&(j=this._trigger("slide",o,{handle:this.handles[l],value:k}),j!==!1&&this.value(k))
},_stop:function(k,j){var a={handle:this.handles[j],value:this.value()};
this.options.values&&this.options.values.length&&(a.value=this.values(j),a.values=this.values()),this._trigger("stop",k,a)
},_change:function(k,j){if(!this._keySliding&&!this._mouseSliding){var a={handle:this.handles[j],value:this.value()};
this.options.values&&this.options.values.length&&(a.value=this.values(j),a.values=this.values()),this._lastChangedValue=j,this._trigger("change",k,a)
}},value:function(a){return arguments.length?(this.options.value=this._trimAlignValue(a),this._refreshValue(),this._change(null,0),void 0):this._value()
},values:function(k,j){var l,m,e;
if(arguments.length>1){return this.options.values[k]=this._trimAlignValue(j),this._refreshValue(),this._change(null,k),void 0
}if(!arguments.length){return this._values()
}if(!g.isArray(arguments[0])){return this.options.values&&this.options.values.length?this._values(k):this.value()
}for(l=this.options.values,m=arguments[0],e=0;
l.length>e;
e+=1){l[e]=this._trimAlignValue(m[e]),this._change(null,e)
}this._refreshValue()
},_setOption:function(e,a){var j,k=0;
switch("range"===e&&this.options.range===!0&&("min"===a?(this.options.value=this._values(0),this.options.values=null):"max"===a&&(this.options.value=this._values(this.options.values.length-1),this.options.values=null)),g.isArray(this.options.values)&&(k=this.options.values.length),"disabled"===e&&this.element.toggleClass("ui-state-disabled",!!a),this._super(e,a),e){case"orientation":this._detectOrientation(),this.element.removeClass("ui-slider-horizontal ui-slider-vertical").addClass("ui-slider-"+this.orientation),this._refreshValue(),this.handles.css("horizontal"===a?"bottom":"left","");
break;
case"value":this._animateOff=!0,this._refreshValue(),this._change(null,0),this._animateOff=!1;
break;
case"values":for(this._animateOff=!0,this._refreshValue(),j=0;
k>j;
j+=1){this._change(null,j)
}this._animateOff=!1;
break;
case"step":case"min":case"max":this._animateOff=!0,this._calculateNewMax(),this._refreshValue(),this._animateOff=!1;
break;
case"range":this._animateOff=!0,this._refresh(),this._animateOff=!1
}},_value:function(){var a=this.options.value;
return a=this._trimAlignValue(a)
},_values:function(l){var j,a,k;
if(arguments.length){return j=this.options.values[l],j=this._trimAlignValue(j)
}if(this.options.values&&this.options.values.length){for(a=this.options.values.slice(),k=0;
a.length>k;
k+=1){a[k]=this._trimAlignValue(a[k])
}return a
}return[]
},_trimAlignValue:function(l){if(this._valueMin()>=l){return this._valueMin()
}if(l>=this._valueMax()){return this._valueMax()
}var j=this.options.step>0?this.options.step:1,a=(l-this._valueMin())%j,k=l-a;
return 2*Math.abs(a)>=j&&(k+=a>0?j:-j),parseFloat(k.toFixed(5))
},_calculateNewMax:function(){var a=(this.options.max-this._valueMin())%this.options.step;
this.max=this.options.max-a
},_valueMin:function(){return this.options.min
},_valueMax:function(){return this.max
},_refreshValue:function(){var x,p,y,k,v,j=this.options.range,e=this.options,q=this,m=this._animateOff?!1:e.animate,w={};
this.options.values&&this.options.values.length?this.handles.each(function(a){p=100*((q.values(a)-q._valueMin())/(q._valueMax()-q._valueMin())),w["horizontal"===q.orientation?"left":"bottom"]=p+"%",g(this).stop(1,1)[m?"animate":"css"](w,e.animate),q.options.range===!0&&("horizontal"===q.orientation?(0===a&&q.range.stop(1,1)[m?"animate":"css"]({left:p+"%"},e.animate),1===a&&q.range[m?"animate":"css"]({width:p-x+"%"},{queue:!1,duration:e.animate})):(0===a&&q.range.stop(1,1)[m?"animate":"css"]({bottom:p+"%"},e.animate),1===a&&q.range[m?"animate":"css"]({height:p-x+"%"},{queue:!1,duration:e.animate}))),x=p
}):(y=this.value(),k=this._valueMin(),v=this._valueMax(),p=v!==k?100*((y-k)/(v-k)):0,w["horizontal"===this.orientation?"left":"bottom"]=p+"%",this.handle.stop(1,1)[m?"animate":"css"](w,e.animate),"min"===j&&"horizontal"===this.orientation&&this.range.stop(1,1)[m?"animate":"css"]({width:p+"%"},e.animate),"max"===j&&"horizontal"===this.orientation&&this.range[m?"animate":"css"]({width:100-p+"%"},{queue:!1,duration:e.animate}),"min"===j&&"vertical"===this.orientation&&this.range.stop(1,1)[m?"animate":"css"]({height:p+"%"},e.animate),"max"===j&&"vertical"===this.orientation&&this.range[m?"animate":"css"]({height:100-p+"%"},{queue:!1,duration:e.animate}))
},_handleEvents:{keydown:function(k){var j,l,p,e,m=g(k.target).data("ui-slider-handle-index");
switch(k.keyCode){case g.ui.keyCode.HOME:case g.ui.keyCode.END:case g.ui.keyCode.PAGE_UP:case g.ui.keyCode.PAGE_DOWN:case g.ui.keyCode.UP:case g.ui.keyCode.RIGHT:case g.ui.keyCode.DOWN:case g.ui.keyCode.LEFT:if(k.preventDefault(),!this._keySliding&&(this._keySliding=!0,g(k.target).addClass("ui-state-active"),j=this._start(k,m),j===!1)){return
}}switch(e=this.options.step,l=p=this.options.values&&this.options.values.length?this.values(m):this.value(),k.keyCode){case g.ui.keyCode.HOME:p=this._valueMin();
break;
case g.ui.keyCode.END:p=this._valueMax();
break;
case g.ui.keyCode.PAGE_UP:p=this._trimAlignValue(l+(this._valueMax()-this._valueMin())/this.numPages);
break;
case g.ui.keyCode.PAGE_DOWN:p=this._trimAlignValue(l-(this._valueMax()-this._valueMin())/this.numPages);
break;
case g.ui.keyCode.UP:case g.ui.keyCode.RIGHT:if(l===this._valueMax()){return
}p=this._trimAlignValue(l+e);
break;
case g.ui.keyCode.DOWN:case g.ui.keyCode.LEFT:if(l===this._valueMin()){return
}p=this._trimAlignValue(l-e)
}this._slide(k,m,p)
},keyup:function(e){var a=g(e.target).data("ui-slider-handle-index");
this._keySliding&&(this._keySliding=!1,this._stop(e,a),this._change(e,a),g(e.target).removeClass("ui-state-active"))
}}})
});
/*!
 * jScrollPane - v2.0.20 - 2014-10-23
 * http://jscrollpane.kelvinluck.com/
 *
 * Copyright (c) 2014 Kelvin Luck
 * Dual licensed under the MIT or GPL licenses.
 */
(function(c,b){var a=function(d){return c(d,b)
};
if(typeof define==="function"&&define.amd){define(["jquery"],a)
}else{if(typeof exports==="object"){module.exports=a
}else{a(jQuery)
}}}(function(b,a,c){b.fn.jScrollPane=function(e){function d(E,P){var az,R=this,Z,ak,w,am,U,aa,z,r,aA,aF,av,j,J,h,k,ab,V,aq,Y,u,B,ar,ag,an,H,m,au,ay,y,aw,aI,f,M,aj=true,Q=true,aH=false,l=false,ap=E.clone(false,false).empty(),ad=b.fn.mwheelIntent?"mwheelIntent.jsp":"mousewheel.jsp";
if(E.css("box-sizing")==="border-box"){aI=0;
f=0
}else{aI=E.css("paddingTop")+" "+E.css("paddingRight")+" "+E.css("paddingBottom")+" "+E.css("paddingLeft");
f=(parseInt(E.css("paddingLeft"),10)||0)+(parseInt(E.css("paddingRight"),10)||0)
}function at(aR){var aM,aO,aN,aK,aJ,aQ,aP=false,aL=false;
az=aR;
if(Z===c){aJ=E.scrollTop();
aQ=E.scrollLeft();
E.css({overflow:"hidden",padding:0});
ak=E.innerWidth()+f;
w=E.innerHeight();
E.width(ak);
Z=b('<div class="jspPane" />').css("padding",aI).append(E.children());
am=b('<div class="jspContainer" />').css({width:ak+"px",height:w+"px"}).append(Z).appendTo(E)
}else{E.css("width","");
aP=az.stickToBottom&&L();
aL=az.stickToRight&&C();
aK=E.innerWidth()+f!=ak||E.outerHeight()!=w;
if(aK){ak=E.innerWidth()+f;
w=E.innerHeight();
am.css({width:ak+"px",height:w+"px"})
}if(!aK&&M==U&&Z.outerHeight()==aa){E.width(ak);
return
}M=U;
Z.css("width","");
E.width(ak);
am.find(">.jspVerticalBar,>.jspHorizontalBar").remove().end()
}Z.css("overflow","auto");
if(aR.contentWidth){U=aR.contentWidth
}else{U=Z[0].scrollWidth
}aa=Z[0].scrollHeight;
Z.css("overflow","");
z=U/ak;
r=aa/w;
aA=r>1;
aF=z>1;
if(!(aF||aA)){E.removeClass("jspScrollable");
Z.css({top:0,left:0,width:am.width()-f});
o();
F();
S();
x()
}else{E.addClass("jspScrollable");
aM=az.maintainPosition&&(J||ab);
if(aM){aO=aD();
aN=aB()
}aG();
A();
G();
if(aM){O(aL?(U-ak):aO,false);
N(aP?(aa-w):aN,false)
}K();
ah();
ao();
if(az.enableKeyboardNavigation){T()
}if(az.clickOnTrack){q()
}D();
if(az.hijackInternalLinks){n()
}}if(az.autoReinitialise&&!aw){aw=setInterval(function(){at(az)
},az.autoReinitialiseDelay)
}else{if(!az.autoReinitialise&&aw){clearInterval(aw)
}}aJ&&E.scrollTop(0)&&N(aJ,false);
aQ&&E.scrollLeft(0)&&O(aQ,false);
E.trigger("jsp-initialised",[aF||aA])
}function aG(){if(aA){am.append(b('<div class="jspVerticalBar" />').append(b('<div class="jspCap jspCapTop" />'),b('<div class="jspTrack" />').append(b('<div class="jspDrag" />').append(b('<div class="jspDragTop" />'),b('<div class="jspDragBottom" />'))),b('<div class="jspCap jspCapBottom" />')));
V=am.find(">.jspVerticalBar");
aq=V.find(">.jspTrack");
av=aq.find(">.jspDrag");
if(az.showArrows){ar=b('<a class="jspArrow jspArrowUp" />').bind("mousedown.jsp",aE(0,-1)).bind("click.jsp",aC);
ag=b('<a class="jspArrow jspArrowDown" />').bind("mousedown.jsp",aE(0,1)).bind("click.jsp",aC);
if(az.arrowScrollOnHover){ar.bind("mouseover.jsp",aE(0,-1,ar));
ag.bind("mouseover.jsp",aE(0,1,ag))
}al(aq,az.verticalArrowPositions,ar,ag)
}u=w;
am.find(">.jspVerticalBar>.jspCap:visible,>.jspVerticalBar>.jspArrow").each(function(){u-=b(this).outerHeight()
});
av.hover(function(){av.addClass("jspHover")
},function(){av.removeClass("jspHover")
}).bind("mousedown.jsp",function(aJ){b("html").bind("dragstart.jsp selectstart.jsp",aC);
av.addClass("jspActive");
var s=aJ.pageY-av.position().top;
b("html").bind("mousemove.jsp",function(aK){W(aK.pageY-s,false)
}).bind("mouseup.jsp mouseleave.jsp",ax);
return false
});
p()
}}function p(){aq.height(u+"px");
J=0;
Y=az.verticalGutter+aq.outerWidth();
Z.width(ak-Y-f);
try{if(V.position().left===0){Z.css("margin-left",Y+"px")
}}catch(s){}}function A(){if(aF){am.append(b('<div class="jspHorizontalBar" />').append(b('<div class="jspCap jspCapLeft" />'),b('<div class="jspTrack" />').append(b('<div class="jspDrag" />').append(b('<div class="jspDragLeft" />'),b('<div class="jspDragRight" />'))),b('<div class="jspCap jspCapRight" />')));
an=am.find(">.jspHorizontalBar");
H=an.find(">.jspTrack");
h=H.find(">.jspDrag");
if(az.showArrows){ay=b('<a class="jspArrow jspArrowLeft" />').bind("mousedown.jsp",aE(-1,0)).bind("click.jsp",aC);
y=b('<a class="jspArrow jspArrowRight" />').bind("mousedown.jsp",aE(1,0)).bind("click.jsp",aC);
if(az.arrowScrollOnHover){ay.bind("mouseover.jsp",aE(-1,0,ay));
y.bind("mouseover.jsp",aE(1,0,y))
}al(H,az.horizontalArrowPositions,ay,y)
}h.hover(function(){h.addClass("jspHover")
},function(){h.removeClass("jspHover")
}).bind("mousedown.jsp",function(aJ){b("html").bind("dragstart.jsp selectstart.jsp",aC);
h.addClass("jspActive");
var s=aJ.pageX-h.position().left;
b("html").bind("mousemove.jsp",function(aK){X(aK.pageX-s,false)
}).bind("mouseup.jsp mouseleave.jsp",ax);
return false
});
m=am.innerWidth();
ai()
}}function ai(){am.find(">.jspHorizontalBar>.jspCap:visible,>.jspHorizontalBar>.jspArrow").each(function(){m-=b(this).outerWidth()
});
H.width(m+"px");
ab=0
}function G(){if(aF&&aA){var aJ=H.outerHeight(),s=aq.outerWidth();
u-=aJ;
b(an).find(">.jspCap:visible,>.jspArrow").each(function(){m+=b(this).outerWidth()
});
m-=s;
w-=s;
ak-=aJ;
H.parent().append(b('<div class="jspCorner" />').css("width",aJ+"px"));
p();
ai()
}if(aF){Z.width((am.outerWidth()-f)+"px")
}aa=Z.outerHeight();
r=aa/w;
if(aF){au=Math.ceil(1/z*m);
if(au>az.horizontalDragMaxWidth){au=az.horizontalDragMaxWidth
}else{if(au<az.horizontalDragMinWidth){au=az.horizontalDragMinWidth
}}h.width(au+"px");
k=m-au;
af(ab)
}if(aA){B=Math.ceil(1/r*u);
if(B>az.verticalDragMaxHeight){B=az.verticalDragMaxHeight
}else{if(B<az.verticalDragMinHeight){B=az.verticalDragMinHeight
}}av.height(B+"px");
j=u-B;
ae(J)
}}function al(aK,aM,aJ,s){var aO="before",aL="after",aN;
if(aM=="os"){aM=/Mac/.test(navigator.platform)?"after":"split"
}if(aM==aO){aL=aM
}else{if(aM==aL){aO=aM;
aN=aJ;
aJ=s;
s=aN
}}aK[aO](aJ)[aL](s)
}function aE(aJ,s,aK){return function(){I(aJ,s,this,aK);
this.blur();
return false
}
}function I(aM,aL,aP,aO){aP=b(aP).addClass("jspActive");
var aN,aK,aJ=true,s=function(){if(aM!==0){R.scrollByX(aM*az.arrowButtonSpeed)
}if(aL!==0){R.scrollByY(aL*az.arrowButtonSpeed)
}aK=setTimeout(s,aJ?az.initialDelay:az.arrowRepeatFreq);
aJ=false
};
s();
aN=aO?"mouseout.jsp":"mouseup.jsp";
aO=aO||b("html");
aO.bind(aN,function(){aP.removeClass("jspActive");
aK&&clearTimeout(aK);
aK=null;
aO.unbind(aN)
})
}function q(){x();
if(aA){aq.bind("mousedown.jsp",function(aO){if(aO.originalTarget===c||aO.originalTarget==aO.currentTarget){var aM=b(this),aP=aM.offset(),aN=aO.pageY-aP.top-J,aK,aJ=true,s=function(){var aS=aM.offset(),aT=aO.pageY-aS.top-B/2,aQ=w*az.scrollPagePercent,aR=j*aQ/(aa-w);
if(aN<0){if(J-aR>aT){R.scrollByY(-aQ)
}else{W(aT)
}}else{if(aN>0){if(J+aR<aT){R.scrollByY(aQ)
}else{W(aT)
}}else{aL();
return
}}aK=setTimeout(s,aJ?az.initialDelay:az.trackClickRepeatFreq);
aJ=false
},aL=function(){aK&&clearTimeout(aK);
aK=null;
b(document).unbind("mouseup.jsp",aL)
};
s();
b(document).bind("mouseup.jsp",aL);
return false
}})
}if(aF){H.bind("mousedown.jsp",function(aO){if(aO.originalTarget===c||aO.originalTarget==aO.currentTarget){var aM=b(this),aP=aM.offset(),aN=aO.pageX-aP.left-ab,aK,aJ=true,s=function(){var aS=aM.offset(),aT=aO.pageX-aS.left-au/2,aQ=ak*az.scrollPagePercent,aR=k*aQ/(U-ak);
if(aN<0){if(ab-aR>aT){R.scrollByX(-aQ)
}else{X(aT)
}}else{if(aN>0){if(ab+aR<aT){R.scrollByX(aQ)
}else{X(aT)
}}else{aL();
return
}}aK=setTimeout(s,aJ?az.initialDelay:az.trackClickRepeatFreq);
aJ=false
},aL=function(){aK&&clearTimeout(aK);
aK=null;
b(document).unbind("mouseup.jsp",aL)
};
s();
b(document).bind("mouseup.jsp",aL);
return false
}})
}}function x(){if(H){H.unbind("mousedown.jsp")
}if(aq){aq.unbind("mousedown.jsp")
}}function ax(){b("html").unbind("dragstart.jsp selectstart.jsp mousemove.jsp mouseup.jsp mouseleave.jsp");
if(av){av.removeClass("jspActive")
}if(h){h.removeClass("jspActive")
}}function W(s,aJ){if(!aA){return
}if(s<0){s=0
}else{if(s>j){s=j
}}if(aJ===c){aJ=az.animateScroll
}if(aJ){R.animate(av,"top",s,ae)
}else{av.css("top",s);
ae(s)
}}function ae(aJ){if(aJ===c){aJ=av.position().top
}am.scrollTop(0);
J=aJ||0;
var aM=J===0,aK=J==j,aL=aJ/j,s=-aL*(aa-w);
if(aj!=aM||aH!=aK){aj=aM;
aH=aK;
E.trigger("jsp-arrow-change",[aj,aH,Q,l])
}v(aM,aK);
Z.css("top",s);
E.trigger("jsp-scroll-y",[-s,aM,aK]).trigger("scroll")
}function X(aJ,s){if(!aF){return
}if(aJ<0){aJ=0
}else{if(aJ>k){aJ=k
}}if(s===c){s=az.animateScroll
}if(s){R.animate(h,"left",aJ,af)
}else{h.css("left",aJ);
af(aJ)
}}function af(aJ){if(aJ===c){aJ=h.position().left
}am.scrollTop(0);
ab=aJ||0;
var aM=ab===0,aL=ab==k,aK=aJ/k,s=-aK*(U-ak);
if(Q!=aM||l!=aL){Q=aM;
l=aL;
E.trigger("jsp-arrow-change",[aj,aH,Q,l])
}t(aM,aL);
Z.css("left",s);
E.trigger("jsp-scroll-x",[-s,aM,aL]).trigger("scroll")
}function v(aJ,s){if(az.showArrows){ar[aJ?"addClass":"removeClass"]("jspDisabled");
ag[s?"addClass":"removeClass"]("jspDisabled")
}}function t(aJ,s){if(az.showArrows){ay[aJ?"addClass":"removeClass"]("jspDisabled");
y[s?"addClass":"removeClass"]("jspDisabled")
}}function N(s,aJ){var aK=s/(aa-w);
W(aK*j,aJ)
}function O(aJ,s){var aK=aJ/(U-ak);
X(aK*k,s)
}function ac(aW,aR,aK){var aO,aL,aM,s=0,aV=0,aJ,aQ,aP,aT,aS,aU;
try{aO=b(aW)
}catch(aN){return
}aL=aO.outerHeight();
aM=aO.outerWidth();
am.scrollTop(0);
am.scrollLeft(0);
while(!aO.is(".jspPane")){s+=aO.position().top;
aV+=aO.position().left;
aO=aO.offsetParent();
if(/^body|html$/i.test(aO[0].nodeName)){return
}}aJ=aB();
aP=aJ+w;
if(s<aJ||aR){aS=s-az.horizontalGutter
}else{if(s+aL>aP){aS=s-w+aL+az.horizontalGutter
}}if(!isNaN(aS)){N(aS,aK)
}aQ=aD();
aT=aQ+ak;
if(aV<aQ||aR){aU=aV-az.horizontalGutter
}else{if(aV+aM>aT){aU=aV-ak+aM+az.horizontalGutter
}}if(!isNaN(aU)){O(aU,aK)
}}function aD(){return -Z.position().left
}function aB(){return -Z.position().top
}function L(){var s=aa-w;
return(s>20)&&(s-aB()<10)
}function C(){var s=U-ak;
return(s>20)&&(s-aD()<10)
}function ah(){am.unbind(ad).bind(ad,function(aN,aO,aL,aJ){if(!ab){ab=0
}if(!J){J=0
}var aK=ab,s=J,aM=aN.deltaFactor||az.mouseWheelSpeed;
R.scrollBy(aL*aM,-aJ*aM,false);
return aK==ab&&s==J
})
}function o(){am.unbind(ad)
}function aC(){return false
}function K(){Z.find(":input,a").unbind("focus.jsp").bind("focus.jsp",function(s){ac(s.target,false)
})
}function F(){Z.find(":input,a").unbind("focus.jsp")
}function T(){var s,aJ,aL=[];
aF&&aL.push(an[0]);
aA&&aL.push(V[0]);
Z.focus(function(){E.focus()
});
E.attr("tabindex",0).unbind("keydown.jsp keypress.jsp").bind("keydown.jsp",function(aO){if(aO.target!==this&&!(aL.length&&b(aO.target).closest(aL).length)){return
}var aN=ab,aM=J;
switch(aO.keyCode){case 40:case 38:case 34:case 32:case 33:case 39:case 37:s=aO.keyCode;
aK();
break;
case 35:N(aa-w);
s=null;
break;
case 36:N(0);
s=null;
break
}aJ=aO.keyCode==s&&aN!=ab||aM!=J;
return !aJ
}).bind("keypress.jsp",function(aM){if(aM.keyCode==s){aK()
}return !aJ
});
if(az.hideFocus){E.css("outline","none");
if("hideFocus" in am[0]){E.attr("hideFocus",true)
}}else{E.css("outline","");
if("hideFocus" in am[0]){E.attr("hideFocus",false)
}}function aK(){var aN=ab,aM=J;
switch(s){case 40:R.scrollByY(az.keyboardSpeed,false);
break;
case 38:R.scrollByY(-az.keyboardSpeed,false);
break;
case 34:case 32:R.scrollByY(w*az.scrollPagePercent,false);
break;
case 33:R.scrollByY(-w*az.scrollPagePercent,false);
break;
case 39:R.scrollByX(az.keyboardSpeed,false);
break;
case 37:R.scrollByX(-az.keyboardSpeed,false);
break
}aJ=aN!=ab||aM!=J;
return aJ
}}function S(){E.attr("tabindex","-1").removeAttr("tabindex").unbind("keydown.jsp keypress.jsp")
}function D(){if(location.hash&&location.hash.length>1){var aL,aJ,aK=escape(location.hash.substr(1));
try{aL=b("#"+aK+', a[name="'+aK+'"]')
}catch(s){return
}if(aL.length&&Z.find(aK)){if(am.scrollTop()===0){aJ=setInterval(function(){if(am.scrollTop()>0){ac(aL,true);
b(document).scrollTop(am.position().top);
clearInterval(aJ)
}},50)
}else{ac(aL,true);
b(document).scrollTop(am.position().top)
}}}}function n(){if(b(document.body).data("jspHijack")){return
}b(document.body).data("jspHijack",true);
b(document.body).delegate("a[href*=#]","click",function(s){var aJ=this.href.substr(0,this.href.indexOf("#")),aL=location.href,aP,aQ,aK,aN,aM,aO;
if(location.href.indexOf("#")!==-1){aL=location.href.substr(0,location.href.indexOf("#"))
}if(aJ!==aL){return
}aP=escape(this.href.substr(this.href.indexOf("#")+1));
aQ;
try{aQ=b("#"+aP+', a[name="'+aP+'"]')
}catch(aR){return
}if(!aQ.length){return
}aK=aQ.closest(".jspScrollable");
aN=aK.data("jsp");
aN.scrollToElement(aQ,true);
if(aK[0].scrollIntoView){aM=b(a).scrollTop();
aO=aQ.offset().top;
if(aO<aM||aO>aM+b(a).height()){aK[0].scrollIntoView()
}}s.preventDefault()
})
}function ao(){var aK,aJ,aM,aL,aN,s=false;
am.unbind("touchstart.jsp touchmove.jsp touchend.jsp click.jsp-touchclick").bind("touchstart.jsp",function(aO){var aP=aO.originalEvent.touches[0];
aK=aD();
aJ=aB();
aM=aP.pageX;
aL=aP.pageY;
aN=false;
s=true
}).bind("touchmove.jsp",function(aR){if(!s){return
}var aQ=aR.originalEvent.touches[0],aP=ab,aO=J;
R.scrollTo(aK+aM-aQ.pageX,aJ+aL-aQ.pageY);
aN=aN||Math.abs(aM-aQ.pageX)>5||Math.abs(aL-aQ.pageY)>5;
return aP==ab&&aO==J
}).bind("touchend.jsp",function(aO){s=false
}).bind("click.jsp-touchclick",function(aO){if(aN){aN=false;
return false
}})
}function g(){var s=aB(),aJ=aD();
E.removeClass("jspScrollable").unbind(".jsp");
E.replaceWith(ap.append(Z.children()));
ap.scrollTop(s);
ap.scrollLeft(aJ);
if(aw){clearInterval(aw)
}}b.extend(R,{reinitialise:function(aJ){aJ=b.extend({},az,aJ);
at(aJ)
},scrollToElement:function(aK,aJ,s){ac(aK,aJ,s)
},scrollTo:function(aK,s,aJ){O(aK,aJ);
N(s,aJ)
},scrollToX:function(aJ,s){O(aJ,s)
},scrollToY:function(s,aJ){N(s,aJ)
},scrollToPercentX:function(aJ,s){O(aJ*(U-ak),s)
},scrollToPercentY:function(aJ,s){N(aJ*(aa-w),s)
},scrollBy:function(aJ,s,aK){R.scrollByX(aJ,aK);
R.scrollByY(s,aK)
},scrollByX:function(s,aK){var aJ=aD()+Math[s<0?"floor":"ceil"](s),aL=aJ/(U-ak);
X(aL*k,aK)
},scrollByY:function(s,aK){var aJ=aB()+Math[s<0?"floor":"ceil"](s),aL=aJ/(aa-w);
W(aL*j,aK)
},positionDragX:function(s,aJ){X(s,aJ)
},positionDragY:function(aJ,s){W(aJ,s)
},animate:function(aJ,aM,s,aL){var aK={};
aK[aM]=s;
aJ.animate(aK,{duration:az.animateDuration,easing:az.animateEase,queue:false,step:aL})
},getContentPositionX:function(){return aD()
},getContentPositionY:function(){return aB()
},getContentWidth:function(){return U
},getContentHeight:function(){return aa
},getPercentScrolledX:function(){return aD()/(U-ak)
},getPercentScrolledY:function(){return aB()/(aa-w)
},getIsScrollableH:function(){return aF
},getIsScrollableV:function(){return aA
},getContentPane:function(){return Z
},scrollToBottom:function(s){W(j,s)
},hijackInternalLinks:b.noop,destroy:function(){g()
}});
at(P)
}e=b.extend({},b.fn.jScrollPane.defaults,e);
b.each(["arrowButtonSpeed","trackClickSpeed","keyboardSpeed"],function(){e[this]=e[this]||e.speed
});
return this.each(function(){var f=b(this),g=f.data("jsp");
if(g){g.reinitialise(e)
}else{b("script",f).filter('[type="text/javascript"],:not([type])').remove();
g=new d(f,e);
f.data("jsp",g)
}})
};
b.fn.jScrollPane.defaults={showArrows:false,maintainPosition:true,stickToBottom:false,stickToRight:false,clickOnTrack:true,autoReinitialise:false,autoReinitialiseDelay:500,verticalDragMinHeight:0,verticalDragMaxHeight:99999,horizontalDragMinWidth:0,horizontalDragMaxWidth:99999,contentWidth:c,animateScroll:false,animateDuration:300,animateEase:"linear",hijackInternalLinks:false,verticalGutter:4,horizontalGutter:4,mouseWheelSpeed:3,arrowButtonSpeed:0,arrowRepeatFreq:50,arrowScrollOnHover:false,trackClickSpeed:0,trackClickRepeatFreq:70,verticalArrowPositions:"split",horizontalArrowPositions:"split",enableKeyboardNavigation:true,hideFocus:false,keyboardSpeed:0,initialDelay:300,speed:30,scrollPagePercent:0.8}
},this));
(function(g){var a,h,b,j,d,c;
var f={loadingNotice:"Loading image",errorNotice:"The image could not be loaded",errorDuration:2500,preventClicks:true,onShow:undefined,onHide:undefined};
function e(l,k){this.$target=g(l);
this.opts=g.extend({},f,k);
if(this.isOpen===undefined){this._init()
}return this
}e.prototype._init=function(){var k=this;
this.$link=this.$target.find("a");
this.$image=this.$target.find("img");
this.$flyout=g('<div class="easyzoom-flyout" />');
this.$notice=g('<div class="easyzoom-notice" />');
this.$target.on("mouseenter.easyzoom touchstart.easyzoom",function(l){k.isMouseOver=true;
if(!l.originalEvent.touches||l.originalEvent.touches.length===1){l.preventDefault();
k.show(l,true)
}}).on("mousemove.easyzoom touchmove.easyzoom",function(l){if(k.isOpen){l.preventDefault();
k._move(l)
}}).on("mouseleave.easyzoom touchend.easyzoom",function(){k.isMouseOver=false;
if(k.isOpen){k.hide()
}});
if(this.opts.preventClicks){this.$target.on("click.easyzoom","a",function(l){l.preventDefault()
})
}};
e.prototype.show=function(p,q){var l,o,k,n;
var m=this;
if(!this.isReady){this._load(this.$link.attr("href"),function(){if(m.isMouseOver||!q){m.show(p)
}});
return
}this.$target.append(this.$flyout);
l=this.$target.width();
o=this.$target.height();
k=this.$flyout.width();
n=this.$flyout.height();
a=this.$zoom.width()-k;
h=this.$zoom.height()-n;
b=a/l;
j=h/o;
this.isOpen=true;
if(this.opts.onShow){this.opts.onShow.call(this)
}if(p){this._move(p)
}};
e.prototype._load=function(k,m){var l=new Image();
this.$target.addClass("is-loading").append(this.$notice.text(this.opts.loadingNotice));
this.$zoom=g(l);
l.onerror=g.proxy(function(){var n=this;
this.$notice.text(this.opts.errorNotice);
this.$target.removeClass("is-loading").addClass("is-error");
this.detachNotice=setTimeout(function(){n.$notice.detach();
n.detachNotice=null
},this.opts.errorDuration)
},this);
l.onload=g.proxy(function(){if(!l.width){return
}this.isReady=true;
this.$notice.detach();
this.$flyout.html(this.$zoom);
this.$target.removeClass("is-loading").addClass("is-ready");
m()
},this);
l.style.position="absolute";
l.src=k
};
e.prototype._move=function(o){if(o.type.indexOf("touch")===0){var m=o.touches||o.originalEvent.touches;
d=m[0].pageX;
c=m[0].pageY
}else{d=o.pageX||d;
c=o.pageY||c
}var p=this.$target.offset();
var n=c-p.top;
var l=d-p.left;
var k=Math.ceil(n*j);
var q=Math.ceil(l*b);
if(q<0||k<0||q>a||k>h){this.hide()
}else{this.$zoom.css({top:""+(k*-1)+"px",left:""+(q*-1)+"px"})
}};
e.prototype.hide=function(){if(this.isOpen){this.$flyout.detach();
this.isOpen=false;
if(this.opts.onHide){this.opts.onHide.call(this)
}}};
e.prototype.swap=function(l,m,k){this.hide();
this.isReady=false;
if(this.detachNotice){clearTimeout(this.detachNotice)
}if(this.$notice.parent().length){this.$notice.detach()
}if(g.isArray(k)){k=k.join()
}this.$target.removeClass("is-loading is-ready is-error");
this.$image.attr({src:l,srcset:k});
this.$link.attr("href",m)
};
e.prototype.teardown=function(){this.hide();
this.$target.removeClass("is-loading is-ready is-error").off(".easyzoom");
if(this.detachNotice){clearTimeout(this.detachNotice)
}delete this.$link;
delete this.$zoom;
delete this.$image;
delete this.$notice;
delete this.$flyout;
delete this.isOpen;
delete this.isReady
};
g.fn.easyZoom=function(k){return this.each(function(){var l=g.data(this,"easyZoom");
if(!l){g.data(this,"easyZoom",new e(this,k))
}else{if(l.isOpen===undefined){l._init()
}}})
};
if(typeof define==="function"&&define.amd){define(function(){return e
})
}else{if(typeof module!=="undefined"&&module.exports){module.exports=e
}}})(jQuery);
$(".cx-breadcrumbs.insidebar").each(function(){$(".dropdown-menu.cx-breadcrumbs").html($(this).html())
});
(function(){angular.module("main",["cxTreeMenu","cxClipboard","cxResults","cxAutocomplete","cxPagination"])
})();
(function(){angular.module("cxAutocomplete",["cxResults"]).directive("autocomplete",["$http","GetParam","$timeout",function(c,b,a){return{restrict:"E",template:"<div class='Autocomplete'>    <input class='Autocomplete-input' placeholder='Search' type='text' ng-model='searchString' name='q' autocomplete='off'/>    <input type='hidden' ng-model='tags' name='tags' id='tags' />    <input type='hidden' name='fq' value='archived_status:'Not Archived''>    <input type='submit' value='Search' class='cx-magnifying-icon'>    <div class='Autocomplete-result' ng-show='isTyping'>        <div class='Autocomplete-spinner' ng-show='loading'>            <div class='rect1'></div>            <div class='rect2'></div>            <div class='rect3'></div>            <div class='rect4'></div>            <div class='rect5'></div>        </div>        <ul class='Autocomplete-list' ng-hide='notFound'>            <li class='Autocomplete-item' ng-repeat='item in results'>                <a href='#' ng-click='choseItem(item.name)' class='Autocomplete-itemLink {{item.is_title}}' >{{ item.name }}</a>            </li>        </ul>        <div class='Autocomplete-notFound' ng-show='notFound'></div>    </div></div>",scope:{dataMaxSize:"@maxSize",dataUrl:"@url"},link:function(g,f,d){g.loading=false;
g.chosedItem=false;
g.results=[];
g.isTyping=false;
g.notFound=false;
var h={types:[],productName:[],productVersion:[],componentName:[],componentVersion:[],categoryName:[],categoryVersion:[],plataform:[]};
h.types=f.data("type");
h.productName=f.data("productname");
h.productVersion=f.data("productversion");
h.componentName=f.data("componentname");
h.componentVersion=f.data("componentversion");
h.categoryName=f.data("categoryname");
h.categoryVersion=f.data("categoryversion");
h.plataform=f.data("platform");
if(window.btoa){$("#tags").attr("value",btoa(JSON.stringify(h)))
}else{}g.choseItem=function(j){g.searchString=j;
g.chosedItem=true;
g.isTyping=false;
$(".Autocomplete-input").focus()
};
a(function(){var j=b.getUrlParameter("q",true);
if(j){$(".Autocomplete-input").val(decodeURIComponent(j))
}},100);
function e(p){var k=[{name:"Products",is_title:"is_title",param:"pn"}];
var l=[{name:"Components",is_title:"is_title",param:"cn"}];
var r=[];
var j=2;
p.forEach(function(t){var u=t.suggestion.split(";");
if("pn"===u[1]){k.push({name:u[0],is_title:"not_is_title",param:"pn"});
j=0
}if("pv"===u[1]){if(j<2){k.push({name:u[0],is_title:"is_versiones",param:"pv"});
j=j+1
}}if("cn"===u[1]){l.push({name:u[0],is_title:"not_is_title",param:"cn"})
}if("cv"===u[1]){l.push({name:u[0],is_title:"is_versiones",param:"cv"})
}if("ck"===u[1]){r.push({name:u[0],is_title:"not_is_title",param:"ck"})
}});
var s=[];
var q=k.length,o=l.length,m=r.length;
if(q+o+m>10){if(m>0){for(var n=0;
n<4;
n++){if(r[n]){s.push(r[n])
}}}if(q>1){for(var n=0;
n<k.length;
n++){if(k[n]){s.push(k[n])
}}}if(o>1){for(var n=0;
n<4;
n++){if(l[n]){s.push(l[n])
}}}}else{if(m>0){s=s.concat(r)
}if(q>1){s=s.concat(k)
}if(o>1){s=s.concat(l)
}}return s
}g.$watch("searchString",function(l,j){var k=l;
g.results=[];
if(g.chosedItem){g.chosedItem=false;
return
}if(k===undefined||k==""){g.isTyping=false;
return
}g.isTyping=true;
if(k.length>g.dataMaxSize){var m="search="+k;
g.loading=true;
g.isTyping=true;
c.get(g.dataUrl+"?q="+k).then(function(n){g.loading=false;
if(n.data.suggest.found>0){g.notFound=false;
g.results=e(n.data.suggest.suggestions)
}else{g.notFound=true
}})
}})
}}
}])
})();
(function(b){var a=function(){var c=$("footer.cx-footer"),e=$(".back-to-top"),f,h;
e.on("click",function(){$("html, body").animate({scrollTop:0},400);
return false
});
var j=function(){e.addClass("is-fixed").removeClass("is-absolute").css("top","auto").css("bottom",0)
};
var g=function(){e.addClass("is-absolute").removeClass("is-fixed").css("bottom","auto").css("top",Math.ceil(c.offset().top)-e.outerHeight(true))
};
var d=function(){if($(window).height()>c.offset().top){e.hide();
return false
}e.show();
if($(window).scrollTop()>200){if(typeof h==="undefined"||h){e.addClass("is-visible")
}h=false
}else{if(typeof h==="undefined"||!h){e.removeClass("is-visible")
}h=true
}if(Math.ceil(c.offset().top)<$(window).scrollTop()+$(window).height()){if(typeof f==="undefined"||f){g()
}f=false
}else{if(typeof f==="undefined"||!f){j()
}f=true
}};
$(window).on("load",function(){setTimeout(d);
$(window).scroll(d)
})
}()
})(onEndResize);
(function(){angular.module("main").directive("backgroundImage",["$window",function(a){return{scope:{backgroundImage:"@"},restrict:"A",link:function(d,c,b){c.css("backgroundImage","url("+d.backgroundImage+")")
}}
}])
})();
(function(){Modernizr.addTest("firefox",function(){return !!navigator.userAgent.match(/firefox/i)
});
if(navigator.userAgent.match(/IEMobile\/10\.0/)){var a=document.createElement("style");
a.appendChild(document.createTextNode("@-ms-viewport{width:auto!important}"));
document.getElementsByTagName("head")[0].appendChild(a)
}})();
(function(){angular.module("cxClipboard",[]).directive("copyCode",function(){return{restrict:"A",link:function(f,e,c){ZeroClipboard.config({swfPath:"http://cdnjs.cloudflare.com/ajax/libs/zeroclipboard/2.1.6/ZeroClipboard.swf"});
var g=e.find(".copy-trigger"),b=e.find(".clipboard-content pre code"),d="ctc_"+(Math.random()+1).toString(36).substring(7),a=null;
b.attr("id",d);
g.attr("data-clipboard-target",d);
a=new ZeroClipboard(g);
a.on("ready",function(){a.on("error",function(h){ZeroClipboard.destroy()
});
a.on("mouseover",function(h){ZeroClipboard.destroy()
})
})
}}
});
$(".clipboard-content").jScrollPane({showArrows:true,horizontalGutter:30,verticalGutter:30,autoReinitialise:true,horizontalDragMinWidth:20,horizontalDragMaxWidth:20})
})();
(function(){$(document).ready(function(){$('[data-auto-close="false"]').on("click",function(c){c.stopPropagation()
});
$(".cx-products-names").css("display","none");
$(document).click(function(){$(".cx-products-names").css("display","none").parent().removeClass("on")
});
$("#cx-products").click(function(){$(".cx-products-names").css("display","block").addClass("dropdown-menu");
$(".cx-products-filter").css("display","none").removeClass("dropdown-menu")
});
var b="Select Solution/Product";
$(".cx-products-names li").on("click",function(d){var f=$(this).text();
if(f!==""){$("#cx-products").text(f);
var c=$(this).data("name");
a(c)
}});
function a(d){if(!a.hasOwnProperty("lastResult")){a.lastResult=null
}var c=$('[data-result="'+d+'"]');
if(!c.length||a.lastResult===c){return false
}else{$(".cx-products-names").css("display","none").removeClass("dropdown-menu");
$(".cx-products-filter").css("display","block").addClass("dropdown-menu");
if(a.lastResult){a.lastResult.removeClass("active")
}c.addClass("active");
a.lastResult=c
}}$(".close_filter").on("click",function(c){$(".cx-products-filter").css("display","none").removeClass("dropdown-menu");
$(".cx-products-names").css("display","none").addClass("dropdown-menu").parent().removeClass("on")
})
})
})();
var onEndResize=(function(){var a=function(e,d){var c,b=typeof d!=="undefined"?d:180;
if(typeof e!=="function"||b>>>0!==parseFloat(b)){return false
}$(window).on("resize",function(){clearTimeout(c);
c=setTimeout(e,b)
})
};
return a
})();
(function(){angular.module("cxPagination",["cxResults",]).directive("pagination",["GetParam","$http",function(a,b){return{restrict:"C",controller:["$scope",function(d){d.renderPagination=function(j,l){if(j>10){var f=Math.ceil(j/10)
}else{var f=1
}var h=l-10;
l=l/10+1;
html="";
if(l!==1){var e=i-1;
if(h<0){h=0
}html='<li  class="number previous" data-num="'+h+'"  ><a href="#"> Previous </a></li>'
}if(l<5){for(i=1;
i<=f;
i++){if(i<=10){var k=i-1;
if(i===l){html+='<li  class="number bolder" data-num="'+k*10+'" > <a href="#"> '+i+" </a></li>"
}else{html+='<li  class="number" data-num="'+k*10+'" > <a href="#"> '+i+" </a></li>"
}}}}else{for(i=l-4;
i<l+5;
i++){if(i<=f){var e=i-1;
if(i===l){html+='<li  class="number bolder" data-num="'+k*10+'" > <a href="#"> '+i+" </a></li>"
}else{html+='<li  class="number" data-num="'+e*10+'" > <a href="#"> '+i+" </a></li>"
}}}}if(f>l+10&&l!==f&&l!==f-1){html+='<li  class="number"  > ...</li>'
}if(f!==l){var g=l*10;
html+='<li class="number next" data-num="'+g+'" ng-click="pagnationclick($event)"><a href="#"> Next </a></li>'
}$(".numbering").html(html);
$(".pagination .number").on("click",c)
};
var c=function(f){var e=$(f.target.parentElement).data("num");
var g="";
if($(".filter-relevance").is(":checked")){g="_score+desc"
}else{g="date_of_last_major_change+desc"
}if(d.hide_pver){d.sendQuery("version_products","cx-results-checkbox",e,g)
}else{if(d.hide_subver){d.sendQuery("sversion_products","cx-subselect-checkbox",e,g)
}else{d.sendQuery("","",e,g)
}}$(".pagination .number").on("click",c)
}
}]}
}])
})();
$(function(){$("[data-toggle='popover']").popover();
var a=$(".cx-search-popover").attr("data-text");
$(".cx-search-input").popover({html:true,content:a,animation:true,placement:"right",container:".cx-search-input"});
$(".cx-magnifying-icon").click(function(){$(".cx-search-input").popover()
})
});
(function(a){})(jQuery);
(function(){function b(e,f,c){for(var d=0;
d<c.length;
d++){if(c[d][e]===f){return c[d]
}else{}}}function a(f){var c=new Array();
for(var e=0,d=f.length;
e<d;
e++){if(f[e]){c.push(f[e])
}}return c
}angular.module("cxResults",["cxPagination","ngSanitize"]).service("GetParam",function(){this.getUrlParameter=function(j,c){var h=window.location.search.substring(1);
var d=h.split("&");
for(var e=0;
e<d.length;
e++){var g=d[e].split("=");
if(g[0]==j){if(j=="q"){if(c){f=decodeURIComponent(g[1]).split("+").join(" ")
}else{var f=g[1].split("%22").join('"').split("%3F").join("?").split("+").join(" ");
f=decodeURIComponent(f)
}f=f.split(">").join("").split("<").join("").split("<script>").join("").split("<\/script>").join("");
return f
}else{return g[1]
}}}}
}).directive("searchResults",function(){return{restrict:"A",controllerAs:"result",controller:["$scope","$http","GetParam","$timeout","$attrs",function(k,h,f,e,j){k.is_not_found=false;
k.is_not_found_log=true;
k.hide_p=false;
k.hide_pver=false;
k.hide_sub=false;
k.hide_subver=false;
k.categoryFilter=[];
k.productFilter=[];
k.pversionFilter=[];
k.subcategoryFilter=[];
k.psubversionFilter=[];
var g={types:[],productName:[],productVersion:[],componentName:[],componentVersion:[],categoryName:[],categoryVersion:[],plataform:[]};
k.sendQuery=function(n,G,q,w,t){var x="",K="",y,A="",J,B="";
if(window.btoa){$("#tags").attr("value",btoa(JSON.stringify(g)))
}else{}if(n!==""){A="."+n+":checked";
if($(" ."+G+" .legacy").is(":checked")){B="."+n+".archived"
}y=$(A);
for(var C=0,D=y.length;
C<D;
C++){if(x!==""){x=x+","+$(y[C]).data("key")
}else{x=$(y[C]).data("key")
}}J=$(B);
for(var C=0,D=J.length;
C<D;
C++){if(K!==""){K=K+","+$(J[C]).data("key")
}else{K=$(J[C]).data("key")
}}var r=false;
if($(" ."+G+" .legacy").is(":checked")){r=true
}else{r=false
}}var s="/bin/docs/search?q=";
var H="";
var z;
var o;
var I="";
var E;
if(typeof f.getUrlParameter("q",false)!=="undefined"){s+=encodeURIComponent(f.getUrlParameter("q",false))
}var u=$(".filter-check input:checked").data("slug");
if(u=="product"){z="product_name";
o="product_version"
}else{if(u=="category"){z="category";
o=""
}else{z="component_name";
o="component_version"
}}if("cx-results-checkbox"==G||"cx-subselect-checkbox"==G){H=z+":'"+$(".cx-global-select button").html()+"'"
}else{H=""
}var p=x.split(",");
var F=K.split(",");
var v=keys_totalArch="";
if(o){if(p.length>0){v=" (or";
p.forEach(function(L){v+=" "+o+":'"+L.replace("/","%2F")+"'"
});
v+=") "
}if(F.length>0){keys_totalArch=" (or";
F.forEach(function(L){keys_totalArch+=" "+o+":'"+L.replace("/","%2F")+"'"
});
keys_totalArch+=") "
}}if(H){if(r){if(x!==""){s+="&fq="+encodeURIComponent("(or (and "+H+v+"archived_status:'Not Archived')(and "+H+keys_totalArch+"archived_status:'Archived'))")
}else{if(keys_totalArch){s+="&fq="+encodeURIComponent("(and "+H+keys_totalArch+"archived_status:'Archived')")
}else{s+="&fq="+encodeURIComponent("(or (and "+H+" archived_status:'Not Archived') (and "+H+" archived_status:'Archived'))")
}}}else{if(x!==""){s+="&fq="+encodeURIComponent("(and "+H+v+"archived_status:'Not Archived')")
}else{s+="&fq="+encodeURIComponent("(and "+H+" archived_status:'Not Archived')")
}}}else{s+="&fq="+encodeURIComponent("archived_status:'Not Archived'")
}if(w){s+="&sort="+w
}else{if($(".filter-relevance").is(":checked")){w="_score+desc"
}else{w="date_of_last_major_change+desc"
}s+="&sort="+w
}s+="&size=10&start="+q;
h.get(s).success(function(L){if(L){if(L.hits.found!==0){k.is_not_found=false
}else{k.is_not_found=true
}k.is_not_found_log=false;
k.results=L.hits.hit;
k.hit=L.hits.found;
k.time=parseInt(L.status["time-ms"])/1000;
k.renderPagination(L.hits.found,q);
$(".description_result").html(f.getUrlParameter("q",true))
}})
};
k.fShowProduct=function(n,o){k.productFilter=b("slug",n,k.categoryFilter).categories;
k.hide_p=true;
k.hide_pver=false;
k.hide_sub=false;
k.hide_subver=false;
if(n==="category"){n="categories"
}else{n=n+"s"
}$(".cx-global-select button").html("All "+n);
if(!o){k.sendQuery("","",0)
}};
k.clickorderby=function(){var n;
if($(".filter-relevance").is(":checked")){n="_score+desc"
}else{n="date_of_last_major_change+desc"
}if(k.hide_pver){k.sendQuery("version_products","cx-results-checkbox",0,n)
}else{if(k.hide_subver){k.sendQuery("sversion_products","cx-subselect-checkbox",0,n)
}else{k.sendQuery("","",0,n)
}}};
k.allDocsmain=function(){if($(".alldocs").is(":checked")){k.hide_p=false;
k.hide_pver=false;
k.hide_sub=false;
k.hide_subver=false;
k.sendQuery("","",0)
}};
k.fShowVer=function(n,q){var p=b("slug",n,k.productFilter);
$(".cx-global-select button").html(p.name);
$(".cx-global-select button").data("slug",p.slug);
$(".cx-subselect button").html("All");
if(p.have_subcategory){k.subcategoryFilter=p.list_subcategory;
k.hide_pver=false;
k.hide_sub=true;
k.hide_subver=false
}else{k.pversionFilter=p.list_items;
var o=0;
p.list_items.forEach(function(r){o=parseInt(o)+parseInt(r.numresults)
});
k.all_cad=o;
k.hide_pver=true;
k.hide_sub=false;
k.hide_subver=false;
$(".all_vp").prop("checked",true);
$(".version_products").prop("checked",true);
e(function(r){if($(".version_products[type=checkbox]").length>0){k.all_show=true
}else{k.all_show=false
}k.sendQuery("version_products","cx-results-checkbox",0)
},100)
}$(".sversion_products").prop("checked",false)
};
k.fShowSubVer=function(n,q){var p=b("slug",n,k.subcategoryFilter);
var o=0;
$(".cx-subselect button").html(p.name);
$(".cx-subselect button").data("slug",p.slug);
p.list_items.forEach(function(r){o=parseInt(o)+parseInt(r.numresults)
});
k.all_scad=o;
k.psubversionFilter=p.list_items;
k.hide_pver=false;
k.hide_sub=true;
k.hide_subver=true;
$(".version_products").prop("checked",true);
e(function(){if($(".sversion_products[type=checkbox]").length>0){k.suball_show=true
}else{k.suball_show=false
}k.sendQuery("sversion_products","cx-subselect-checkbox",0)
},100)
};
k.checkeall=function(){if($(".all_vp").is(":checked")){$(".version_products").prop("checked",true);
k.sendQuery("version_products","cx-results-checkbox",0)
}else{$(".version_products").prop("checked",false);
k.sendQuery("version_products","cx-results-checkbox",0)
}};
k.clickvp=function(){$(".all_vp").prop("checked",false);
$(".all_svp").prop("checked",false);
k.sendQuery("version_products","cx-results-checkbox",0)
};
k.checkesall=function(){if($(".all_svp").is(":checked")){$(".sversion_products").prop("checked",true);
k.sendQuery("sversion_products","cx-subselect-checkbox",0)
}else{$(".sversion_products").prop("checked",false);
k.sendQuery("sversion_products","cx-subselect-checkbox",0)
}};
k.clicksvp=function(){$(".all_svp").prop("checked",false);
k.sendQuery("sversion_products","cx-subselect-checkbox",0)
};
k.clicklegacy=function(o,n){k.sendQuery(o,n,0)
};
if(k.categoryFilter!==[]){var d=function(){var n=k.categoryFilter;
if(n){n.forEach(function(o){if(o.is_activated){k.fShowProduct(o.slug,true);
$('.filter-check input[data-slug="'+o.slug+'"]').prop("checked",true);
if(o.categories.length>0){o.categories.forEach(function(p){if(p.is_activated){k.fShowVer(p.slug,true);
if(p.have_subcategory){p.list_subcategory.forEach(function(s){if(s.is_activated){k.pre_subproducto=s
}});
var r=false;
k.fShowSubVer(k.pre_subproducto.slug,true);
k.s_array_version=[];
k.pre_subproducto.list_items.forEach(function(s){if(s.is_activated){r=true;
k.s_array_version.push(s)
}});
if(r){e(function(){$(".all_svp").prop("checked",false);
$(".sversion_products").prop("checked",false);
k.s_array_version.forEach(function(s){$('.sversion_products[data-key="'+s.slug+'"]').prop("checked",true)
})
},100)
}}else{k.array_version=[];
var q=false;
p.list_items.forEach(function(s){if(s.is_activated){k.array_version.push(s);
q=true
}});
if(q){e(function(){$(".all_vp").prop("checked",false);
$(".version_products").prop("checked",false);
k.array_version.forEach(function(s){$('.version_products[data-key="'+s.slug+'"]').prop("checked",true)
})
},100)
}}}})
}}})
}};
var m=jQuery.makeArray(j.tags);
var l=f.getUrlParameter("tags",false);
var c=Math.floor((Math.random()*100)+1);
h.get("/bin/citrix/searchfilter."+c+".json?tags="+l).success(function(n){k.categoryFilter=n.list
});
k.$on("onRepeatLast",function(p,o,n){d()
})
}k.sendQuery("","",0)
}]}
}).directive("renderFilterPredefined",function(){return function(e,d,c){if(e.$last){setTimeout(function(){e.$emit("onRepeatLast",d,c)
},1)
}}
})
})();
(function(){$(".left-nav-parent-pages-actual ").on("click",function(a){$(this).siblings("ul").toggle();
$(this).toggleClass("left-nav-parent-pages")
})
})();
(function(){var e=$(".matrix")?true:false;
if(e){var a=$("<div class='row-headings'></div>");
var d=[];
$(".row-heading").each(function(){d.push($(this).text())
});
e=$(".matrix");
var b=$(".matrix .row-heading").length;
for(var c=1;
c<=b;
c++){a.append($("<div></div>"))
}e.wrap("<div class='table-wrap'></div>");
$(".table-wrap").wrap("<div class='responsive-matrix-on'></div>");
$(".responsive-matrix-on").prepend(a);
$(".row-headings div").each(function(f){$(this).text(d[f])
})
}$(window).resize(function(){if(e){e=$(".matrix");
var f=[];
$(".row-headings div").each(function(){f.push($(this).innerHeight())
});
$(".matrix tr").each(function(g){$(this).innerHeight(f[g])
})
}})
})();
function choiceprop(b,a){if(b=="_self"){window.location=a
}if(b=="_blank"){window.open(a)
}}(function(){angular.module("cxTreeMenu",[]).directive("treeMenu",function(){return{restrict:"A",link:function(d,c,b){var a=null;
c.find(".dropdown-trigger").bind("click",function(h){h.preventDefault();
var f=angular.element(this),g=f.next(".dropdown");
f.toggleClass("open");
a=f
})
}}
})
})();
(function(){$(".easyzoom").easyZoom()
})();
(function(){angular.module("main").filter("capitalize",function(){return function(a){if(!a){return""
}a=a.trim();
return a.substr(0,1).toUpperCase()+a.substr(1)
}
})
})();
(function(){angular.module("main").filter("ellipsis",function(){return function(j,h,f,e){if(!j){return""
}h=parseInt(h,10);
if(!h){return j
}if(j.length<=h){return j
}var c=/\.{3,}/g;
if(c.test(j)){j=j.replace(c," ")
}var a=/<b>.*<\/b>/;
var b=a.test(j);
if(b){var g=j.search(a);
var k=(h>g)?0:g;
var d=(g+h>j.length)?j.length:g+h;
var l=j.substring(k,d);
return l
}else{j=j.substring(0,h)
}return j
}
}).filter("to_trusted",["$sce",function(a){return function(b){return a.trustAsHtml(b)
}
}])
})();
$(".datatable").each(function(){var a=[];
$(this).find("thead tr th").each(function(b){a[b]=$(this).html()
});
$(this).find("tbody tr").each(function(){$(this).find("td").each(function(b){$(this).attr("before",a[b])
})
})
});
$(".matrix").each(function(){$(this).find("tbody tr").each(function(){$(this).find("td:first").each(function(a){$(this).attr("class","row-heading")
})
});
$(this).find("thead tr th:first").each(function(){$(this).attr("class","row-heading")
})
});
$(document).ready(function(){setLanguage()
});
function setSelectedLanguage(){var d="docslanguage";
var c=getCookie(d);
if(c!==null){var b=c.split(",");
var a;
if(!(b instanceof String)){a=b[b.length-1]
}else{a=c
}$('#cx-language-selector option:contains("'+a+'")').attr("selected","selected")
}}function delCookie(a){document.cookie=a+"=; expires=Thu, 01-Jan-70 00:00:01 GMT;"
}function setCookie(a,e,c){var f=new Date();
f.setDate(f.getDate()+c);
var d="";
var b=window.navigator.userAgent;
if(b.indexOf("MSIE")<0){d=escape(e)+((c==null)?"":"; expires="+f.toUTCString())+";path=/"
}else{d=escape(e)
}document.cookie=a+"="+d
}function getCookie(b){var c=document.cookie;
var d=c.indexOf(" "+b+"=");
if(d==-1){d=c.indexOf(b+"=")
}if(d==-1){c=null
}else{d=c.indexOf("=",d)+1;
var a=c.indexOf(";",d);
if(a==-1){a=c.length
}c=unescape(c.substring(d,a))
}return c
}function redirectLanguage(){var b=$("#cx-language-selector option:selected").val();
var a=location.protocol+"//"+location.hostname+(location.port?":"+location.port:"")+b;
var d=$("input[name='q']").val();
if(typeof d!=="undefined"&&d!==""){var c=window.document.URL.toString();
var e=c.indexOf("tags");
if(e!==-1){var f=c.substring(e);
a=a+"?q="+d+"&tags="+f
}}window.location.href=a
}function setLanguage(){var c=window.location.pathname.split("/")[1];
if(c==="content"){c=window.location.pathname.split("/")[3]
}var a=$("#cx-language-selector option");
for(var b=0;
b<=a.length;
b++){var d=a[b].value;
if(d.indexOf(c)>=0){a[b].selected=true;
break
}}if(c.length<1){$('#cx-language-selector option[value="/en-us.html"]').prop("selected","selected")
}}$(document).ready(function(){if($("#startDate").length){$("#startDate").datepicker()
}if($("#endDate").length){$("#endDate").datepicker()
}});
(function(){var e=$(".matrix")?true:false;
if(e){var a=$("<div class='row-headings'></div>");
var d=[];
$(".row-heading").each(function(){d.push($(this).text())
});
e=$(".matrix");
var b=$(".matrix .row-heading").length;
for(var c=1;
c<=b;
c++){a.append($("<div></div>"))
}e.wrap("<div class='table-wrap'></div>");
$(".table-wrap").wrap("<div class='responsive-matrix-on'></div>");
$(".responsive-matrix-on").prepend(a);
$(".row-headings div").each(function(f){$(this).text(d[f])
})
}$(window).resize(function(){if(e){e=$(".matrix");
var f=[];
$(".row-headings div").each(function(){f.push($(this).innerHeight())
});
$(".matrix tr").each(function(g){$(this).innerHeight(f[g])
})
}})
})();
function trackSelection(f,e){var b=getCookie("recentlyviewed");
if(b!==undefined&&b!==null&&b.length>0){var a=b.split("$$");
var c="";
var d=a.length;
if(d>15){d=15
}for(i=0;
i<d;
i++){var g=a[i].split("||");
if(e==g[1]){continue
}c+="$$"+g[0]+"||"+g[1]
}setCookie("recentlyviewed",f+"||"+e+c)
}else{setCookie("recentlyviewed",f+"||"+e)
}}function populateTrackSelection(c){var b=getCookie("recentlyviewed");
if(b!==undefined&&b!==null&&b.length>0){var a=b.split("$$");
total=c;
if(a.length<c){total=a.length
}$ul=$("ul[recent-viewed='true']");
for(i=0;
i<total;
i++){if(a[i]!==undefined){var d=a[i].split("||");
$ul.append("<li><a href='"+d[1]+"'>"+d[0]+"</a></li>")
}}}else{$("div.recentlyviewed").hide()
}}$(document).ready(function(){$("#clickme").click()
});
function locate(a){if($("li[data-path='"+a+"']")[0]==undefined){location.replace(a+".html")
}else{$("#mainmenudropdown").click();
$("li[data-path='"+a+"']").click()
}}function filterSearch(){var b="/etc/designs/citrixedocs/clientlibs/scripts/json/SearchResponse.json";
var c="#cx-search-result-text";
$.getJSON(b).done(function(d){a(d)
}).fail(function(f,g,d){var e=g+","+d;
console.log(e)
});
var a=function(e){console.log("JSON Data:",e);
var f=$(c);
f.empty();
var d;
var h="";
$.each(e.results,function(){h="";
$.each(this.products,function(){h+="["+this+"]"
});
f.append("<div><a href='"+this.url+"'>"+this.title+"</a><br><a class='cx-search-result-url' href='"+this.url+"'>"+this.url+"</a><p>"+this.description+" <br> "+h+"</p></div>")
});
f.append("<br><br>");
var g=document.createElement("center");
$.each(e.pages,function(){console.log("test numeration:",this);
if(this.path){$(g).append("<a href='"+this.path+"'>"+this.number+"</a>    ")
}else{$(g).append("<b>"+this.number+"</b>    ")
}});
f.append(g)
}
}function updateFeedbackValue(c){var a;
var b;
if(c===1){a=$("#cx-feedback-value-first").val();
b=getFeedbackValue(a);
$("input[name=positiveFeedback]").val(b)
}else{if(c===2){a=$("#cx-feedback-value-second").val();
b=getFeedbackValue(a);
$("input[name=negativeFeedback]").val(b)
}}}function getFeedbackValue(a){if(a){if(!isNaN(a)){var b=parseInt(a);
return ++b
}}return 1
}function sendFeedback(b,a){if(b===1){$.ajax({url:"/bin/docs/setFeedback",type:"get",data:{path:a,value:1},success:function(c){$("input[name=negativeFeedback]").prop("checked",false)
},error:function(c){}})
}else{if(b===2){$.ajax({url:"/bin/docs/setFeedback",type:"get",data:{path:a,value:2},success:function(c){$("input[name=positiveFeedback]").prop("checked",false)
},error:function(c){}})
}}}
/*!
 * The MIT License
 *
 * Copyright (c) 2012 James Allardice
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
!function(aW){function aV(){}function aU(){try{return document.activeElement
}catch(b){}}function aT(f,e){for(var h=0,g=f.length;
g>h;
h++){if(f[h]===e){return !0
}}return !1
}function aS(e,d,f){return e.addEventListener?e.addEventListener(d,f,!1):e.attachEvent?e.attachEvent("on"+d,f):void 0
}function aR(e,d){var f;
e.createTextRange?(f=e.createTextRange(),f.move("character",d),f.select()):e.selectionStart&&(e.focus(),e.setSelectionRange(d,d))
}function aQ(e,d){try{return e.type=d,!0
}catch(f){return !1
}}function aP(r,q){if(r&&r.getAttribute(av)){q(r)
}else{for(var p,o=r?r.getElementsByTagName("input"):ai,n=r?r.getElementsByTagName("textarea"):ah,m=o?o.length:0,l=n?n.length:0,k=m+l,j=0;
k>j;
j++){p=m>j?o[j]:n[j-m],q(p)
}}}function aO(b){aP(b,aM)
}function aN(b){aP(b,aL)
}function aM(h,g){var m=!!g&&h.value!==g,l=h.value===h.getAttribute(av);
if((m||l)&&"true"===h.getAttribute(au)){h.removeAttribute(au),h.value=h.value.replace(h.getAttribute(av),""),h.className=h.className.replace(aw,"");
var k=h.getAttribute(an);
parseInt(k,10)>=0&&(h.setAttribute("maxLength",k),h.removeAttribute(an));
var j=h.getAttribute(at);
return j&&(h.type=j),!0
}return !1
}function aL(f){var e=f.getAttribute(av);
if(""===f.value&&e){f.setAttribute(au,"true"),f.value=e,f.className+=" "+ax;
var h=f.getAttribute(an);
h||(f.setAttribute(an,f.maxLength),f.removeAttribute("maxLength"));
var g=f.getAttribute(at);
return g?f.type="text":"password"===f.type&&aQ(f,"text")&&f.setAttribute(at,"password"),!0
}return !1
}function aK(b){return function(){ag&&b.value===b.getAttribute(av)&&"true"===b.getAttribute(au)?aR(b,0):aM(b)
}
}function aJ(b){return function(){aL(b)
}
}function aI(b){return function(){aO(b)
}
}function aH(b){return function(a){return aB=b.value,"true"===b.getAttribute(au)&&aB===b.getAttribute(av)&&aT(az,a.keyCode)?(a.preventDefault&&a.preventDefault(),!1):void 0
}
}function aG(b){return function(){aM(b,aB),""===b.value&&(b.blur(),aR(b,0))
}
}function aF(b){return function(){b===aU()&&b.value===b.getAttribute(av)&&"true"===b.getAttribute(au)&&aR(b,0)
}
}function aE(d){var c=d.form;
c&&"string"==typeof c&&(c=document.getElementById(c),c.getAttribute(ar)||(aS(c,"submit",aI(c)),c.setAttribute(ar,"true"))),aS(d,"focus",aK(d)),aS(d,"blur",aJ(d)),ag&&(aS(d,"keydown",aH(d)),aS(d,"keyup",aG(d)),aS(d,"click",aF(d))),d.setAttribute(aq,"true"),d.setAttribute(av,ac),(ag||d!==aU())&&aL(d)
}var aD=document.createElement("input"),aC=void 0!==aD.placeholder;
if(aW.Placeholders={nativeSupport:aC,disable:aC?aV:aO,enable:aC?aV:aN},!aC){var aB,aA=["text","search","url","tel","email","password","number","textarea"],az=[27,33,34,35,36,37,38,39,40,8,46],ay="#ccc",ax="placeholdersjs",aw=new RegExp("(?:^|\\s)"+ax+"(?!\\S)"),av="data-placeholder-value",au="data-placeholder-active",at="data-placeholder-type",ar="data-placeholder-submit",aq="data-placeholder-bound",ap="data-placeholder-focus",ao="data-placeholder-live",an="data-placeholder-maxlength",am=100,al=document.getElementsByTagName("head")[0],ak=document.documentElement,aj=aW.Placeholders,ai=document.getElementsByTagName("input"),ah=document.getElementsByTagName("textarea"),ag="false"===ak.getAttribute(ap),af="false"!==ak.getAttribute(ao),ae=document.createElement("style");
ae.type="text/css";
var ad=document.createTextNode("."+ax+" {color:"+ay+";}");
ae.styleSheet?ae.styleSheet.cssText=ad.nodeValue:ae.appendChild(ad),al.insertBefore(ae,al.firstChild);
for(var ac,ab,aa=0,Z=ai.length+ah.length;
Z>aa;
aa++){ab=aa<ai.length?ai[aa]:ah[aa-ai.length],ac=ab.attributes.placeholder,ac&&(ac=ac.nodeValue,ac&&aT(aA,ab.type)&&aE(ab))
}var Y=setInterval(function(){for(var d=0,c=ai.length+ah.length;
c>d;
d++){ab=d<ai.length?ai[d]:ah[d-ai.length],ac=ab.attributes.placeholder,ac?(ac=ac.nodeValue,ac&&aT(aA,ab.type)&&(ab.getAttribute(aq)||aE(ab),(ac!==ab.getAttribute(av)||"password"===ab.type&&!ab.getAttribute(at))&&("password"===ab.type&&!ab.getAttribute(at)&&aQ(ab,"text")&&ab.setAttribute(at,"password"),ab.value===ab.getAttribute(av)&&(ab.value=ac),ab.setAttribute(av,ac)))):ab.getAttribute(au)&&(aM(ab),ab.removeAttribute(av))
}af||clearInterval(Y)
},am);
aS(aW,"beforeunload",function(){aj.disable()
})
}}(this);