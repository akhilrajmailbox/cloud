_satellite.pushAsyncScript(function(event, target, $variables){
  var CHANNEL_COOKIE = 'UTMReferralSources';

function checkSearchEngine(documentReferrer) {
    var searchEngine = undefined;
    if (documentReferrer.indexOf('google') > -1) {
        searchEngine = 'google';
    } else if (documentReferrer.indexOf('bing') > -1) {
        searchEngine = 'bing';
    } else if (documentReferrer.indexOf('yahoo') > -1) {
        searchEngine = 'yahoo';
    } else if (documentReferrer.indexOf('baidu') > -1) {
        searchEngine = 'baidu';
    } else if (documentReferrer.indexOf('yandex') > -1) {
        searchEngine = 'yandex';
    };
    return searchEngine;
};

function getChannel() {
    var currentChannel = '';
    if (_satellite.getQueryParam('gclid') != undefined) {
        currentChannel = 'google|Paid+Search+(SEM)';
    } else if (_satellite.getQueryParam('utm_source') != undefined && _satellite.getQueryParam('utm_medium') != undefined) {
        currentChannel = _satellite.getQueryParam('utm_source') + '|' + _satellite.getQueryParam('utm_medium');
    } else if (document.referrer != '') {
        var searchEngine = checkSearchEngine(document.referrer);
        if (searchEngine != undefined) {
            currentChannel = searchEngine + '|organic';
        } else {
            currentChannel = document.referrer.split( '/' )[2] + '|referral';
        }
    } else if (_satellite.readCookie('UTMReferralSources')){
        currentChannel = _satellite.readCookie('UTMReferralSources');
    } else {
        currentChannel = 'direct|direct';
    }
    return currentChannel;
};

var channelString = getChannel();
_satellite.writeCookie(CHANNEL_COOKIE, channelString, 63072000000);

});
